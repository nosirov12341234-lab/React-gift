import { useState, useEffect } from 'react'
import { G } from './styles.js'
import Home     from './pages/Home.jsx'
import Stars    from './pages/Stars.jsx'
import Premium  from './pages/Premium.jsx'
import Gifts    from './pages/Gifts.jsx'
import SMM      from './pages/SMM.jsx'
import Games    from './pages/Games.jsx'
import VirtualNum from './pages/VirtualNum.jsx'
import TonSell  from './pages/TonSell.jsx'
import TopUp    from './pages/TopUp.jsx'
import History  from './pages/History.jsx'
import Referral from './pages/Referral.jsx'
import Profile  from './pages/Profile.jsx'
import { getSettings } from './api.js'

const tg = window.Telegram?.WebApp

export default function App() {
  const [page, setPage]       = useState('home')
  const [modal, setModal]     = useState(null)
  const [settings, setSettings] = useState({})
  const [toast, setToast]     = useState(null)
  const [uid, setUid]         = useState('0')
  const [tgUser, setTgUser]   = useState(null)

  useEffect(() => {
    tg?.expand?.()
    const u = tg?.initDataUnsafe?.user
    if (u) { setUid(String(u.id)); setTgUser(u) }
    const style = document.createElement('style')
    style.textContent = G
    document.head.appendChild(style)
  }, [])

  useEffect(() => {
    if (uid !== '0') loadSettings()
  }, [uid])

  async function loadSettings() {
    try {
      const r = await getSettings(uid)
      setSettings({ ...r, bal: r.balance })
    } catch {}
  }

  function showToast(msg, type = 'ok') {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3000)
  }

  function openModal(name) { setModal(name) }
  function closeModal() { setModal(null) }

  const NAV = [
    { key: 'home',    icon: '🏠', label: 'Bosh' },
    { key: 'history', icon: '📋', label: 'Tarix' },
    { key: 'ref',     icon: '👥', label: 'Referal' },
    { key: 'profile', icon: '👤', label: 'Profil' },
  ]

  return (
    <>
      {/* Toast */}
      {toast && (
        <div style={{
          position: 'fixed', top: 20, left: '50%', transform: 'translateX(-50%)',
          background: toast.type === 'ok' ? '#22d3a5' : '#ff4f6d',
          color: '#fff', padding: '10px 20px', borderRadius: 20,
          fontSize: 13, fontWeight: 700, zIndex: 9999,
          boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
          animation: 'fadeUp .3s ease'
        }}>
          {toast.msg}
        </div>
      )}

      {/* Sahifalar */}
      {page === 'home' && (
        <Home
          settings={settings} uid={uid} tgUser={tgUser}
          onOpen={openModal} showToast={showToast}
        />
      )}
      {page === 'history' && <History uid={uid} />}
      {page === 'ref'     && <Referral uid={uid} settings={settings} showToast={showToast} />}
      {page === 'profile' && <Profile uid={uid} settings={settings} showToast={showToast} onOpen={openModal} />}

      {/* Modallar */}
      <Stars      open={modal==='stars'}    onClose={closeModal} settings={settings} uid={uid} tgUser={tgUser} showToast={showToast} onBalanceUpdate={loadSettings} />
      <Premium    open={modal==='premium'}  onClose={closeModal} settings={settings} uid={uid} tgUser={tgUser} showToast={showToast} onBalanceUpdate={loadSettings} />
      <Gifts      open={modal==='gifts'}    onClose={closeModal} settings={settings} uid={uid} tgUser={tgUser} showToast={showToast} onBalanceUpdate={loadSettings} />
      <SMM        open={modal==='smm'}      onClose={closeModal} settings={settings} uid={uid} showToast={showToast} onBalanceUpdate={loadSettings} />
      <Games      open={modal==='games'}    onClose={closeModal} settings={settings} showToast={showToast} />
      <VirtualNum open={modal==='vnum'}     onClose={closeModal} settings={settings} uid={uid} showToast={showToast} onBalanceUpdate={loadSettings} />
      <TonSell    open={modal==='ton'}      onClose={closeModal} settings={settings} uid={uid} showToast={showToast} onBalanceUpdate={loadSettings} />
      <TopUp      open={modal==='topup'}    onClose={closeModal} settings={settings} uid={uid} showToast={showToast} onBalanceUpdate={loadSettings} />

      {/* Bottom Nav */}
      <nav style={{
        position: 'fixed', bottom: 0, left: 0, right: 0,
        background: '#0f0f18', borderTop: '1px solid rgba(255,255,255,0.06)',
        display: 'flex', zIndex: 100, paddingBottom: 'env(safe-area-inset-bottom)'
      }}>
        {NAV.map(n => (
          <button key={n.key} onClick={() => setPage(n.key)} style={{
            flex: 1, background: 'none', border: 'none', padding: '10px 0',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            cursor: 'pointer', opacity: page === n.key ? 1 : 0.4,
            transition: 'opacity .2s'
          }}>
            <span style={{ fontSize: 20 }}>{n.icon}</span>
            <span style={{
              fontSize: 9, color: page === n.key ? 'var(--gold)' : 'var(--mt)',
              fontWeight: page === n.key ? 800 : 400
            }}>{n.label}</span>
          </button>
        ))}
      </nav>
    </>
  )
}
