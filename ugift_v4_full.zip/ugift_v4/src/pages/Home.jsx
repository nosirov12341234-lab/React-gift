const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g,' ')

const SERVICES = [
  { key:'stars',   icon:'⭐', label:'Stars',         sub:'Telegram Stars',      color:'rgba(245,200,66,0.15)' },
  { key:'premium', icon:'👑', label:'Premium',       sub:'Telegram Premium',    color:'rgba(124,92,252,0.15)' },
  { key:'gifts',   icon:'🎁', label:'Giftlar',       sub:'Telegram giftlar',    color:'rgba(34,211,165,0.12)' },
  { key:'smm',     icon:'📊', label:'SMM',           sub:'Ijtimoiy tarmoqlar',  color:'rgba(42,171,238,0.12)' },
  { key:'vnum',    icon:'📱', label:'Virtual raqam', sub:'Telegram uchun',      color:'rgba(255,170,0,0.12)'  },
  { key:'ton',     icon:'💎', label:'TON / USDT',    sub:'Kriptovalyuta',       color:'rgba(100,180,255,0.12)'},
  { key:'games',   icon:'🎮', label:'O\'yin donati', sub:'FF, PUBG, MLBB...',   color:'rgba(255,79,109,0.12)' },
  { key:'topup',   icon:'💳', label:'Balans',        sub:'Hisob to\'ldirish',   color:'rgba(245,200,66,0.08)' },
]

export default function Home({ settings, uid, tgUser, onOpen, showToast }) {
  const bal = settings?.bal || 0

  return (
    <div style={{ animation: 'fadeUp .28s ease', paddingBottom: 80 }}>

      {/* Balans kartasi */}
      <div style={{
        margin: '16px 18px 0',
        background: 'linear-gradient(135deg,#1e1a3a,#0f1525)',
        border: '1px solid rgba(124,92,252,0.2)',
        borderRadius: 20, padding: '20px', position: 'relative', overflow: 'hidden'
      }}>
        <div style={{
          position: 'absolute', top: -40, right: -40, width: 160, height: 160,
          background: 'radial-gradient(circle,rgba(124,92,252,0.15),transparent 70%)',
          borderRadius: '50%', pointerEvents: 'none'
        }} />
        <div style={{ fontSize: 11, color: 'var(--mt)', letterSpacing: 2, textTransform: 'uppercase', marginBottom: 4 }}>
          Balansingiz
        </div>
        <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 28, fontWeight: 700, color: 'var(--gold)' }}>
          {fmt(bal)} <span style={{ fontSize: 14, color: 'var(--mt)' }}>so'm</span>
        </div>
        <div style={{ fontSize: 11, color: 'var(--mt)', marginTop: 4 }}>
          👤 {tgUser?.first_name || 'Foydalanuvchi'}
          {tgUser?.username ? ` · @${tgUser.username}` : ''}
        </div>
        <button onClick={() => onOpen('topup')} style={{
          marginTop: 14, background: 'linear-gradient(135deg,var(--gold),var(--gold2))',
          border: 'none', borderRadius: 11, padding: '9px 20px',
          color: '#000', fontFamily: 'Syne,sans-serif', fontSize: 12, fontWeight: 800, cursor: 'pointer'
        }}>+ To'ldirish</button>
      </div>

      {/* Xizmatlar */}
      <div style={{ margin: '14px 18px 0' }}>
        <div style={{ fontSize: 11, color: 'var(--mt)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 10 }}>
          Xizmatlar
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {SERVICES.filter(s => s.key !== 'topup').map(svc => (
            <div key={svc.key} onClick={() => onOpen(svc.key)} style={{
              background: 'var(--s1)', border: `1px solid ${svc.color}`,
              borderRadius: 16, padding: '16px', cursor: 'pointer',
              display: 'flex', flexDirection: 'column', gap: 6,
              transition: 'transform .15s',
              position: 'relative', overflow: 'hidden'
            }}>
              <div style={{
                position: 'absolute', top: -20, right: -20, width: 70, height: 70,
                background: svc.color, borderRadius: '50%', pointerEvents: 'none'
              }} />
              <div style={{ fontSize: 28 }}>{svc.icon}</div>
              <div style={{ fontWeight: 800, fontSize: 14 }}>{svc.label}</div>
              <div style={{ fontSize: 10, color: 'var(--mt)' }}>{svc.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tez havolalar */}
      <div style={{ margin: '14px 18px 0', display: 'flex', gap: 8 }}>
        {settings?.channel_link && (
          <a href={settings.channel_link} target="_blank" rel="noreferrer" style={{
            flex: 1, background: 'var(--s1)', border: '1px solid var(--bd)',
            borderRadius: 12, padding: '10px', textAlign: 'center',
            textDecoration: 'none', color: 'var(--mt)', fontSize: 11
          }}>📢 Kanal</a>
        )}
        {settings?.support_link && (
          <a href={settings.support_link} target="_blank" rel="noreferrer" style={{
            flex: 1, background: 'var(--s1)', border: '1px solid var(--bd)',
            borderRadius: 12, padding: '10px', textAlign: 'center',
            textDecoration: 'none', color: 'var(--mt)', fontSize: 11
          }}>💬 Support</a>
        )}
      </div>
    </div>
  )
}
