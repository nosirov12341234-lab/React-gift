import { useState, useEffect } from 'react'
import FullPage from '../components/FullPage.jsx'
import { getSmmServices, buySmmService } from '../api.js'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g, ' ')

const PLATFORMS = [
  { key: 'telegram', label: 'Telegram', emoji: '✈️', color: '#2AABEE' },
  { key: 'instagram', label: 'Instagram', emoji: '📸', color: '#E1306C' },
  { key: 'youtube', label: 'YouTube', emoji: '▶️', color: '#FF0000' },
  { key: 'tiktok', label: 'TikTok', emoji: '🎵', color: '#69C9D0' },
]

export default function SMM({ open, onClose, settings, showToast, uid, onBalanceUpdate }) {
  const [services, setServices] = useState({})
  const [loading, setLoading]   = useState(true)
  const [platform, setPlatform] = useState('telegram')
  const [sel, setSel]           = useState(null)
  const [link, setLink]         = useState('')
  const [qty, setQty]           = useState('')
  const [buying, setBuying]     = useState(false)

  useEffect(() => { if (open) load() }, [open])

  async function load() {
    setLoading(true)
    try {
      const r = await getSmmServices()
      if (r.success) setServices(r.services || {})
    } catch { }
    setLoading(false)
  }

  const list = services[platform] || []

  const price = sel && qty
    ? Math.round((parseInt(qty) || 0) / 1000 * (sel.price_per_1000 || 0))
    : 0

  async function buy() {
    if (!sel) { showToast("Xizmat tanlang!", 'err'); return }
    if (!link.trim()) { showToast("Link kiritilmagan!", 'err'); return }
    const q = parseInt(qty) || 0
    if (q < sel.min) { showToast(`Minimum ${sel.min} ta!`, 'err'); return }
    if (q > sel.max) { showToast(`Maximum ${sel.max} ta!`, 'err'); return }
    if ((settings.bal || 0) < price) { showToast("Balans yetarli emas!", 'err'); return }
    setBuying(true)
    try {
      const r = await buySmmService(uid, sel.id, link, q, price)
      if (r.success) {
        showToast("✅ Buyurtma qabul qilindi!", 'ok')
        onBalanceUpdate?.()
        onClose()
      } else showToast('❌ ' + r.error, 'err')
    } catch { showToast('❌ Xato', 'err') }
    setBuying(false)
  }

  function reset() { setSel(null); setLink(''); setQty('') }

  return (
    <FullPage open={open} onClose={() => { reset(); onClose() }} title="📊 SMM Xizmatlar">

      {/* Platform tanlash */}
      <div style={{ display: 'flex', gap: 6, padding: '14px 18px 0', overflowX: 'auto' }}>
        {PLATFORMS.map(p => (
          <button key={p.key} onClick={() => { setPlatform(p.key); setSel(null) }} style={{
            flexShrink: 0, padding: '8px 14px', borderRadius: 20,
            border: `1.5px solid ${platform === p.key ? p.color : 'var(--bd)'}`,
            background: platform === p.key ? `${p.color}18` : 'transparent',
            color: platform === p.key ? p.color : 'var(--mt)',
            fontSize: 12, fontWeight: 700, cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 4
          }}>
            {p.emoji} {p.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--mt)' }}>⏳ Yuklanmoqda...</div>
      ) : (
        <div style={{ padding: '12px 18px', display: 'flex', flexDirection: 'column', gap: 10 }}>

          {/* Xizmatlar ro'yxati */}
          {!sel && (
            <>
              <div style={{ fontSize: 12, color: 'var(--mt)' }}>Xizmat tanlang:</div>
              {list.length === 0 ? (
                <div style={{ textAlign: 'center', padding: 20, color: 'var(--mt)', fontSize: 12 }}>
                  Bu platform uchun xizmat topilmadi
                </div>
              ) : list.map(svc => (
                <div key={svc.id} onClick={() => setSel(svc)} style={{
                  background: 'var(--s1)', border: '1px solid var(--bd)',
                  borderRadius: 12, padding: '12px 14px', cursor: 'pointer',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  transition: 'border-color .2s'
                }}>
                  <div style={{ flex: 1, marginRight: 10 }}>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 2 }}>{svc.name}</div>
                    <div style={{ fontSize: 10, color: 'var(--mt)' }}>
                      Min: {svc.min} — Max: {fmt(svc.max)}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 12, fontWeight: 700, color: 'var(--gold)' }}>
                      {fmt(svc.price_per_1000)}
                    </div>
                    <div style={{ fontSize: 9, color: 'var(--mt)' }}>so'm/1000</div>
                  </div>
                </div>
              ))}
            </>
          )}

          {/* Buyurtma formasi */}
          {sel && (
            <>
              <button onClick={() => setSel(null)} style={{ background: 'none', border: 'none', color: 'var(--mt)', fontSize: 12, cursor: 'pointer', textAlign: 'left', padding: 0 }}>
                ← Orqaga
              </button>

              <div style={{ background: 'var(--s1)', border: '1px solid var(--gold)', borderRadius: 12, padding: '12px 14px' }}>
                <div style={{ fontSize: 11, fontWeight: 800, color: 'var(--gold)', marginBottom: 2 }}>{sel.name}</div>
                <div style={{ fontSize: 10, color: 'var(--mt)' }}>Min: {sel.min} — Max: {fmt(sel.max)}</div>
              </div>

              <div style={{ background: 'var(--s1)', border: '1px solid var(--bd)', borderRadius: 12, padding: '10px 14px' }}>
                <div style={{ fontSize: 10, color: 'var(--mt)', marginBottom: 4 }}>Link:</div>
                <input value={link} onChange={e => setLink(e.target.value)}
                  placeholder="https://t.me/kanal yoki @username"
                  style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', color: 'var(--tx)', fontFamily: 'Syne,sans-serif', fontSize: 13 }}
                />
              </div>

              <div style={{ background: 'var(--s1)', border: '1px solid var(--bd)', borderRadius: 12, padding: '10px 14px' }}>
                <div style={{ fontSize: 10, color: 'var(--mt)', marginBottom: 4 }}>Miqdor (min {sel.min}, max {fmt(sel.max)}):</div>
                <input type="number" value={qty} onChange={e => setQty(e.target.value)}
                  placeholder={String(sel.min)}
                  style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', color: 'var(--tx)', fontFamily: 'Syne,sans-serif', fontSize: 15 }}
                />
              </div>

              {/* Xulosa */}
              <div style={{ background: 'var(--s2)', border: '1px solid var(--bd)', borderRadius: 14, padding: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--mt)', marginBottom: 6 }}>
                  <span>Miqdor</span><span style={{ color: 'var(--tx)' }}>{qty || 0} ta</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--mt)', marginBottom: 6 }}>
                  <span>Narx (1000 ta)</span>
                  <span style={{ color: 'var(--tx)' }}>{fmt(sel.price_per_1000)} so'm</span>
                </div>
                <div style={{ borderTop: '1px solid var(--bd)', paddingTop: 8, display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 800 }}>Jami</span>
                  <span style={{ fontFamily: 'Space Mono,monospace', fontWeight: 800, color: 'var(--gold)', fontSize: 16 }}>
                    {fmt(price)} so'm
                  </span>
                </div>
              </div>

              <button onClick={buy} disabled={buying || !qty || !link} style={{
                background: 'linear-gradient(135deg,#2AABEE,#1a8fd1)',
                border: 'none', borderRadius: 14, padding: 14, color: '#fff',
                fontFamily: 'Syne,sans-serif', fontSize: 15, fontWeight: 800,
                cursor: 'pointer', opacity: buying || !qty || !link ? 0.5 : 1
              }}>
                {buying ? '⏳ Yuborilmoqda...' : '📊 Buyurtma berish'}
              </button>
            </>
          )}
        </div>
      )}
    </FullPage>
  )
}
