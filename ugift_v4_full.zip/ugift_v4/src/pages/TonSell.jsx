import { useState, useEffect } from 'react'
import FullPage from '../components/FullPage.jsx'
import { getTonRate, buyTon } from '../api.js'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g, ' ')

export default function TonSell({ open, onClose, settings, showToast, uid, onBalanceUpdate }) {
  const [currency, setCurrency] = useState('TON')
  const [rate, setRate]         = useState(null)
  const [loadRate, setLoadRate] = useState(true)
  const [amtUzs, setAmtUzs]    = useState('')
  const [wallet, setWallet]     = useState('')
  const [buying, setBuying]     = useState(false)

  useEffect(() => { if (open) loadRates() }, [open])
  useEffect(() => { if (open) loadRates() }, [currency, open])

  async function loadRates() {
    setLoadRate(true)
    try {
      const r = await getTonRate()
      if (r.success) setRate(r)
    } catch { }
    setLoadRate(false)
  }

  const rateNow = currency === 'TON' ? rate?.ton_uzs : rate?.usdt_uzs
  const cryptoAmt = rateNow && amtUzs ? (parseInt(amtUzs) / rateNow).toFixed(4) : '0'

  async function buy() {
    const uzs = parseInt(amtUzs) || 0
    if (uzs < 10000) { showToast("Minimum 10 000 so'm!", 'err'); return }
    if (!wallet.trim()) { showToast("Hamyon manzilini kiriting!", 'err'); return }
    if ((settings.bal || 0) < uzs) { showToast("Balans yetarli emas!", 'err'); return }
    setBuying(true)
    try {
      const r = await buyTon(uid, currency, uzs, parseFloat(cryptoAmt), wallet, rateNow)
      if (r.success) {
        showToast("✅ So'rov qabul qilindi!", 'ok')
        onBalanceUpdate?.()
        onClose()
      } else showToast('❌ ' + r.error, 'err')
    } catch { showToast('❌ Xato', 'err') }
    setBuying(false)
  }

  const AMTS = [50000, 100000, 200000, 500000]

  return (
    <FullPage open={open} onClose={onClose} title="💎 TON / USDT sotib olish">
      <div style={{ padding: '14px 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>

        {/* Valyuta tanlash */}
        <div style={{ display: 'flex', gap: 8 }}>
          {['TON', 'USDT'].map(c => (
            <div key={c} onClick={() => setCurrency(c)} style={{
              flex: 1, textAlign: 'center', padding: '12px',
              background: currency === c ? 'rgba(124,92,252,.1)' : 'var(--s1)',
              border: `1.5px solid ${currency === c ? 'var(--pur)' : 'var(--bd)'}`,
              borderRadius: 14, cursor: 'pointer'
            }}>
              <div style={{ fontSize: 24, marginBottom: 4 }}>{c === 'TON' ? '💎' : '💵'}</div>
              <div style={{ fontSize: 13, fontWeight: 800, color: currency === c ? 'var(--pur2)' : 'var(--tx)' }}>{c}</div>
              {loadRate ? (
                <div style={{ fontSize: 10, color: 'var(--mt)' }}>...</div>
              ) : (
                <div style={{ fontSize: 10, color: 'var(--mt)', marginTop: 2 }}>
                  1 {c} = {fmt(c === 'TON' ? rate?.ton_uzs : rate?.usdt_uzs)} so'm
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Kurs ma'lumoti */}
        {rate && (
          <div style={{
            background: 'rgba(124,92,252,.05)', border: '1px solid rgba(124,92,252,.2)',
            borderRadius: 12, padding: '10px 14px', fontSize: 11, color: 'var(--mt)',
            display: 'flex', justifyContent: 'space-between'
          }}>
            <span>📈 Bozor kursi</span>
            <span style={{ color: 'var(--tx)' }}>
              1 {currency} = {fmt(currency === 'TON' ? rate.ton_uzs_raw : rate.usdt_uzs_raw)} so'm
            </span>
          </div>
        )}

        {/* Tez tanlash */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          {AMTS.map(a => (
            <div key={a} onClick={() => setAmtUzs(String(a))} style={{
              background: amtUzs === String(a) ? 'rgba(124,92,252,.08)' : 'var(--s1)',
              border: `1.5px solid ${amtUzs === String(a) ? 'var(--pur)' : 'var(--bd)'}`,
              borderRadius: 12, padding: '8px', textAlign: 'center', cursor: 'pointer'
            }}>
              <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 11, fontWeight: 700, color: 'var(--pur2)' }}>
                {fmt(a)} so'm
              </div>
              {rateNow && (
                <div style={{ fontSize: 9, color: 'var(--mt)', marginTop: 2 }}>
                  ≈ {(a / rateNow).toFixed(4)} {currency}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* So'm kiriting */}
        <div style={{ background: 'var(--s1)', border: '1px solid var(--bd)', borderRadius: 12, padding: '10px 14px' }}>
          <div style={{ fontSize: 10, color: 'var(--mt)', marginBottom: 4 }}>Miqdor (so'mda):</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <input type="number" value={amtUzs} onChange={e => setAmtUzs(e.target.value)}
              placeholder="100000"
              style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: 'var(--tx)', fontFamily: 'Syne,sans-serif', fontSize: 16 }}
            />
            <span style={{ color: 'var(--mt)', fontSize: 12 }}>so'm</span>
          </div>
        </div>

        {/* Crypto miqdori */}
        {amtUzs && rateNow && (
          <div style={{
            background: 'rgba(124,92,252,.05)', border: '1px solid rgba(124,92,252,.2)',
            borderRadius: 12, padding: '12px 14px', textAlign: 'center'
          }}>
            <div style={{ fontSize: 11, color: 'var(--mt)', marginBottom: 4 }}>Olasiz:</div>
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 24, fontWeight: 700, color: 'var(--pur2)' }}>
              {cryptoAmt} {currency}
            </div>
          </div>
        )}

        {/* Hamyon */}
        <div style={{ background: 'var(--s1)', border: '1px solid var(--bd)', borderRadius: 12, padding: '10px 14px' }}>
          <div style={{ fontSize: 10, color: 'var(--mt)', marginBottom: 4 }}>
            {currency === 'TON' ? 'TON' : 'USDT TRC20'} hamyon manzili:
          </div>
          <input value={wallet} onChange={e => setWallet(e.target.value)}
            placeholder={currency === 'TON' ? 'UQ...' : 'T...'}
            style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', color: 'var(--tx)', fontFamily: 'Space Mono,monospace', fontSize: 12 }}
          />
        </div>

        {/* Ogohlantirish */}
        <div style={{
          background: 'rgba(245,200,66,.05)', border: '1px solid rgba(245,200,66,.15)',
          borderRadius: 12, padding: '10px 14px', fontSize: 11, color: 'var(--mt)', lineHeight: 1.7
        }}>
          ⚡ So'rov admin tomonidan 1-2 soat ichida bajariladi<br />
          🔒 Hamyon manzilini to'g'ri kiriting
        </div>

        <button onClick={buy} disabled={buying || !amtUzs || !wallet} style={{
          background: 'linear-gradient(135deg,var(--pur),#5b3fd8)',
          border: 'none', borderRadius: 14, padding: 14, color: '#fff',
          fontFamily: 'Syne,sans-serif', fontSize: 15, fontWeight: 800,
          cursor: 'pointer', opacity: buying || !amtUzs || !wallet ? 0.5 : 1
        }}>
          {buying ? '⏳...' : `💎 ${cryptoAmt} ${currency} sotib olish`}
        </button>
      </div>
    </FullPage>
  )
}
