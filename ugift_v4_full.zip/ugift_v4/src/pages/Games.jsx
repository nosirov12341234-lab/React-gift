import { useState, useEffect } from 'react'
import FullPage from '../components/FullPage.jsx'
import { getGames } from '../api.js'

export default function Games({ open, onClose, settings, showToast }) {
  const [games, setGames] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { if (open) load() }, [open])

  async function load() {
    setLoading(true)
    try { const r = await getGames(); setGames(r.games || []) } catch {}
    setLoading(false)
  }

  function openSupport() {
    const link = settings?.supportLink || settings?.support_link || ''
    if (link && window.Telegram?.WebApp) window.Telegram.WebApp.openLink(link)
    else showToast("Support linki sozlanmagan", 'err')
  }

  return (
    <FullPage open={open} onClose={onClose} title="🎮 O'yin Donatlari">
      <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>

        <div style={{
          background: 'rgba(245,200,66,.05)', border: '1px solid rgba(245,200,66,.2)',
          borderRadius: 14, padding: '14px', fontSize: 12, color: 'var(--mt)', lineHeight: 1.8
        }}>
          🎮 O'yin donatlari <b style={{ color: 'var(--gold)' }}>qo'lda bajariladi</b><br />
          ⚡ Odatda <b style={{ color: 'var(--tx)' }}>5-30 daqiqa</b> ichida<br />
          💬 Buyurtma berish uchun adminga yozing
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: 20, color: 'var(--mt)' }}>⏳ Yuklanmoqda...</div>
        ) : games.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 20, color: 'var(--mt)', fontSize: 12 }}>
            Hozircha o'yinlar qo'shilmagan
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ fontSize: 12, color: 'var(--mt)' }}>Mavjud o'yinlar:</div>
            {games.map((g, i) => (
              <div key={i} style={{
                background: 'var(--s1)', border: '1px solid var(--bd)',
                borderRadius: 14, padding: '14px 16px',
                display: 'flex', alignItems: 'center', gap: 12
              }}>
                <div style={{ fontSize: 28 }}>{g.emoji}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{g.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--mt)', marginTop: 2 }}>
                    Adminga murojaat qiling
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <button onClick={openSupport} style={{
          background: 'linear-gradient(135deg,var(--pur),#5b3fd8)',
          border: 'none', borderRadius: 14, padding: 14, color: '#fff',
          fontFamily: 'Syne,sans-serif', fontSize: 15, fontWeight: 800,
          cursor: 'pointer', marginTop: 4
        }}>
          👨‍💼 Adminga murojaat
        </button>
      </div>
    </FullPage>
  )
}
