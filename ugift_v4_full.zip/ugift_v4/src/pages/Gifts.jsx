import { useState, useEffect } from 'react'
import FullPage from '../components/FullPage.jsx'
import { getGifts, buyGift } from '../api.js'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g, ' ')

export default function Gifts({ open, onClose, settings, showToast, uid, tgUser, onBalanceUpdate }) {
  const [gifts, setGifts]     = useState([])
  const [loading, setLoading] = useState(true)
  const [sel, setSel]         = useState(null)
  const [recip, setRecip]     = useState('self')
  const [uname, setUname]     = useState('')
  const [buying, setBuying]   = useState(false)

  useEffect(() => {
    if (open) loadGifts()
  }, [open])

  async function loadGifts() {
    setLoading(true)
    try {
      const r = await getGifts()
      setGifts((r.gifts || []).filter(g => g.available))
    } catch { }
    setLoading(false)
  }

  async function buy() {
    if (!sel) { showToast("Gift tanlang!", 'err'); return }
    const username = recip === 'self' ? (tgUser?.username || '') : uname.replace('@', '')
    if (!username) { showToast("Username kiritilmagan!", 'err'); return }
    if ((settings.bal || 0) < sel.price) { showToast("Balans yetarli emas!", 'err'); return }
    setBuying(true)
    try {
      const r = await buyGift(uid, sel.id, username)
      if (r.success) {
        showToast("🎁 Gift yuborildi!", 'ok')
        onBalanceUpdate?.()
        onClose()
      } else showToast('❌ ' + r.error, 'err')
    } catch { showToast('❌ Xato', 'err') }
    setBuying(false)
  }

  function reset() { setSel(null); setRecip('self'); setUname('') }

  return (
    <FullPage open={open} onClose={() => { reset(); onClose() }} title="🎁 Telegram Giftlar">

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--mt)' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>⏳</div>
          Yuklanmoqda...
        </div>
      ) : gifts.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--mt)' }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>🎁</div>
          Hozircha mavjud gift yo'q
        </div>
      ) : (
        <div style={{ padding: '14px 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>

          {/* Gift tanlash */}
          <div style={{ fontSize: 12, color: 'var(--mt)' }}>Gift tanlang:</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {gifts.map(g => (
              <div key={g.id} onClick={() => setSel(g)} style={{
                background: sel?.id === g.id ? 'rgba(245,200,66,.08)' : 'var(--s1)',
                border: `1.5px solid ${sel?.id === g.id ? 'var(--gold)' : 'var(--bd)'}`,
                borderRadius: 14, padding: '12px 10px', textAlign: 'center',
                cursor: 'pointer', transition: 'all .2s', position: 'relative'
              }}>
                {g.remaining_count && g.remaining_count < 100 && (
                  <div style={{
                    position: 'absolute', top: -8, right: -4,
                    background: 'var(--red)', color: '#fff',
                    fontSize: 8, fontWeight: 800, padding: '2px 6px',
                    borderRadius: 20
                  }}>Kam qoldi</div>
                )}
                <div style={{ fontSize: 32, marginBottom: 4 }}>🎁</div>
                <div style={{ fontSize: 10, color: 'var(--mt)', marginBottom: 4 }}>
                  {g.star_count} ⭐
                </div>
                <div style={{
                  fontFamily: 'Space Mono,monospace', fontSize: 13,
                  fontWeight: 700, color: 'var(--gold)'
                }}>{fmt(g.price)}</div>
                <div style={{ fontSize: 9, color: 'var(--mt)' }}>so'm</div>
              </div>
            ))}
          </div>

          {/* Kimga */}
          {sel && (
            <>
              <div style={{ fontSize: 12, color: 'var(--mt)', marginTop: 4 }}>Kimga yuborilsin:</div>
              <div style={{ display: 'flex', gap: 8 }}>
                {['self', 'other'].map(v => (
                  <div key={v} onClick={() => setRecip(v)} style={{
                    flex: 1, textAlign: 'center', padding: '10px',
                    background: recip === v ? 'rgba(245,200,66,.08)' : 'var(--s1)',
                    border: `1.5px solid ${recip === v ? 'var(--gold)' : 'var(--bd)'}`,
                    borderRadius: 12, cursor: 'pointer', fontSize: 12, fontWeight: 700,
                    color: recip === v ? 'var(--gold)' : 'var(--tx)'
                  }}>
                    {v === 'self' ? '👤 O\'zim' : '👥 Boshqa'}
                  </div>
                ))}
              </div>

              {recip === 'other' && (
                <div style={{ background: 'var(--s1)', border: '1px solid var(--bd)', borderRadius: 12, padding: '10px 14px' }}>
                  <div style={{ fontSize: 10, color: 'var(--mt)', marginBottom: 4 }}>Username:</div>
                  <input
                    value={uname} onChange={e => setUname(e.target.value)}
                    placeholder="@username"
                    style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', color: 'var(--tx)', fontFamily: 'Syne,sans-serif', fontSize: 14 }}
                  />
                </div>
              )}

              {/* Xulosa */}
              <div style={{ background: 'var(--s2)', border: '1px solid var(--bd)', borderRadius: 14, padding: '14px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--mt)', marginBottom: 8 }}>
                  <span>Gift</span><span style={{ color: 'var(--tx)' }}>🎁 {sel.star_count} ⭐</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--mt)', marginBottom: 8 }}>
                  <span>Kimga</span>
                  <span style={{ color: 'var(--tx)' }}>
                    {recip === 'self' ? tgUser?.first_name || 'O\'zim' : uname || '—'}
                  </span>
                </div>
                <div style={{ borderTop: '1px solid var(--bd)', paddingTop: 8, display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 800 }}>Jami</span>
                  <span style={{ fontFamily: 'Space Mono,monospace', fontWeight: 800, color: 'var(--gold)', fontSize: 16 }}>
                    {fmt(sel.price)} so'm
                  </span>
                </div>
              </div>

              <button onClick={buy} disabled={buying} style={{
                background: 'linear-gradient(135deg,var(--gold),var(--gold2))',
                border: 'none', borderRadius: 14, padding: 14, color: '#000',
                fontFamily: 'Syne,sans-serif', fontSize: 15, fontWeight: 800,
                cursor: 'pointer', opacity: buying ? 0.6 : 1
              }}>
                {buying ? '⏳ Yuborilmoqda...' : '🎁 Gift yuborish'}
              </button>
            </>
          )}
        </div>
      )}
    </FullPage>
  )
}
