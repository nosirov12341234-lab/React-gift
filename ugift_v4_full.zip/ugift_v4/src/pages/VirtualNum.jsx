import { useState, useEffect, useRef } from 'react'
import FullPage from '../components/FullPage.jsx'
import { getVnumCountries, buyVnum, getSms } from '../api.js'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g, ' ')

export default function VirtualNum({ open, onClose, settings, showToast, uid, onBalanceUpdate }) {
  const [countries, setCountries] = useState([])
  const [loading, setLoading]     = useState(true)
  const [search, setSearch]       = useState('')
  const [sel, setSel]             = useState(null)
  const [buying, setBuying]       = useState(false)
  const [numInfo, setNumInfo]     = useState(null) // { number, request_id }
  const [smsCode, setSmsCode]     = useState(null)
  const [secs, setSecs]           = useState(600)
  const timerRef                  = useRef(null)

  useEffect(() => { if (open) load() }, [open])

  useEffect(() => {
    if (!numInfo) return
    setSecs(600)
    timerRef.current = setInterval(() => {
      setSecs(p => {
        if (p <= 1) { clearInterval(timerRef.current); return 0 }
        return p - 1
      })
    }, 1000)
    // SMS ni har 5 sekundda tekshirish
    const smsTimer = setInterval(async () => {
      if (!numInfo?.request_id) return
      const r = await getSms(numInfo.request_id)
      if (r.success && r.code) {
        setSmsCode(r.code)
        clearInterval(smsTimer)
        clearInterval(timerRef.current)
      }
    }, 5000)
    return () => { clearInterval(timerRef.current); clearInterval(smsTimer) }
  }, [numInfo])

  async function load() {
    setLoading(true)
    try {
      const r = await getVnumCountries()
      setCountries(r.countries || [])
    } catch { }
    setLoading(false)
  }

  async function buy() {
    if (!sel) return
    if ((settings.bal || 0) < sel.price) { showToast("Balans yetarli emas!", 'err'); return }
    setBuying(true)
    try {
      const r = await buyVnum(uid, sel.id, sel.price)
      if (r.success) {
        setNumInfo({ number: r.number, request_id: r.request_id })
        onBalanceUpdate?.()
      } else showToast('❌ ' + r.error, 'err')
    } catch { showToast('❌ Xato', 'err') }
    setBuying(false)
  }

  function reset() { setSel(null); setNumInfo(null); setSmsCode(null); setSearch('') }

  const filtered = countries.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase())
  )

  const m = Math.floor(secs / 60)
  const s = secs % 60

  return (
    <FullPage open={open} onClose={() => { reset(); onClose() }} title="📱 Virtual Raqam">

      {/* SMS keldi */}
      {smsCode && (
        <div style={{ padding: '20px 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 8 }}>✅</div>
            <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--green)' }}>SMS kodi keldi!</div>
          </div>
          <div style={{ background: 'var(--s1)', border: '1.5px solid var(--green)', borderRadius: 16, padding: '20px', textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'var(--mt)', marginBottom: 8 }}>Tasdiqlash kodi:</div>
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 32, fontWeight: 700, color: 'var(--green)', letterSpacing: 4 }}>
              {smsCode}
            </div>
            <div style={{ fontSize: 11, color: 'var(--mt)', marginTop: 8 }}>Raqam: {numInfo?.number}</div>
          </div>
          <button onClick={() => { if (navigator.clipboard) navigator.clipboard.writeText(smsCode).then(() => showToast('✅ Nusxalandi!', 'ok')) }} style={{
            background: 'var(--s1)', border: '1px solid var(--green)',
            borderRadius: 14, padding: 12, color: 'var(--green)',
            fontFamily: 'Syne,sans-serif', fontSize: 13, fontWeight: 700, cursor: 'pointer'
          }}>📋 Kodni nusxalash</button>
          <button onClick={() => { reset(); onClose() }} style={{
            background: 'transparent', border: '1px solid var(--bd)',
            borderRadius: 14, padding: 12, color: 'var(--mt)',
            fontFamily: 'Syne,sans-serif', fontSize: 13, cursor: 'pointer'
          }}>← Yopish</button>
        </div>
      )}

      {/* Raqam olindi, SMS kutilmoqda */}
      {numInfo && !smsCode && (
        <div style={{ padding: '20px 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 8 }}>📱</div>
            <div style={{ fontSize: 14, fontWeight: 800 }}>Raqam tayyor!</div>
            <div style={{ fontSize: 12, color: 'var(--mt)', marginTop: 4 }}>SMS kutilmoqda...</div>
          </div>
          <div style={{ background: 'var(--s1)', border: '1.5px solid var(--gold)', borderRadius: 16, padding: '16px', textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'var(--mt)', marginBottom: 6 }}>Telegram raqami:</div>
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 20, fontWeight: 700, color: 'var(--gold)' }}>
              {numInfo.number}
            </div>
            <button onClick={() => { if (navigator.clipboard) navigator.clipboard.writeText(numInfo.number).then(() => showToast('✅ Nusxalandi!', 'ok')) }}
              style={{ marginTop: 8, background: 'rgba(245,200,66,0.1)', border: '1px solid var(--gold)', borderRadius: 8, padding: '4px 12px', color: 'var(--gold)', fontSize: 11, cursor: 'pointer' }}>
              📋 Nusxalash
            </button>
          </div>
          <div style={{ background: 'rgba(34,211,165,0.05)', border: '1px solid rgba(34,211,165,0.2)', borderRadius: 12, padding: '12px', textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'var(--mt)', marginBottom: 4 }}>Qolgan vaqt:</div>
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 24, fontWeight: 700, color: secs < 60 ? 'var(--red)' : 'var(--green)' }}>
              {String(m).padStart(2, '0')}:{String(s).padStart(2, '0')}
            </div>
            <div style={{ fontSize: 10, color: 'var(--mt)', marginTop: 4 }}>SMS avtomatik aniqlanadi</div>
          </div>
          <div style={{ background: 'rgba(245,200,66,.05)', border: '1px solid rgba(245,200,66,.15)', borderRadius: 12, padding: '10px 14px', fontSize: 11, color: 'var(--mt)', lineHeight: 1.7 }}>
            1️⃣ Telegram da bu raqamni kiriting<br />
            2️⃣ SMS kod yuboring<br />
            3️⃣ Kod bu yerda avtomatik chiqadi ✅
          </div>
        </div>
      )}

      {/* Davlat tanlash */}
      {!numInfo && !smsCode && (
        <div style={{ padding: '14px 18px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ background: 'var(--s1)', border: '1px solid var(--bd)', borderRadius: 12, padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ color: 'var(--mt)' }}>🔍</span>
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Davlat qidirish..."
              style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: 'var(--tx)', fontFamily: 'Syne,sans-serif', fontSize: 13 }}
            />
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: 20, color: 'var(--mt)' }}>⏳ Yuklanmoqda...</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxHeight: 350, overflowY: 'auto' }}>
              {filtered.map(c => (
                <div key={c.id} onClick={() => setSel(c)} style={{
                  background: sel?.id === c.id ? 'rgba(245,200,66,.08)' : 'var(--s1)',
                  border: `1.5px solid ${sel?.id === c.id ? 'var(--gold)' : 'var(--bd)'}`,
                  borderRadius: 12, padding: '12px 14px', cursor: 'pointer',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center'
                }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700 }}>{c.name}</div>
                    <div style={{ fontSize: 10, color: 'var(--mt)' }}>Mavjud: {c.count} ta</div>
                  </div>
                  <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 13, fontWeight: 700, color: 'var(--gold)' }}>
                    {fmt(c.price)} so'm
                  </div>
                </div>
              ))}
            </div>
          )}

          {sel && (
            <>
              <div style={{ background: 'rgba(245,200,66,.05)', border: '1px solid rgba(245,200,66,.15)', borderRadius: 12, padding: '10px 14px', fontSize: 11, color: 'var(--mt)', lineHeight: 1.7 }}>
                📱 Faqat <b style={{ color: 'var(--gold)' }}>Telegram</b> uchun raqam<br />
                ⏰ SMS kodi 10 daqiqa ichida keladi
              </div>
              <button onClick={buy} disabled={buying} style={{
                background: 'linear-gradient(135deg,var(--gold),var(--gold2))',
                border: 'none', borderRadius: 14, padding: 14, color: '#000',
                fontFamily: 'Syne,sans-serif', fontSize: 15, fontWeight: 800,
                cursor: 'pointer', opacity: buying ? 0.6 : 1
              }}>
                {buying ? '⏳...' : `📱 Raqam olish — ${fmt(sel.price)} so'm`}
              </button>
            </>
          )}
        </div>
      )}
    </FullPage>
  )
}
