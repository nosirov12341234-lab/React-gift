import { useState, useEffect } from 'react'
import FullPage from '../components/FullPage.jsx'
import { createCardTopup } from '../api.js'

const AMTS = [10000, 25000, 50000, 100000, 200000, 500000]

// 50000 so'm + 37 tiyin → "50 000,37"
function fmtUnique(som, tiyin) {
  const s = Math.round(som).toLocaleString('ru-RU').replace(/\s/g, ' ')
  const t = String(tiyin).padStart(2, '0')
  return `${s},${t}`
}

function fmt(n) {
  return Math.round(n).toLocaleString('ru-RU').replace(/\s/g, ' ')
}

// Taymer: qolgan soniyalarni ko'rsatadi
function Countdown({ seconds }) {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  const pct = (seconds / (15 * 60)) * 100
  const danger = seconds < 120
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{
        width: 80, height: 80, borderRadius: '50%', margin: '0 auto 8px',
        background: `conic-gradient(${danger ? '#ff4444' : 'var(--gold)'} ${pct * 3.6}deg, rgba(255,255,255,0.05) 0deg)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative'
      }}>
        <div style={{
          width: 64, height: 64, borderRadius: '50%',
          background: '#0f1525',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexDirection: 'column'
        }}>
          <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 16, fontWeight: 700, color: danger ? '#ff4444' : 'var(--gold)', lineHeight: 1 }}>
            {String(m).padStart(2, '0')}:{String(s).padStart(2, '0')}
          </div>
        </div>
      </div>
      <div style={{ fontSize: 11, color: danger ? '#ff4444' : 'var(--mt)' }}>
        {danger ? '⚠️ Vaqt tugayapti!' : '⏰ Qolgan vaqt'}
      </div>
    </div>
  )
}

export default function TopUp({ open, onClose, settings, showToast, uid }) {
  const [method, setMethod]   = useState(null)
  const [selAmt, setSelAmt]   = useState(null)
  const [custom, setCustom]   = useState('')
  const [cardInfo, setCardInfo] = useState(null)
  const [loading, setLoad]    = useState(false)
  const [secs, setSecs]       = useState(15 * 60)
  const [copied, setCopied]   = useState(false)

  const finalAmt = selAmt || (parseInt(custom) || 0)
  const support  = settings?.supportLink || ''

  // Taymer
  useEffect(() => {
    if (!cardInfo) return
    setSecs(15 * 60)
    const id = setInterval(() => {
      setSecs(prev => {
        if (prev <= 1) { clearInterval(id); return 0 }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(id)
  }, [cardInfo])

  async function autoTopup() {
    if (finalAmt < 5000) { showToast("Minimum 5 000 so'm!", 'err'); return }
    setLoad(true)
    try {
      const r = await createCardTopup(uid, finalAmt)
      if (r.success) {
        setCardInfo(r)
      } else {
        showToast('❌ ' + (r.error || 'Xato'), 'err')
      }
    } catch { showToast('❌ Xato', 'err') }
    setLoad(false)
  }

  function copySum() {
    const val = `${cardInfo.amount_som},${String(cardInfo.tiyin).padStart(2,'0')}`
    if (navigator.clipboard) {
      navigator.clipboard.writeText(val).then(() => {
        setCopied(true)
        showToast('✅ Summa nusxalandi!', 'ok')
        setTimeout(() => setCopied(false), 2000)
      })
    }
  }

  function copyCard() {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(cardInfo.card.replace(/\s/g, ''))
        .then(() => showToast('✅ Karta nusxalandi!', 'ok'))
    }
  }

  function reset() {
    setMethod(null); setCardInfo(null)
    setSelAmt(null); setCustom(''); setSecs(15 * 60)
  }

  return (
    <FullPage open={open} onClose={() => { reset(); onClose() }} title="💰 Hisob To'ldirish">

      {/* ── USUL TANLASH ── */}
      {!method && !cardInfo && (
        <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ fontSize: 12, color: 'var(--mt)', marginBottom: 2 }}>To'lov usulini tanlang:</div>

          <div onClick={() => setMethod('auto')} style={{
            background: 'var(--s1)', border: '1.5px solid var(--gold)',
            borderRadius: 16, padding: '16px', cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 12
          }}>
            <div style={{ fontSize: 28 }}>💳</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 800, fontSize: 14, color: 'var(--gold)' }}>Avtomatik (Karta)</div>
              <div style={{ fontSize: 11, color: 'var(--mt)', marginTop: 3 }}>Summani kiriting → kartaga to'lang → avtomatik tasdiqlanadi</div>
            </div>
            <span style={{ color: 'var(--gold)' }}>›</span>
          </div>

          <div onClick={() => setMethod('screen')} style={{
            background: 'var(--s1)', border: '1px solid var(--bd)',
            borderRadius: 16, padding: '16px', cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 12
          }}>
            <div style={{ fontSize: 28 }}>📸</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 800, fontSize: 14 }}>Screenshot orqali</div>
              <div style={{ fontSize: 11, color: 'var(--mt)', marginTop: 3 }}>Kartaga to'lang → screenshot yuboring → admin tasdiqlaydi</div>
            </div>
            <span style={{ color: 'var(--mt)' }}>›</span>
          </div>

          {support && (
            <div onClick={() => { const tg = window.Telegram?.WebApp; if (tg) tg.openLink(support) }} style={{
              background: 'var(--s1)', border: '1px solid var(--bd)',
              borderRadius: 16, padding: '16px', cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 12
            }}>
              <div style={{ fontSize: 28 }}>👨‍💼</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 800, fontSize: 14 }}>Admin orqali</div>
                <div style={{ fontSize: 11, color: 'var(--mt)', marginTop: 3 }}>Admin bilan bog'laning</div>
              </div>
              <span style={{ color: 'var(--mt)' }}>›</span>
            </div>
          )}
        </div>
      )}

      {/* ── SUMMA TANLASH ── */}
      {method === 'auto' && !cardInfo && (
        <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <button onClick={() => setMethod(null)} style={{ background: 'none', border: 'none', color: 'var(--mt)', fontSize: 12, cursor: 'pointer', textAlign: 'left', padding: 0 }}>← Orqaga</button>
          <div style={{ fontSize: 13, fontWeight: 700 }}>💳 Avtomatik to'ldirish</div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            {AMTS.map(a => (
              <div key={a} onClick={() => { setSelAmt(a); setCustom('') }} style={{
                background: selAmt === a && !custom ? 'rgba(245,200,66,.08)' : 'var(--s1)',
                border: `1.5px solid ${selAmt === a && !custom ? 'var(--gold)' : 'var(--bd)'}`,
                borderRadius: 12, padding: '10px 6px', textAlign: 'center', cursor: 'pointer'
              }}>
                <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 12, fontWeight: 700, color: 'var(--gold)' }}>{fmt(a)}</div>
                <div style={{ fontSize: 9, color: 'var(--mt)' }}>so'm</div>
              </div>
            ))}
          </div>

          <div style={{ background: 'var(--s1)', border: '1px solid var(--bd)', borderRadius: 12, padding: '10px 14px' }}>
            <div style={{ fontSize: 10, color: 'var(--mt)', marginBottom: 4 }}>Yoki kiriting (min 5 000):</div>
            <input type="number" value={custom}
              onChange={e => { setCustom(e.target.value); setSelAmt(null) }}
              placeholder="75000"
              style={{ width: '100%', background: 'transparent', border: 'none', outline: 'none', color: 'var(--tx)', fontFamily: 'Syne,sans-serif', fontSize: 15 }}
            />
          </div>

          <div style={{
            background: 'rgba(245,200,66,.05)', border: '1px solid rgba(245,200,66,.15)',
            borderRadius: 12, padding: '10px 12px', fontSize: 11, color: 'var(--mt)', lineHeight: 1.6
          }}>
            ⚠️ <b style={{ color: 'var(--gold)' }}>Muhim!</b> Tiyin bilan birga <b style={{ color: 'var(--tx)' }}>aniq summani</b> nusxalab to'lang. Farq bo'lsa to'lov aniqlanmaydi.
          </div>

          <button onClick={autoTopup} disabled={loading || finalAmt < 5000} style={{
            background: 'linear-gradient(135deg,var(--gold),var(--gold2))',
            border: 'none', borderRadius: 14, padding: 14, color: '#000',
            fontFamily: 'Syne,sans-serif', fontSize: 14, fontWeight: 800, cursor: 'pointer',
            opacity: loading || finalAmt < 5000 ? 0.5 : 1
          }}>{loading ? '⏳...' : "💳 Karta ma'lumotlarini olish"}</button>
        </div>
      )}

      {/* ── KARTA MA'LUMOTLARI + TAYMER ── */}
      {cardInfo && (
        <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>

          {/* Taymer */}
          <Countdown seconds={secs} />

          {/* Karta kartochkasi */}
          <div style={{
            background: 'linear-gradient(135deg,#1e1a3a,#0f1525)',
            border: '1px solid rgba(245,200,66,0.25)',
            borderRadius: 20, padding: '20px'
          }}>
            {/* Karta raqami */}
            <div style={{ fontSize: 11, color: 'var(--mt)', marginBottom: 4 }}>Karta raqami:</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
              <div style={{
                fontFamily: 'Space Mono,monospace', fontSize: 17, fontWeight: 700,
                color: 'var(--gold)', letterSpacing: 2, flex: 1
              }}>{cardInfo.card}</div>
              <button onClick={copyCard} style={{
                background: 'rgba(245,200,66,0.1)', border: '1px solid rgba(245,200,66,0.3)',
                borderRadius: 8, padding: '4px 10px', color: 'var(--gold)',
                fontSize: 11, cursor: 'pointer', fontFamily: 'Syne,sans-serif'
              }}>📋</button>
            </div>
            <div style={{ fontSize: 11, color: 'var(--mt)', marginBottom: 16 }}>{cardInfo.holder}</div>

            {/* Summa bloki */}
            <div style={{
              background: 'rgba(0,0,0,0.35)', borderRadius: 14, padding: '14px', textAlign: 'center'
            }}>
              <div style={{ fontSize: 11, color: 'var(--mt)', marginBottom: 6 }}>
                ⚠️ Aynan shu summani yuboring:
              </div>
              <div style={{
                fontFamily: 'Space Mono,monospace', fontSize: 26, fontWeight: 700, color: 'var(--gold)', lineHeight: 1
              }}>
                {fmtUnique(cardInfo.amount_som, cardInfo.tiyin)}
              </div>
              <div style={{ fontSize: 12, color: 'var(--mt)', marginTop: 4 }}>so'm</div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)', marginTop: 8 }}>
                Tiyin bilan birga aniq nusxalang
              </div>
            </div>
          </div>

          {/* Summa nusxalash tugmasi */}
          <button onClick={copySum} style={{
            background: copied ? 'rgba(0,200,100,0.1)' : 'var(--s1)',
            border: `1px solid ${copied ? '#00c864' : 'var(--gold)'}`,
            borderRadius: 14, padding: 13, color: copied ? '#00c864' : 'var(--gold)',
            fontFamily: 'Syne,sans-serif', fontSize: 13, fontWeight: 700, cursor: 'pointer',
            transition: 'all 0.2s'
          }}>
            {copied ? '✅ Nusxalandi!' : '📋 Summani nusxalash'}
          </button>

          {/* Ogohlantirish */}
          <div style={{
            background: 'rgba(255,68,68,0.06)', border: '1px solid rgba(255,68,68,0.2)',
            borderRadius: 12, padding: '10px 14px', fontSize: 11, color: '#ff8888', lineHeight: 1.7
          }}>
            🔴 <b>Eslatma:</b> Tiyingacha aniq summani yuboring.<br/>
            ⏰ {cardInfo.wait_minutes} daqiqa ichida to'lanmasa so'rov bekor bo'ladi.
          </div>

          <button onClick={reset} style={{
            background: 'transparent', border: '1px solid var(--bd)',
            borderRadius: 14, padding: 12, color: 'var(--mt)',
            fontFamily: 'Syne,sans-serif', fontSize: 13, cursor: 'pointer'
          }}>← Orqaga</button>
        </div>
      )}

      {/* ── SCREENSHOT ── */}
      {method === 'screen' && (
        <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <button onClick={() => setMethod(null)} style={{ background: 'none', border: 'none', color: 'var(--mt)', fontSize: 12, cursor: 'pointer', textAlign: 'left', padding: 0 }}>← Orqaga</button>
          <div style={{ fontSize: 13, fontWeight: 700 }}>📸 Screenshot orqali</div>
          <div style={{ background: 'var(--s1)', border: '1px solid var(--bd)', borderRadius: 14, padding: '14px', fontSize: 12, lineHeight: 1.8, color: 'var(--mt)' }}>
            1️⃣ Kartaga pul yuboring<br />
            2️⃣ Botga <b style={{ color: 'var(--tx)' }}>/tolov</b> buyrug'ini yuboring<br />
            3️⃣ "📸 Screenshot orqali" ni tanlang<br />
            4️⃣ Summani kiriting<br />
            5️⃣ Screenshot yuboring → Admin tasdiqlaydi ✅
          </div>
          <button onClick={() => { const tg = window.Telegram?.WebApp; if (tg) tg.close() }} style={{
            background: 'linear-gradient(135deg,var(--pur),#5b3fd8)',
            border: 'none', borderRadius: 14, padding: 14, color: '#fff',
            fontFamily: 'Syne,sans-serif', fontSize: 14, fontWeight: 800, cursor: 'pointer'
          }}>🤖 Botga o'tish → /tolov</button>
        </div>
      )}

    </FullPage>
  )
}
