const BASE = ''

// ─── Asosiy ────────────────────────────────────────────────────
export async function getSettings(uid) {
  const r = await fetch(`${BASE}/api/settings?uid=${uid}`)
  return r.json()
}
export async function checkPromo(code, uid, product) {
  const r = await fetch(`${BASE}/api/promo/check`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code, uid, product })
  })
  return r.json()
}
export async function createCardTopup(uid, amount) {
  const r = await fetch(`${BASE}/api/topup/card`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid, amount })
  })
  return r.json()
}
export async function buyService(uid, service, username, price, stars, months, promo) {
  const r = await fetch(`${BASE}/api/buy`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid, service, username, price, stars, months, promo })
  })
  return r.json()
}
export async function getHistory(uid) {
  const r = await fetch(`${BASE}/api/history?uid=${uid}`)
  return r.json()
}
export async function getTop10(period = 'daily') {
  const r = await fetch(`${BASE}/api/top10?period=${period}`)
  return r.json()
}
export async function getReferral(uid) {
  const r = await fetch(`${BASE}/api/referral?uid=${uid}`)
  return r.json()
}

// ─── Giftlar ───────────────────────────────────────────────────
export async function getGifts() {
  const r = await fetch(`${BASE}/api/gifts/list`)
  return r.json()
}
export async function buyGift(uid, gift_id, username) {
  const r = await fetch(`${BASE}/api/gifts/buy`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid, gift_id, username })
  })
  return r.json()
}

// ─── SMM ───────────────────────────────────────────────────────
export async function getSmmServices() {
  const r = await fetch(`${BASE}/api/smm/services`)
  return r.json()
}
export async function buySmmService(uid, service_id, link, quantity, price) {
  const r = await fetch(`${BASE}/api/smm/buy`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid, service_id, link, quantity, price })
  })
  return r.json()
}

// ─── Virtual raqam ─────────────────────────────────────────────
export async function getVnumCountries() {
  const r = await fetch(`${BASE}/api/vnum/countries`)
  return r.json()
}
export async function buyVnum(uid, country_id, price) {
  const r = await fetch(`${BASE}/api/vnum/buy`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid, country_id, price })
  })
  return r.json()
}
export async function getSms(request_id) {
  const r = await fetch(`${BASE}/api/vnum/sms?request_id=${request_id}`)
  return r.json()
}

// ─── TON/USDT ──────────────────────────────────────────────────
export async function getTonRate() {
  const r = await fetch(`${BASE}/api/ton/rate`)
  return r.json()
}
export async function buyTon(uid, currency, amount_uzs, amount_crypto, wallet, rate) {
  const r = await fetch(`${BASE}/api/ton/buy`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid, currency, amount_uzs, amount_crypto, wallet, rate })
  })
  return r.json()
}

// ─── O'yinlar ──────────────────────────────────────────────────
export async function getGames() {
  const r = await fetch(`${BASE}/api/games/list`)
  return r.json()
}

// ─── Reseller API token ────────────────────────────────────────
export async function createApiToken(uid) {
  const r = await fetch(`${BASE}/api/v1/token/create`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid })
  })
  return r.json()
}
