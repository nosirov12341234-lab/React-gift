"""
U-Gift Userbot - Telethon
HumoUzBot xabarlarini o'qib avtomatik balans to'ldiradi

Xabar formati:
🎉 To'ldirish
➕ 22.868,00 UZS
📍 BN 1 POPOLN KARTI>To
💳 HUMOCARD *6205
🕓 22:56 03.06.2026
💰 22.916,12 UZS

Taqqoslash: DB dagi tiyin → xabardagi tiyin mosligini tekshiradi
"""
import asyncio, json, os, re, logging
from datetime import datetime
from telethon import TelegramClient, events
from dotenv import load_dotenv

load_dotenv()

API_ID            = int(os.getenv("TELEGRAM_API_ID", "0"))
API_HASH          = os.getenv("TELEGRAM_API_HASH", "")
BOT_TOKEN         = os.getenv("BOT_TOKEN", "")
HUMO_BOT_USERNAME = os.getenv("HUMO_BOT_USERNAME", "HumoUzBot").lower().lstrip("@")
HUMO_BOT_ID       = int(os.getenv("HUMO_BOT_ID", "0"))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

DB      = os.path.join(os.path.expanduser("~"), "ugift-react", "database.json")
SESSION = os.path.join(os.path.expanduser("~"), "ugift-react", "userbot.session")


def db():
    if os.path.exists(DB):
        with open(DB, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def sdb(data):
    with open(DB, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def fmt(n):
    return f"{int(n):,}".replace(",", " ")


# ─── PARSE ───────────────────────────────────────────
def parse_humo_message(text: str) -> dict | None:
    """
    HumoUzBot xabaridan so'm va tiyin ajratib oladi.

    Formatlar:
      ➕ 22.868,00 UZS   → som=22868, tiyin=0   (lekin 0 bo'lsa ham ishlaydi)
      ➕ 50.000,37 UZS   → som=50000, tiyin=37
      ➕ 22 868,00 UZS   → som=22868, tiyin=0
      ➕ 5000 UZS        → som=5000,  tiyin=0
    """
    if "➕" not in text:
        return None

    m = re.search(r'➕\s*([\d\s.,]+)\s*UZS', text)
    if not m:
        return None

    raw = m.group(1).strip()
    # "22.868,00" yoki "22 868,00" yoki "50000.37"
    # Qoidalar:
    # - vergul (,) — kasr ajratuvchi
    # - nuqta (.) — yoki minglik yoki kasr (kontekstga qarab)
    # - bo'shliq — minglik ajratuvchi

    if ',' in raw:
        # "22.868,00" → so'm qismi: "22.868" = 22868, tiyin: "00"
        parts = raw.split(',')
        som_raw = parts[0].replace(' ', '').replace('.', '')
        tiyin_raw = parts[1].strip()[:2] if len(parts) > 1 else '0'
        som   = int(som_raw) if som_raw.isdigit() else 0
        tiyin = int(tiyin_raw) if tiyin_raw.isdigit() else 0
    elif '.' in raw:
        # "50000.37" — nuqta kasr
        parts = raw.split('.')
        som_raw   = parts[0].replace(' ', '')
        tiyin_raw = parts[1].strip()[:2] if len(parts) > 1 else '0'
        som   = int(som_raw) if som_raw.isdigit() else 0
        tiyin = int(tiyin_raw) if tiyin_raw.isdigit() else 0
    else:
        # Faqat butun son: "5000"
        som_raw = raw.replace(' ', '')
        som   = int(som_raw) if som_raw.isdigit() else 0
        tiyin = 0

    # Vaqt: 🕓 22:56 03.06.2026
    pay_time = datetime.now()
    tm = re.search(r'🕓\s*(\d{2}:\d{2})\s*(\d{2}\.\d{2}\.\d{4})', text)
    if tm:
        try:
            pay_time = datetime.strptime(f"{tm.group(2)} {tm.group(1)}", "%d.%m.%Y %H:%M")
        except Exception:
            pass

    log.info(f"[Parse] so'm={som}, tiyin={tiyin}, vaqt={pay_time}")
    return {"som": som, "tiyin": tiyin, "pay_time": pay_time}


# ─── PENDING TOPISH ──────────────────────────────────
def find_pending(parsed: dict) -> tuple[str, dict] | None:
    """
    DB dagi pending_topups ichidan mosini topadi.
    Taqqoslash: xabardagi tiyin == DB dagi tiyin
    So'm farqi ±50 so'm ruxsat etiladi (xavfsizlik uchun).
    """
    if not parsed:
        return None

    d    = db()
    now  = datetime.now()
    p_tiyin = parsed["tiyin"]
    p_som   = parsed["som"]

    for txn_id, topup in d.get("pending_topups", {}).items():
        if topup.get("method") != "card":
            continue

        # Muddati tekshirish
        exp = topup.get("expires", "")
        try:
            if datetime.fromisoformat(exp) < now:
                log.debug(f"[find] {txn_id} muddati o'tgan")
                continue
        except Exception:
            pass

        db_tiyin = topup.get("tiyin", 0)
        db_som   = topup.get("amount", 0)

        # Tiyin mos kelishi shart
        if db_tiyin != p_tiyin:
            continue

        # So'm farqi ±50 so'm (1 foydalanuvchi xato kiritmasa)
        if abs(db_som - p_som) > 50:
            log.debug(f"[find] {txn_id} tiyin mos ({db_tiyin}=={p_tiyin}) lekin som farqi katta: {db_som} vs {p_som}")
            continue

        log.info(f"[find] ✅ Topildi: txn={txn_id}, uid={topup.get('uid')}, tiyin={db_tiyin}")
        return txn_id, topup

    log.warning(f"[find] ❌ Mos pending yo'q: so'm={p_som}, tiyin={p_tiyin}")
    return None


# ─── TASDIQLASH ──────────────────────────────────────
async def confirm_topup(txn_id: str, topup: dict):
    d   = db()
    uid = topup["uid"]
    amt = topup["amount"]

    if uid not in d.get("users", {}):
        log.warning(f"[confirm] Foydalanuvchi topilmadi: {uid}")
        return

    old_bal = d["users"][uid].get("balance", 0)
    new_bal = old_bal + amt
    d["users"][uid]["balance"] = new_bal
    del d["pending_topups"][txn_id]
    sdb(d)

    log.info(f"✅ uid={uid} | +{fmt(amt)} so'm | yangi bal={fmt(new_bal)}")

    # Foydalanuvchiga xabar
    try:
        from aiogram import Bot
        b = Bot(token=BOT_TOKEN)
        await b.send_message(
            int(uid),
            f"✅ <b>Balansingiz to'ldirildi!</b>\n\n"
            f"➕ <b>+{fmt(amt)} so'm</b>\n"
            f"💰 Joriy balans: <b>{fmt(new_bal)} so'm</b>",
            parse_mode="HTML"
        )
        await b.session.close()
    except Exception as e:
        log.error(f"[xabar xato] {e}")

    # Logs kanal
    try:
        logs_ch = d.get("settings", {}).get("logs_channel")
        if logs_ch:
            from aiogram import Bot
            b = Bot(token=BOT_TOKEN)
            await b.send_message(
                logs_ch,
                f"💳 <b>Karta to'lov tasdiqlandi</b>\n"
                f"👤 UID: <code>{uid}</code>\n"
                f"➕ +{fmt(amt)} so'm\n"
                f"💰 Balans: {fmt(new_bal)} so'm",
                parse_mode="HTML"
            )
            await b.session.close()
    except Exception:
        pass


# ─── ASOSIY ──────────────────────────────────────────
async def main():
    log.info("🤖 Userbot ishga tushmoqda...")
    client = TelegramClient(SESSION, API_ID, API_HASH)
    await client.start()
    me = await client.get_me()
    log.info(f"✅ Ulandi: {me.first_name} (@{me.username})")

    @client.on(events.NewMessage(incoming=True))
    async def handler(event):
        sender = await event.get_sender()
        if not sender:
            return

        uname = (getattr(sender, "username", "") or "").lower()
        sid   = getattr(sender, "id", 0)

        is_humo = (
            (HUMO_BOT_ID and sid == HUMO_BOT_ID) or
            (HUMO_BOT_USERNAME and HUMO_BOT_USERNAME in uname)
        )
        if not is_humo:
            return

        text = event.message.text or event.message.message or ""
        log.info(f"[HumoBot] {text[:120].strip()}")

        if "➕" not in text:
            return

        parsed = parse_humo_message(text)
        if not parsed:
            log.warning("[HumoBot] Parse qilinmadi")
            return

        result = find_pending(parsed)
        if result:
            txn_id, topup = result
            await confirm_topup(txn_id, topup)
        else:
            log.warning(f"[HumoBot] Pending topilmadi (so'm={parsed['som']}, tiyin={parsed['tiyin']})")

    log.info("👂 HumoUzBot xabarlari kutilmoqda...")
    await client.run_until_disconnected()


if __name__ == "__main__":
    asyncio.run(main())

# ─── .env ────────────────────────────────────────────
# TELEGRAM_API_ID=12345678
# TELEGRAM_API_HASH=abc123...
# BOT_TOKEN=123456:ABC...
# CARD_NUMBER=8600 1234 5678 9012
# CARD_HOLDER=SARDOR YUSUPOV
# HUMO_BOT_USERNAME=HumoUzBot
# HUMO_BOT_ID=0   ← aniq ID bilsangiz yozing (ishonchliroq)
