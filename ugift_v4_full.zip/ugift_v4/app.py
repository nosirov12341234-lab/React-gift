"""
U-Gift Flask Server v4
Xizmatlar: Stars, Premium, Giftlar, SMM, O'yin, Virtual raqam, TON/USDT
"""
import json, os, asyncio, secrets, random, re
import requests as req
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, send_from_directory
from dotenv import load_dotenv

load_dotenv()

WEBAPP_DIR       = os.path.join(os.path.expanduser("~"), "webapp")
app              = Flask(__name__, static_folder=WEBAPP_DIR, static_url_path="")
DB               = os.path.join(os.path.expanduser("~"), "ugift-react", "database.json")
BOT_TOKEN        = os.getenv("BOT_TOKEN", "")
SUPER_ADMIN_ID   = int(os.getenv("ADMIN_ID", "0"))
FRAGMENT_COOKIES = os.getenv("FRAGMENT_COOKIES", "")
WALLET_MNEMONIC  = os.getenv("WALLET_MNEMONIC", "")
TON_API_KEY      = os.getenv("TON_API_KEY", "")
CARD_NUMBER      = os.getenv("CARD_NUMBER", "")
CARD_HOLDER      = os.getenv("CARD_HOLDER", "")
SMSMAN_KEY       = os.getenv("SMSMAN_API_KEY", "")
JAP_KEY          = os.getenv("JAP_API_KEY", "")
JAP_URL          = os.getenv("JAP_API_URL", "https://just-another-panel.com/api/v2")

_cached_hash = None

# ─── DB ─────────────────────────────────────────────────────────
def default_db():
    return {
        "users": {}, "orders": [], "admins": {},
        "promo_codes": {}, "pending_topups": {}, "api_keys": {},
        "games": [],
        "settings": {
            "prices": {
                "star": 210,
                "pm3": 195000, "pm6": 370000, "pm12": 680000,
                "gifts": {},
                "smm_margin": 20,
                "vnum_margin": 15,
                "ton_margin": 5,
                "usdt_margin": 5,
            },
            "referral_bonus": 5000,
            "min_stars": 50,
            "required_channels": [],
            "logs_channel": None,
            "support_link": "",
            "channel_link": "",
            "logo_file_id": None,
            "bot_active": True,
            "ton_wallet": "",
            "stars_reserve": 0,
            "stars_reserve_min": 200,
        }
    }

def db():
    if os.path.exists(DB):
        with open(DB, "r", encoding="utf-8") as f:
            return json.load(f)
    return default_db()

def sdb(data):
    with open(DB, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def fmt(n): return f"{int(n):,}".replace(",", " ")
def is_admin(uid): return int(uid) == SUPER_ADMIN_ID or str(uid) in db().get("admins", {})

def run_async(coro):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(coro)
    loop.close()

async def send_tg(chat_id, text, kb=None):
    try:
        import aiohttp
        payload = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
        if kb: payload["reply_markup"] = kb
        async with aiohttp.ClientSession() as s:
            await s.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage", json=payload)
    except: pass

async def send_log(text):
    d = db(); ch = d["settings"].get("logs_channel")
    if ch: await send_tg(ch, text)

# ─── FRAGMENT ───────────────────────────────────────────────────
def get_fragment_hash():
    global _cached_hash
    if _cached_hash: return _cached_hash
    try:
        s = req.Session()
        for c in FRAGMENT_COOKIES.split(';'):
            c = c.strip()
            if '=' in c:
                k, v = c.split('=', 1)
                s.cookies.set(k.strip(), v.strip(), domain='fragment.com')
        s.headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'
        r = s.get('https://fragment.com/', timeout=15)
        m = re.search(r'apiUrl.*?hash=([a-f0-9]+)', r.text)
        if m:
            _cached_hash = m.group(1)
            return _cached_hash
    except Exception as e:
        print(f"[Hash xato]: {e}")
    return os.getenv("FRAGMENT_HASH", "")

def do_fragment_sync(order):
    try:
        from FragmentAPI import SyncFragmentAPI
        hash_val = get_fragment_hash()
        if not hash_val: return False
        api = SyncFragmentAPI(
            cookies=FRAGMENT_COOKIES,
            hash_value=hash_val,
            wallet_mnemonic=WALLET_MNEMONIC,
            wallet_api_key=TON_API_KEY,
        )
        if order["service"] == "stars":
            r = api.buy_stars(order["username"], order["stars"])
        elif order["service"] == "premium":
            r = api.gift_premium(order["username"], order["months"])
        else:
            return False
        if hasattr(r, 'success'): return r.success
        if isinstance(r, dict): return r.get("success") or r.get("ok")
        return bool(r)
    except Exception as e:
        print(f"[Fragment xato]: {e}")
        global _cached_hash
        _cached_hash = None
        return False

# ─── STARS/PREMIUM BUYURTMA ─────────────────────────────────────
def process_order(uid, service, username, price, stars=None, months=None, promo="", source="app"):
    d = db()
    if uid not in d["users"]: return False, "Foydalanuvchi topilmadi"
    if not username: return False, "Username kiritilmagan"
    bal = d["users"][uid].get("balance", 0)
    if bal < price: return False, f"Balans yetarli emas. Kerak: {fmt(price)} so'm, Sizda: {fmt(bal)} so'm"
    if promo and promo in d.get("promo_codes", {}):
        pc = d["promo_codes"][promo]
        if promo not in d["users"][uid].get("promo_used", []):
            d["users"][uid].setdefault("promo_used", []).append(promo)
            pc["used"] = pc.get("used", 0) + 1
    d["users"][uid]["balance"] -= price
    svc_txt = f"👑 Premium {months} oy" if service == "premium" else f"⭐ {fmt(stars or 0)} Stars"
    order = {
        "id": len(d["orders"]) + 1, "user_id": uid,
        "service": service, "username": username,
        "months": months, "stars": stars, "price": price,
        "status": "processing", "source": source,
        "created_at": datetime.now().isoformat(),
    }
    d["orders"].append(order)
    d["users"][uid].setdefault("orders", []).append(order["id"])
    sdb(d)
    success = do_fragment_sync(order)
    d = db()
    if success:
        for o in d["orders"]:
            if o["id"] == order["id"]: o["status"] = "completed"
        sdb(d)
        run_async(send_tg(int(uid), f"🎉 <b>Muvaffaqiyatli!</b>\n\n🛍 {svc_txt}\n👤 @{username}\n💰 {fmt(price)} so'm"))
        run_async(send_log(f"✅ #{order['id']} | {svc_txt} → @{username} | {fmt(price)} so'm"))
        return True, {"order_id": order["id"], "message": f"{svc_txt} yuborildi!"}
    else:
        d["users"][uid]["balance"] += price
        for o in d["orders"]:
            if o["id"] == order["id"]: o["status"] = "failed"
        sdb(d)
        run_async(send_log(f"❌ #{order['id']} | {svc_txt} XATO"))
        return False, "Xato yuz berdi. Balans qaytarildi."

# ─── API TOKEN ──────────────────────────────────────────────────
def get_api_uid():
    token = request.headers.get("X-API-Key", "")
    if not token: return None
    d = db(); kd = d.get("api_keys", {}).get(token)
    if not kd or not kd.get("active"): return None
    d["api_keys"][token]["last_used"] = datetime.now().isoformat()
    d["api_keys"][token]["requests"] = d["api_keys"][token].get("requests", 0) + 1
    sdb(d)
    return kd.get("uid")

def check_admin_token():
    token = request.headers.get("X-Admin-Key", "")
    return token == os.getenv("ADMIN_API_KEY", "") and token != ""

# ─── STATIC ─────────────────────────────────────────────────────
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_react(path):
    if path.startswith("api/") or path.startswith("webhook/"): return jsonify({"error": "not found"}), 404
    full = os.path.join(WEBAPP_DIR, path)
    if path and os.path.exists(full): return send_from_directory(WEBAPP_DIR, path)
    return send_from_directory(WEBAPP_DIR, "index.html")

# ─── SETTINGS ───────────────────────────────────────────────────
@app.route("/api/settings")
def api_settings():
    uid = request.args.get("uid", "0")
    d = db(); u = d["users"].get(str(uid), {}); s = d["settings"]
    return jsonify({
        "prices": s["prices"],
        "min_stars": s["min_stars"],
        "support_link": s.get("support_link", ""),
        "channel_link": s.get("channel_link", ""),
        "referral_bonus": s.get("referral_bonus", 5000),
        "balance": u.get("balance", 0),
        "referrals": u.get("referrals", 0),
        "ref_earned": u.get("ref_earned", 0),
        "username": u.get("username", ""),
        "name": u.get("name", ""),
        "orders_count": len(u.get("orders", [])),
        "ton_wallet": s.get("ton_wallet", ""),
        "games": d.get("games", []),
    })

# ─── STARS / PREMIUM ────────────────────────────────────────────
@app.route("/api/buy", methods=["POST"])
def api_buy():
    data = request.json or {}
    uid = str(data.get("uid", "0"))
    ok, result = process_order(
        uid=uid, service=data.get("service", ""),
        username=data.get("username", "").strip().lstrip("@"),
        price=int(data.get("price", 0)),
        stars=data.get("stars"), months=data.get("months"),
        promo=data.get("promo", "").upper().strip(), source="app"
    )
    if ok: return jsonify({"success": True, **result})
    return jsonify({"success": False, "error": result})

# ─── GIFTLAR ────────────────────────────────────────────────────
@app.route("/api/gifts/list")
def api_gifts_list():
    """Mavjud giftlar ro'yxati va admin belgilagan narxlar"""
    try:
        r = req.get(
            f"https://api.telegram.org/bot{BOT_TOKEN}/getAvailableGifts",
            timeout=10
        )
        data = r.json()
        d = db()
        gift_prices = d["settings"]["prices"].get("gifts", {})
        gifts = []
        if data.get("ok"):
            for g in data["result"].get("gifts", []):
                gid = str(g["id"])
                star_count = g.get("star_count", 0)
                admin_price = gift_prices.get(gid)
                gifts.append({
                    "id": gid,
                    "star_count": star_count,
                    "total_count": g.get("total_count"),
                    "remaining_count": g.get("remaining_count"),
                    "sticker": g.get("sticker", {}),
                    "price": admin_price,
                    "available": admin_price is not None and admin_price > 0,
                })
        return jsonify({"success": True, "gifts": gifts})
    except Exception as e:
        return jsonify({"success": False, "error": str(e), "gifts": []})

@app.route("/api/gifts/buy", methods=["POST"])
def api_gifts_buy():
    """Gift sotib olish — bot orqali yuboradi"""
    data = request.json or {}
    uid = str(data.get("uid", "0"))
    gift_id = str(data.get("gift_id", ""))
    username = data.get("username", "").strip().lstrip("@")

    if not username: return jsonify({"success": False, "error": "Username kiritilmagan"})
    if not gift_id: return jsonify({"success": False, "error": "Gift tanlanmagan"})

    d = db()
    if uid not in d["users"]: return jsonify({"success": False, "error": "Foydalanuvchi topilmadi"})

    gift_prices = d["settings"]["prices"].get("gifts", {})
    price = gift_prices.get(gift_id)
    if not price: return jsonify({"success": False, "error": "Bu gift narxi belgilanmagan"})

    bal = d["users"][uid].get("balance", 0)
    if bal < price: return jsonify({"success": False, "error": f"Balans yetarli emas. Kerak: {fmt(price)} so'm"})

    # Balansdan yechish
    d["users"][uid]["balance"] -= price
    order = {
        "id": len(d["orders"]) + 1,
        "user_id": uid,
        "service": "gift",
        "username": username,
        "gift_id": gift_id,
        "price": price,
        "status": "processing",
        "source": "app",
        "created_at": datetime.now().isoformat(),
    }
    d["orders"].append(order)
    d["users"][uid].setdefault("orders", []).append(order["id"])
    sdb(d)

    # Bot orqali gift yuborish
    try:
        r = req.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendGift",
            json={"user_id": username, "gift_id": gift_id},
            timeout=15
        )
        result = r.json()
        d = db()
        if result.get("ok"):
            for o in d["orders"]:
                if o["id"] == order["id"]: o["status"] = "completed"
            sdb(d)
            run_async(send_tg(int(uid), f"🎁 <b>Gift yuborildi!</b>\n\n👤 @{username}\n💰 {fmt(price)} so'm"))
            run_async(send_log(f"🎁 Gift #{order['id']} → @{username} | {fmt(price)} so'm"))
            return jsonify({"success": True, "message": "Gift yuborildi!"})
        else:
            d["users"][uid]["balance"] += price
            for o in d["orders"]:
                if o["id"] == order["id"]: o["status"] = "failed"
            sdb(d)
            return jsonify({"success": False, "error": "Gift yuborishda xato. Balans qaytarildi."})
    except Exception as e:
        d = db()
        d["users"][uid]["balance"] += price
        sdb(d)
        return jsonify({"success": False, "error": str(e)})

# ─── SMM ────────────────────────────────────────────────────────
@app.route("/api/smm/services")
def api_smm_services():
    """JAP API dan xizmatlar ro'yxati"""
    try:
        r = req.post(JAP_URL, data={"key": JAP_KEY, "action": "services"}, timeout=15)
        services = r.json()
        d = db()
        margin = d["settings"]["prices"].get("smm_margin", 20)

        # Kerakli platformalar filtri
        keywords = {
            "telegram": ["telegram"],
            "instagram": ["instagram"],
            "youtube": ["youtube"],
            "tiktok": ["tiktok", "tik tok"],
        }
        result = {"telegram": [], "instagram": [], "youtube": [], "tiktok": [], "other": []}

        for svc in services:
            name = (svc.get("name", "") + " " + svc.get("category", "")).lower()
            rate = float(svc.get("rate", 0))
            # Narxga margin qo'shish (so'mga o'tkazish: 1$ = ~12700 so'm taxminan)
            price_uzs = round(rate * 127 * (1 + margin / 100))
            item = {
                "id": str(svc.get("service")),
                "name": svc.get("name", ""),
                "category": svc.get("category", ""),
                "min": svc.get("min", 10),
                "max": svc.get("max", 10000),
                "price_per_1000": price_uzs,
                "type": svc.get("type", "Default"),
            }
            placed = False
            for platform, keys in keywords.items():
                if any(k in name for k in keys):
                    result[platform].append(item)
                    placed = True
                    break
            if not placed:
                result["other"].append(item)

        return jsonify({"success": True, "services": result, "margin": margin})
    except Exception as e:
        return jsonify({"success": False, "error": str(e), "services": {}})

@app.route("/api/smm/buy", methods=["POST"])
def api_smm_buy():
    """SMM buyurtma berish"""
    data = request.json or {}
    uid = str(data.get("uid", "0"))
    service_id = data.get("service_id", "")
    link = data.get("link", "").strip()
    quantity = int(data.get("quantity", 0))
    price = int(data.get("price", 0))

    if not link: return jsonify({"success": False, "error": "Link kiritilmagan"})
    if quantity < 10: return jsonify({"success": False, "error": "Minimum 10 ta"})

    d = db()
    if uid not in d["users"]: return jsonify({"success": False, "error": "Foydalanuvchi topilmadi"})
    bal = d["users"][uid].get("balance", 0)
    if bal < price: return jsonify({"success": False, "error": f"Balans yetarli emas. Kerak: {fmt(price)} so'm"})

    # JAP ga buyurtma
    try:
        r = req.post(JAP_URL, data={
            "key": JAP_KEY,
            "action": "add",
            "service": service_id,
            "link": link,
            "quantity": quantity,
        }, timeout=15)
        result = r.json()
        if result.get("order"):
            d["users"][uid]["balance"] -= price
            order = {
                "id": len(d["orders"]) + 1,
                "user_id": uid,
                "service": "smm",
                "jap_order_id": str(result["order"]),
                "link": link,
                "quantity": quantity,
                "price": price,
                "status": "processing",
                "source": "app",
                "created_at": datetime.now().isoformat(),
            }
            d["orders"].append(order)
            d["users"][uid].setdefault("orders", []).append(order["id"])
            sdb(d)
            run_async(send_log(f"📊 SMM #{order['id']} | {link} | {quantity} ta | {fmt(price)} so'm"))
            return jsonify({"success": True, "order_id": order["id"], "jap_id": result["order"]})
        return jsonify({"success": False, "error": result.get("error", "JAP xato")})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/smm/status")
def api_smm_status():
    """JAP buyurtma holati"""
    jap_id = request.args.get("jap_id", "")
    try:
        r = req.post(JAP_URL, data={"key": JAP_KEY, "action": "status", "order": jap_id}, timeout=10)
        return jsonify({"success": True, **r.json()})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

# ─── VIRTUAL RAQAM ──────────────────────────────────────────────
@app.route("/api/vnum/countries")
def api_vnum_countries():
    """SMS-Man dan Telegram uchun mavjud mamlakatlar"""
    try:
        r = req.get(
            "https://api.sms-man.com/control/get-numbers-status",
            params={"token": SMSMAN_KEY, "application_id": 1},  # 1 = Telegram
            timeout=10
        )
        data = r.json()
        d = db()
        margin = d["settings"]["prices"].get("vnum_margin", 15)

        countries = []
        for country_id, info in data.items():
            if isinstance(info, dict) and info.get("count", 0) > 0:
                price_usd = float(info.get("price", 0))
                price_uzs = round(price_usd * 12700 * (1 + margin / 100))
                countries.append({
                    "id": country_id,
                    "name": info.get("country", country_id),
                    "count": info.get("count", 0),
                    "price": price_uzs,
                })
        countries.sort(key=lambda x: x["price"])
        return jsonify({"success": True, "countries": countries})
    except Exception as e:
        return jsonify({"success": False, "error": str(e), "countries": []})

@app.route("/api/vnum/buy", methods=["POST"])
def api_vnum_buy():
    """Virtual raqam sotib olish"""
    data = request.json or {}
    uid = str(data.get("uid", "0"))
    country_id = str(data.get("country_id", ""))
    price = int(data.get("price", 0))

    d = db()
    if uid not in d["users"]: return jsonify({"success": False, "error": "Foydalanuvchi topilmadi"})
    bal = d["users"][uid].get("balance", 0)
    if bal < price: return jsonify({"success": False, "error": f"Balans yetarli emas. Kerak: {fmt(price)} so'm"})

    try:
        r = req.get(
            "https://api.sms-man.com/control/get-number",
            params={"token": SMSMAN_KEY, "application_id": 1, "country_id": country_id},
            timeout=15
        )
        result = r.json()
        if result.get("number"):
            d["users"][uid]["balance"] -= price
            order = {
                "id": len(d["orders"]) + 1,
                "user_id": uid,
                "service": "vnum",
                "request_id": str(result.get("request_id")),
                "number": result["number"],
                "country_id": country_id,
                "price": price,
                "status": "waiting_sms",
                "source": "app",
                "created_at": datetime.now().isoformat(),
                "expires_at": (datetime.now() + timedelta(minutes=10)).isoformat(),
            }
            d["orders"].append(order)
            d["users"][uid].setdefault("orders", []).append(order["id"])
            sdb(d)
            run_async(send_log(f"📱 Virtual raqam #{order['id']} | {result['number']} | {fmt(price)} so'm"))
            return jsonify({
                "success": True,
                "number": result["number"],
                "request_id": result.get("request_id"),
                "order_id": order["id"],
            })
        return jsonify({"success": False, "error": result.get("error_msg", "Raqam olishda xato")})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/vnum/sms")
def api_vnum_sms():
    """SMS kodni tekshirish"""
    request_id = request.args.get("request_id", "")
    try:
        r = req.get(
            "https://api.sms-man.com/control/get-sms",
            params={"token": SMSMAN_KEY, "request_id": request_id},
            timeout=10
        )
        result = r.json()
        if result.get("sms_code"):
            return jsonify({"success": True, "code": result["sms_code"]})
        return jsonify({"success": False, "waiting": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

# ─── TON/USDT ───────────────────────────────────────────────────
@app.route("/api/ton/rate")
def api_ton_rate():
    """Binance dan joriy kurs"""
    try:
        d = db()
        margin_ton = d["settings"]["prices"].get("ton_margin", 5)
        margin_usdt = d["settings"]["prices"].get("usdt_margin", 5)

        # TON kursi
        r_ton = req.get("https://api.binance.com/api/v3/ticker/price?symbol=TONUSDT", timeout=5)
        ton_usd = float(r_ton.json()["price"])

        # USD/UZS (Binance da yo'q — open API dan olamiz)
        r_uzs = req.get("https://open.er-api.com/v6/latest/USD", timeout=5)
        uzs_rate = float(r_uzs.json()["rates"]["UZS"])

        ton_uzs_raw = ton_usd * uzs_rate
        usdt_uzs_raw = uzs_rate

        ton_uzs = round(ton_uzs_raw * (1 + margin_ton / 100))
        usdt_uzs = round(usdt_uzs_raw * (1 + margin_usdt / 100))

        return jsonify({
            "success": True,
            "ton_usd": ton_usd,
            "ton_uzs": ton_uzs,
            "ton_uzs_raw": round(ton_uzs_raw),
            "usdt_uzs": usdt_uzs,
            "usdt_uzs_raw": round(usdt_uzs_raw),
            "margin_ton": margin_ton,
            "margin_usdt": margin_usdt,
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/ton/buy", methods=["POST"])
def api_ton_buy():
    """TON/USDT sotib olish buyurtmasi"""
    data = request.json or {}
    uid = str(data.get("uid", "0"))
    currency = data.get("currency", "TON")  # TON yoki USDT
    amount_uzs = int(data.get("amount_uzs", 0))
    amount_crypto = float(data.get("amount_crypto", 0))
    wallet = data.get("wallet", "").strip()
    rate = int(data.get("rate", 0))

    if not wallet: return jsonify({"success": False, "error": "Hamyon manzili kiritilmagan"})
    if amount_uzs < 10000: return jsonify({"success": False, "error": "Minimum 10 000 so'm"})

    d = db()
    if uid not in d["users"]: return jsonify({"success": False, "error": "Foydalanuvchi topilmadi"})
    bal = d["users"][uid].get("balance", 0)
    if bal < amount_uzs: return jsonify({"success": False, "error": f"Balans yetarli emas. Kerak: {fmt(amount_uzs)} so'm"})

    d["users"][uid]["balance"] -= amount_uzs
    order = {
        "id": len(d["orders"]) + 1,
        "user_id": uid,
        "service": "ton",
        "currency": currency,
        "amount_uzs": amount_uzs,
        "amount_crypto": amount_crypto,
        "wallet": wallet,
        "rate": rate,
        "price": amount_uzs,
        "status": "pending",
        "source": "app",
        "created_at": datetime.now().isoformat(),
    }
    d["orders"].append(order)
    d["users"][uid].setdefault("orders", []).append(order["id"])
    sdb(d)

    # Admin ga xabar
    admin_text = (
        f"💎 <b>Yangi {currency} buyurtma</b>\n\n"
        f"👤 UID: <code>{uid}</code>\n"
        f"💰 So'm: {fmt(amount_uzs)} so'm\n"
        f"💎 Miqdor: {amount_crypto} {currency}\n"
        f"📍 Hamyon: <code>{wallet}</code>\n"
        f"📈 Kurs: {fmt(rate)} so'm\n"
        f"🆔 Buyurtma: #{order['id']}"
    )
    run_async(send_tg(SUPER_ADMIN_ID, admin_text))
    run_async(send_log(admin_text))

    return jsonify({
        "success": True,
        "order_id": order["id"],
        "message": f"{amount_crypto} {currency} so'rov yuborildi. Admin tez orada yuboradi."
    })

# ─── O'YIN DONATLARI ────────────────────────────────────────────
@app.route("/api/games/list")
def api_games_list():
    """Admin qo'shgan o'yinlar ro'yxati"""
    d = db()
    return jsonify({"success": True, "games": d.get("games", [])})

# ─── KARTA TOPUP ────────────────────────────────────────────────
@app.route("/api/topup/card", methods=["POST"])
def api_topup_card():
    data = request.json or {}
    uid = str(data.get("uid", "0"))
    amount = int(data.get("amount", 0))
    if amount < 5000: return jsonify({"success": False, "error": "Minimum 5 000 so'm"})
    d = db()
    if uid not in d["users"]: return jsonify({"success": False, "error": "Foydalanuvchi topilmadi"})

    card = CARD_NUMBER or d["settings"].get("card_number", "")
    holder = CARD_HOLDER or d["settings"].get("card_holder", "Karta egasi")
    if not card: return jsonify({"success": False, "error": "Karta sozlanmagan"})

    now = datetime.now()
    active_tiyins = set()
    for t in d.get("pending_topups", {}).values():
        if t.get("method") != "card": continue
        exp = t.get("expires", "")
        try:
            if datetime.fromisoformat(exp) > now:
                active_tiyins.add(t.get("tiyin", 0))
        except: pass

    candidates = list(range(1, 100))
    random.shuffle(candidates)
    tiyin = next((c for c in candidates if c not in active_tiyins), random.randint(1, 99))

    txn_id = secrets.token_hex(8)
    expires = (now + timedelta(minutes=15)).isoformat()
    d.setdefault("pending_topups", {})[txn_id] = {
        "uid": uid, "amount": amount, "tiyin": tiyin,
        "method": "card", "expires": expires,
        "created_at": now.isoformat(),
    }
    sdb(d)
    return jsonify({
        "success": True, "card": card, "holder": holder,
        "amount_som": amount, "tiyin": tiyin,
        "wait_minutes": 15, "txn_id": txn_id,
    })

# ─── TARIX ──────────────────────────────────────────────────────
@app.route("/api/history")
def api_history():
    uid = request.args.get("uid", "0"); d = db()
    orders = [o for o in d["orders"] if o["user_id"] == str(uid)][-30:]
    return jsonify({"orders": list(reversed(orders))})

# ─── TOP10 ──────────────────────────────────────────────────────
@app.route("/api/top10")
def api_top10():
    period = request.args.get("period", "daily"); d = db()
    today = datetime.now().date().isoformat(); top = {}
    for o in d["orders"]:
        if o["status"] != "completed": continue
        if period == "daily" and o["created_at"][:10] != today: continue
        elif period == "weekly":
            if o["created_at"][:10] < (datetime.now() - timedelta(days=7)).date().isoformat(): continue
        elif period == "monthly":
            if o["created_at"][:7] != today[:7]: continue
        uid_o = o["user_id"]
        if uid_o not in top: top[uid_o] = {"spent": 0, "orders": 0}
        top[uid_o]["spent"] += o.get("price", 0)
        top[uid_o]["orders"] += 1
    result = []
    for uid_o, stats in sorted(top.items(), key=lambda x: x[1]["spent"], reverse=True)[:10]:
        u = d["users"].get(uid_o, {})
        result.append({"uid": uid_o, "name": u.get("name", "Foydalanuvchi"), "spent": stats["spent"], "orders": stats["orders"]})
    return jsonify({"top": result})

# ─── REFERRAL ───────────────────────────────────────────────────
@app.route("/api/referral")
def api_referral():
    uid = request.args.get("uid", "0"); d = db(); u = d["users"].get(str(uid), {})
    try:
        me = req.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getMe", timeout=5).json()
        link = f"https://t.me/{me['result']['username']}?start=ref_{uid}"
    except: link = ""
    ref_list = []
    for rid in u.get("referral_list", []):
        ru = d["users"].get(rid, {})
        ref_list.append({
            "uid": rid, "name": ru.get("name", "Foydalanuvchi"),
            "username": ru.get("username", ""),
            "date": ru.get("joined", "")[:10],
            "orders": len(ru.get("orders", [])),
        })
    return jsonify({
        "link": link,
        "referrals": u.get("referrals", 0),
        "ref_earned": u.get("ref_earned", 0),
        "bonus": d["settings"].get("referral_bonus", 5000),
        "list": ref_list,
    })

# ─── PROMO ──────────────────────────────────────────────────────
@app.route("/api/promo/check", methods=["POST"])
def api_promo_check():
    data = request.json or {}
    code = data.get("code", "").upper().strip()
    uid = str(data.get("uid", "0"))
    product = data.get("product", "all")
    d = db(); promos = d.get("promo_codes", {})
    if code not in promos: return jsonify({"success": False, "error": "Noto'g'ri promo kod"})
    promo = promos[code]
    if promo.get("product", "all") not in ("all", product): return jsonify({"success": False, "error": "Bu mahsulot uchun emas"})
    if promo.get("limit") and promo.get("used", 0) >= promo["limit"]: return jsonify({"success": False, "error": "Limit tugagan"})
    if code in d["users"].get(uid, {}).get("promo_used", []): return jsonify({"success": False, "error": "Allaqachon ishlatgansiz"})
    return jsonify({"success": True, "discount": promo["discount"]})

# ─── RESELLER API ───────────────────────────────────────────────
@app.route("/api/v1/token/create", methods=["POST"])
def v1_token_create():
    data = request.json or {}; uid = str(data.get("uid", "0"))
    if uid not in db().get("users", {}): return jsonify({"error": "Avval /start bosing"}), 400
    d = db(); token = secrets.token_hex(32)
    old = [t for t, v in d.get("api_keys", {}).items() if v.get("uid") == uid]
    for t in old: del d["api_keys"][t]
    d.setdefault("api_keys", {})[token] = {
        "uid": uid, "created_at": datetime.now().isoformat(),
        "active": True, "requests": 0, "last_used": None
    }
    sdb(d)
    return jsonify({"success": True, "token": token})

@app.route("/api/v1/balance")
def v1_balance():
    uid = get_api_uid()
    if not uid: return jsonify({"error": "Noto'g'ri API token"}), 401
    d = db(); u = d["users"].get(str(uid), {})
    return jsonify({"balance": u.get("balance", 0), "orders_count": len(u.get("orders", []))})

@app.route("/api/v1/stars", methods=["POST"])
def v1_stars():
    uid = get_api_uid()
    if not uid: return jsonify({"error": "Noto'g'ri API token"}), 401
    data = request.json or {}
    username = data.get("username", "").strip().lstrip("@")
    count = int(data.get("count", 0))
    d = db(); s = d["settings"]
    if count < s.get("min_stars", 50): return jsonify({"error": f"Minimum {s.get('min_stars', 50)} Stars"}), 400
    price = count * s["prices"]["star"]
    ok, result = process_order(uid=uid, service="stars", username=username, price=price, stars=count, source="api")
    if ok: return jsonify({"success": True, **result})
    return jsonify({"error": result}), 400

@app.route("/api/v1/premium", methods=["POST"])
def v1_premium():
    uid = get_api_uid()
    if not uid: return jsonify({"error": "Noto'g'ri API token"}), 401
    data = request.json or {}
    username = data.get("username", "").strip().lstrip("@")
    months = int(data.get("months", 6))
    if months not in (3, 6, 12): return jsonify({"error": "months: 3, 6 yoki 12"}), 400
    d = db(); s = d["settings"]
    pk = {3: "pm3", 6: "pm6", 12: "pm12"}[months]
    price = s["prices"][pk]
    ok, result = process_order(uid=uid, service="premium", username=username, price=price, months=months, source="api")
    if ok: return jsonify({"success": True, **result})
    return jsonify({"error": result}), 400

@app.route("/api/v1/gift", methods=["POST"])
def v1_gift():
    uid = get_api_uid()
    if not uid: return jsonify({"error": "Noto'g'ri API token"}), 401
    data = request.json or {}
    # Gift API endpoint — app.py dagi gift_buy logikasini ishlatadi
    request._cached_json = (data, request._cached_json[1] if hasattr(request, '_cached_json') else None)
    data["uid"] = uid
    return api_gifts_buy()

@app.route("/api/v1/smm", methods=["POST"])
def v1_smm():
    uid = get_api_uid()
    if not uid: return jsonify({"error": "Noto'g'ri API token"}), 401
    data = request.json or {}
    data["uid"] = uid
    return api_smm_buy()

@app.route("/api/v1/vnum", methods=["POST"])
def v1_vnum():
    uid = get_api_uid()
    if not uid: return jsonify({"error": "Noto'g'ri API token"}), 401
    data = request.json or {}
    data["uid"] = uid
    return api_vnum_buy()

@app.route("/api/v1/ton", methods=["POST"])
def v1_ton():
    uid = get_api_uid()
    if not uid: return jsonify({"error": "Noto'g'ri API token"}), 401
    data = request.json or {}
    data["uid"] = uid
    return api_ton_buy()

@app.route("/api/v1/history")
def v1_history():
    uid = get_api_uid()
    if not uid: return jsonify({"error": "Noto'g'ri API token"}), 401
    d = db(); page = int(request.args.get("page", 1)); limit = 20
    orders = [o for o in reversed(d["orders"]) if o["user_id"] == str(uid)]
    start = (page - 1) * limit
    return jsonify({"orders": orders[start:start + limit], "total": len(orders), "page": page})

@app.route("/api/v1/docs")
def v1_docs():
    base = request.host_url.rstrip("/")
    d = db()
    return jsonify({
        "name": "U-Gift Reseller API v1",
        "version": "2.0",
        "base": base,
        "auth": {"type": "API Key", "header": "X-API-Key: YOUR_TOKEN"},
        "billing": "Barcha so'rovlar balansdan yechiladi",
        "endpoints": {
            "Token": {"POST /api/v1/token/create": "{uid} → token olish"},
            "Hisob": {"GET /api/v1/balance": "Balans", "GET /api/v1/history": "Tarix"},
            "Xaridlar": {
                "POST /api/v1/stars": "{username, count}",
                "POST /api/v1/premium": "{username, months: 3|6|12}",
                "POST /api/v1/gift": "{gift_id, username}",
                "POST /api/v1/smm": "{service_id, link, quantity, price}",
                "POST /api/v1/vnum": "{country_id, price}",
                "POST /api/v1/ton": "{currency: TON|USDT, amount_uzs, amount_crypto, wallet, rate}",
            },
        },
        "prices": d["settings"]["prices"],
    })

# ─── DEV / ADMIN API ────────────────────────────────────────────
@app.route("/api/dev/stats")
def api_dev_stats():
    if not check_admin_token(): return jsonify({"error": "Ruxsat yo'q"}), 401
    d = db(); today = datetime.now().date().isoformat()
    done = [o for o in d["orders"] if o["status"] == "completed"]
    t_ord = [o for o in done if o["created_at"][:10] == today]
    by_service = {}
    for o in done:
        svc = o.get("service", "other")
        by_service[svc] = by_service.get(svc, 0) + o.get("price", 0)
    return jsonify({
        "users": len(d["users"]),
        "orders_total": len(d["orders"]),
        "orders_done": len(done),
        "revenue_total": sum(o["price"] for o in done),
        "revenue_today": sum(o["price"] for o in t_ord),
        "by_service": by_service,
        "prices": d["settings"]["prices"],
    })

@app.route("/api/dev/users")
def api_dev_users():
    if not check_admin_token(): return jsonify({"error": "Ruxsat yo'q"}), 401
    d = db(); page = int(request.args.get("page", 1)); limit = 20
    users = list(d["users"].items()); total = len(users)
    start = (page - 1) * limit
    result = [{
        "uid": uid, "name": u.get("name", ""), "username": u.get("username", ""),
        "balance": u.get("balance", 0), "orders": len(u.get("orders", [])),
        "referrals": u.get("referrals", 0), "banned": u.get("banned", False),
        "joined": u.get("joined", "")[:10]
    } for uid, u in users[start:start + limit]]
    return jsonify({"users": result, "total": total, "page": page})

@app.route("/api/dev/pending-ton")
def api_dev_pending_ton():
    if not check_admin_token(): return jsonify({"error": "Ruxsat yo'q"}), 401
    d = db()
    pending = [o for o in d["orders"] if o.get("service") == "ton" and o.get("status") == "pending"]
    return jsonify({"orders": pending})

@app.route("/api/dev/confirm-ton", methods=["POST"])
def api_dev_confirm_ton():
    if not check_admin_token(): return jsonify({"error": "Ruxsat yo'q"}), 401
    data = request.json or {}
    order_id = int(data.get("order_id", 0))
    d = db()
    for o in d["orders"]:
        if o["id"] == order_id and o.get("service") == "ton":
            o["status"] = "completed"
            sdb(d)
            uid = o["user_id"]
            run_async(send_tg(int(uid),
                f"✅ <b>{o['amount_crypto']} {o['currency']} yuborildi!</b>\n"
                f"📍 Hamyon: <code>{o['wallet']}</code>"
            ))
            return jsonify({"success": True})
    return jsonify({"success": False, "error": "Buyurtma topilmadi"})

if __name__ == "__main__":
    print(f"✅ Webapp: {WEBAPP_DIR}")
    print(f"✅ DB: {DB}")
    app.run(host="0.0.0.0", port=5000, debug=False)
