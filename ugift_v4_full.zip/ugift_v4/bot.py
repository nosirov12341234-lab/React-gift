"""
U-Gift Bot v4 — To'liq
Xizmatlar: Stars, Premium, Giftlar, SMM, Virtual raqam, TON/USDT, O'yinlar
Admin: Majburiy obuna, Logs kanal, Narxlar, O'yinlar ro'yxati, TON buyurtmalar
"""
import asyncio, logging, json, os, re, secrets
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo, MenuButtonDefault
)
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN      = os.getenv("BOT_TOKEN")
SUPER_ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
WEB_URL        = os.getenv("WEB_URL", "")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

bot = Bot(token=BOT_TOKEN)
dp  = Dispatcher(storage=MemoryStorage())
DB  = os.path.join(os.path.expanduser("~"), "ugift-react", "database.json")

# ─── DB ──────────────────────────────────────────────────────────
def default_db():
    return {
        "users": {}, "orders": [], "admins": {},
        "promo_codes": {}, "pending_topups": {}, "api_keys": {},
        "games": [],
        "settings": {
            "bot_active": True, "min_stars": 50,
            "referral_bonus": 5000,
            "required_channels": [],
            "logs_channel": None,
            "support_link": "", "channel_link": "",
            "logo_file_id": None,
            "card_number": "", "card_holder": "",
            "ton_wallet": "",
            "stars_reserve": 0, "stars_reserve_min": 200,
            "prices": {
                "star": 210,
                "pm3": 195000, "pm6": 370000, "pm12": 680000,
                "gifts": {},
                "smm_margin": 20,
                "vnum_margin": 15,
                "ton_margin": 5,
                "usdt_margin": 5,
            },
        }
    }

def db():
    if os.path.exists(DB):
        with open(DB, "r", encoding="utf-8") as f:
            return json.load(f)
    d = default_db(); sdb(d); return d

def sdb(data):
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    with open(DB, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def is_admin(uid): return uid == SUPER_ADMIN_ID or str(uid) in db().get("admins", {})
def is_super(uid): return uid == SUPER_ADMIN_ID
def fmt(n): return f"{int(n):,}".replace(",", " ")

# ─── FSM STATES ─────────────────────────────────────────────────
class A(StatesGroup):
    # Umumiy
    broadcast = State()
    # Sozlamalar
    support = State(); channel_link = State(); logo = State()
    min_stars = State(); ref_bonus = State()
    # Karta
    card_number = State(); card_holder = State()
    # Kanallar
    add_channel = State(); logs_channel = State()
    del_channel = State()
    # Adminlar
    admin_id = State()
    # Foydalanuvchilar
    ban_id = State(); give_bal = State(); usearch = State()
    # Narxlar
    price_key = State()
    # Gift narxlari
    gift_id = State(); gift_price = State()
    # SMM/Virtual/TON foiz
    margin_key = State()
    # O'yinlar
    game_name = State(); game_emoji = State()
    # Promo
    promo_code = State(); promo_disc = State()
    promo_limit = State(); promo_product = State()
    # To'lov
    card_topup = State(); screenshot_topup = State()
    # TON tasdiqlash
    ton_confirm = State()

# ─── YORDAMCHI ──────────────────────────────────────────────────
async def send_log(text):
    d = db(); ch = d["settings"].get("logs_channel")
    if ch:
        try: await bot.send_message(ch, text, parse_mode="HTML")
        except: pass

async def check_sub(uid):
    d = db()
    for ch in d["settings"].get("required_channels", []):
        try:
            m = await bot.get_chat_member(ch, uid)
            if m.status in ["left", "kicked"]: return False
        except: pass
    return True

def make_kb(channel_link="", support_link=""):
    rows = []
    if WEB_URL and WEB_URL.startswith("https://"):
        rows.append([InlineKeyboardButton(text="🛍 U-Gift Marketni ochish", web_app=WebAppInfo(url=WEB_URL))])
    row = []
    if channel_link: row.append(InlineKeyboardButton(text="📢 Kanal", url=channel_link))
    if support_link: row.append(InlineKeyboardButton(text="💬 Support", url=support_link))
    if row: rows.append(row)
    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None

def back_kb(to="adm_main"):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🔙 Orqaga", callback_data=to)]])

def gen_unique_tiyin(base_amount):
    import random
    d = db(); now = datetime.now()
    active = set()
    for t in d.get("pending_topups", {}).values():
        if t.get("method") != "card": continue
        try:
            if datetime.fromisoformat(t.get("expires", "")) > now:
                active.add(t.get("tiyin", 0))
        except: pass
    candidates = list(range(1, 100))
    random.shuffle(candidates)
    return next((c for c in candidates if c not in active), random.randint(1, 99))

# ─── START ───────────────────────────────────────────────────────
@dp.message(Command("start"))
async def cmd_start(msg: types.Message, state: FSMContext):
    await state.clear()
    d = db(); uid = str(msg.from_user.id)
    if not d["settings"]["bot_active"] and not is_admin(msg.from_user.id):
        await msg.answer("🔧 Bot hozirda texnik ishlar uchun o'chirilgan."); return
    # Yangi foydalanuvchi
    if uid not in d["users"]:
        d["users"][uid] = {
            "balance": 0, "orders": [], "referrals": 0, "ref_earned": 0,
            "joined": datetime.now().isoformat(), "banned": False,
            "promo_used": [], "referral_list": [], "referred_by": None,
            "username": msg.from_user.username or "",
            "name": msg.from_user.full_name or "",
        }
        args = msg.text.split()
        if len(args) > 1 and args[1].startswith("ref_"):
            ref_id = args[1][4:]
            if ref_id in d["users"] and ref_id != uid:
                bonus = d["settings"]["referral_bonus"]
                d["users"][ref_id]["balance"] = d["users"][ref_id].get("balance", 0) + bonus
                d["users"][ref_id]["referrals"] = d["users"][ref_id].get("referrals", 0) + 1
                d["users"][ref_id]["ref_earned"] = d["users"][ref_id].get("ref_earned", 0) + bonus
                d["users"][ref_id].setdefault("referral_list", []).append(uid)
                d["users"][uid]["referred_by"] = ref_id
                try:
                    await bot.send_message(int(ref_id),
                        f"🎉 <b>Yangi referral!</b>\n➕ <b>+{fmt(bonus)} so'm</b> bonus!",
                        parse_mode="HTML")
                except: pass
        sdb(d)
        await send_log(f"👤 Yangi foydalanuvchi: {msg.from_user.full_name} (@{msg.from_user.username}) | ID: {uid}")
    else:
        d["users"][uid]["username"] = msg.from_user.username or ""
        d["users"][uid]["name"] = msg.from_user.full_name or ""
        sdb(d)

    d = db()
    if d["users"][uid].get("banned"):
        await msg.answer("🚫 Siz bloklangansiz. Murojaat uchun adminlarga yozing."); return

    # Admin redirect
    args = msg.text.split()
    if len(args) > 1 and args[1] == "admin" and is_admin(msg.from_user.id):
        await cmd_admin(msg, state); return

    # Majburiy obuna tekshirish
    if not await check_sub(msg.from_user.id):
        chs = d["settings"].get("required_channels", [])
        btns = []
        for ch in chs:
            link = f"https://t.me/{ch.lstrip('@')}"
            btns.append([InlineKeyboardButton(text=f"📢 {ch}", url=link)])
        btns.append([InlineKeyboardButton(text="✅ Obuna bo'ldim, tekshirish", callback_data="check_sub")])
        await msg.answer(
            "📢 <b>Botdan foydalanish uchun quyidagi kanallarga obuna bo'ling:</b>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=btns)
        )
        return

    bal = d["users"][uid].get("balance", 0)
    logo = d["settings"].get("logo_file_id")
    channel = d["settings"].get("channel_link", "")
    support = d["settings"].get("support_link", "")
    text = (
        f"👋 <b>Salom, {msg.from_user.first_name}!</b>\n\n"
        f"🛍 <b>U-Gift Market</b> — Telegram xizmatlar platformasi\n\n"
        f"💰 Balansingiz: <b>{fmt(bal)} so'm</b>\n\n"
        f"👇 Marketga kirish uchun tugmani bosing:"
    )
    kb = make_kb(channel, support)
    if logo:
        await msg.answer_photo(logo, caption=text, parse_mode="HTML", reply_markup=kb)
    else:
        await msg.answer(text, parse_mode="HTML", reply_markup=kb)

@dp.callback_query(F.data == "check_sub")
async def cb_check_sub(cb: types.CallbackQuery, state: FSMContext):
    if await check_sub(cb.from_user.id):
        await cb.message.delete()
        await cmd_start(cb.message, state)
    else:
        await cb.answer("❌ Hali obuna bo'lmadingiz!", show_alert=True)

# ─── TO'LOV ──────────────────────────────────────────────────────
@dp.message(Command("tolov"))
async def cmd_topup(msg: types.Message):
    d = db(); uid = str(msg.from_user.id)
    if uid not in d["users"]: await msg.answer("Avval /start bosing"); return
    card = d["settings"].get("card_number", "")
    support = d["settings"].get("support_link", "")
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Avtomatik (karta)", callback_data="topup_auto")],
        [InlineKeyboardButton(text="📸 Screenshot orqali", callback_data="topup_screen")],
        [InlineKeyboardButton(text="👨‍💼 Admin orqali", url=support or "https://t.me/")],
    ])
    await msg.answer("💰 <b>Hisob to'ldirish</b>\n\nTo'lov usulini tanlang:", parse_mode="HTML", reply_markup=kb)

@dp.callback_query(F.data == "topup_auto")
async def cb_topup_auto(cb: types.CallbackQuery, state: FSMContext):
    d = db()
    if not d["settings"].get("card_number"):
        await cb.answer("❌ Karta hali sozlanmagan!", show_alert=True); return
    await cb.message.edit_text(
        "💳 <b>Avtomatik to'ldirish</b>\n\nQancha so'm to'ldirmoqchisiz?\n<i>Minimum: 5 000 so'm</i>",
        parse_mode="HTML"
    )
    await state.set_state(A.card_topup)

@dp.message(A.card_topup)
async def enter_card_topup(msg: types.Message, state: FSMContext):
    try:
        amount = int(msg.text.replace(" ", "").replace(",", ""))
        if amount < 5000: await msg.answer("❌ Minimum 5 000 so'm!"); return
        d = db(); uid = str(msg.from_user.id)
        card = d["settings"].get("card_number", "")
        holder = d["settings"].get("card_holder", "")
        tiyin = gen_unique_tiyin(amount)
        expires = (datetime.now() + timedelta(minutes=15)).isoformat()
        txn_id = secrets.token_hex(8)
        d.setdefault("pending_topups", {})[txn_id] = {
            "uid": uid, "amount": amount, "tiyin": tiyin,
            "method": "card", "expires": expires,
            "created_at": datetime.now().isoformat(),
        }
        sdb(d); await state.clear()
        await msg.answer(
            f"💳 <b>To'lov ma'lumotlari</b>\n\n"
            f"🏦 Karta: <code>{card}</code>\n"
            f"👤 Egasi: <b>{holder}</b>\n\n"
            f"💰 Aynan shu summani yuboring:\n"
            f"<b><code>{fmt(amount)},{str(tiyin).zfill(2)}</code> so'm</b>\n\n"
            f"⚠️ Tiyingacha aniq yuboring — boshqacha bo'lsa aniqlanmaydi!\n"
            f"⏰ Vaqt: <b>15 daqiqa</b>",
            parse_mode="HTML"
        )
    except ValueError: await msg.answer("❌ Faqat raqam kiriting!")

@dp.callback_query(F.data == "topup_screen")
async def cb_topup_screen(cb: types.CallbackQuery, state: FSMContext):
    d = db()
    card = d["settings"].get("card_number", "")
    holder = d["settings"].get("card_holder", "")
    await cb.message.edit_text(
        f"📸 <b>Screenshot orqali to'ldirish</b>\n\n"
        f"1️⃣ Quyidagi kartaga pul yuboring:\n"
        f"🏦 Karta: <code>{card}</code>\n"
        f"👤 Egasi: <b>{holder}</b>\n\n"
        f"2️⃣ Qancha so'm to'ladingiz? (raqam kiriting):",
        parse_mode="HTML"
    )
    await state.set_state(A.screenshot_topup)

@dp.message(A.screenshot_topup)
async def enter_screenshot_amount(msg: types.Message, state: FSMContext):
    try:
        amount = int(msg.text.replace(" ", "").replace(",", ""))
        if amount < 5000: await msg.answer("❌ Minimum 5 000 so'm!"); return
        await state.update_data(screen_amount=amount)
        await msg.answer(f"✅ Summa: <b>{fmt(amount)} so'm</b>\n\nEndi to'lov screenshotini yuboring 📸", parse_mode="HTML")
    except ValueError: await msg.answer("❌ Faqat raqam!")

@dp.message(A.screenshot_topup, F.photo)
async def receive_screenshot(msg: types.Message, state: FSMContext):
    data = await state.get_data(); amount = data.get("screen_amount", 0)
    uid = str(msg.from_user.id); d = db()
    txn_id = secrets.token_hex(8)
    d.setdefault("pending_topups", {})[txn_id] = {
        "uid": uid, "amount": amount, "method": "screenshot",
        "photo_id": msg.photo[-1].file_id, "status": "pending",
        "created_at": datetime.now().isoformat(),
    }
    sdb(d); await state.clear()
    support = d["settings"].get("support_link", "")
    await msg.answer(
        f"✅ <b>Screenshot qabul qilindi!</b>\n\n"
        f"💰 Summa: <b>{fmt(amount)} so'm</b>\n"
        f"⏳ Admin tez orada tasdiqlaydi (5-30 daqiqa)",
        parse_mode="HTML"
    )
    try:
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"confirm_screen_{txn_id}"),
            InlineKeyboardButton(text="❌ Rad etish",  callback_data=f"reject_screen_{txn_id}"),
        ]])
        await bot.send_photo(
            SUPER_ADMIN_ID, msg.photo[-1].file_id,
            caption=(
                f"📸 <b>Screenshot to'lov</b>\n\n"
                f"👤 {msg.from_user.full_name} (@{msg.from_user.username})\n"
                f"🆔 <code>{uid}</code>\n"
                f"💰 {fmt(amount)} so'm\n🔑 {txn_id}"
            ),
            parse_mode="HTML", reply_markup=kb
        )
    except: pass
    await send_log(f"📸 Screenshot keldi | {uid} | {fmt(amount)} so'm")

@dp.callback_query(F.data.startswith("confirm_screen_"))
async def confirm_screen(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    txn_id = cb.data.replace("confirm_screen_", "")
    d = db()
    if txn_id not in d.get("pending_topups", {}):
        await cb.answer("❌ Topilmadi!"); return
    topup = d["pending_topups"][txn_id]; uid = topup["uid"]; amt = topup["amount"]
    d["users"][uid]["balance"] = d["users"][uid].get("balance", 0) + amt
    del d["pending_topups"][txn_id]; sdb(d)
    await cb.message.edit_caption(
        cb.message.caption + f"\n\n✅ <b>Tasdiqlandi! +{fmt(amt)} so'm</b>", parse_mode="HTML"
    )
    try: await bot.send_message(int(uid),
        f"✅ <b>Balansingiz to'ldirildi!</b>\n\n➕ <b>+{fmt(amt)} so'm</b>\n"
        f"💰 Joriy: <b>{fmt(d['users'][uid]['balance'])} so'm</b>", parse_mode="HTML")
    except: pass
    await send_log(f"✅ Screenshot tasdiqlandi | {uid} | +{fmt(amt)} so'm")

@dp.callback_query(F.data.startswith("reject_screen_"))
async def reject_screen(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    txn_id = cb.data.replace("reject_screen_", "")
    d = db()
    if txn_id in d.get("pending_topups", {}):
        uid = d["pending_topups"][txn_id]["uid"]
        del d["pending_topups"][txn_id]; sdb(d)
        try: await bot.send_message(int(uid), "❌ <b>To'lovingiz rad etildi.</b>\n\nSavol bo'lsa adminlarga murojaat qiling.", parse_mode="HTML")
        except: pass
    await cb.message.edit_caption(cb.message.caption + "\n\n❌ <b>Rad etildi</b>", parse_mode="HTML")

# ─── ADMIN PANEL ─────────────────────────────────────────────────
def adm_kb():
    d = db(); s = d["settings"]
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Statistika",        callback_data="adm_stats"),
         InlineKeyboardButton(text="👥 Foydalanuvchilar",  callback_data="adm_users")],
        [InlineKeyboardButton(text="💰 Narxlar",           callback_data="adm_prices"),
         InlineKeyboardButton(text="🎁 Promo kodlar",      callback_data="adm_promos")],
        [InlineKeyboardButton(text="📋 Buyurtmalar",       callback_data="adm_orders"),
         InlineKeyboardButton(text="💎 TON buyurtmalar",   callback_data="adm_ton_orders")],
        [InlineKeyboardButton(text="📸 Screenshotlar",     callback_data="adm_screens"),
         InlineKeyboardButton(text="📢 Broadcast",         callback_data="adm_broadcast")],
        [InlineKeyboardButton(text="📢 Kanallar",          callback_data="adm_channels"),
         InlineKeyboardButton(text="👑 Adminlar",          callback_data="adm_admins")],
        [InlineKeyboardButton(text="💳 Karta",             callback_data="adm_card"),
         InlineKeyboardButton(text="🎮 O'yinlar",          callback_data="adm_games")],
        [InlineKeyboardButton(text="⚙️ Sozlamalar",        callback_data="adm_settings"),
         InlineKeyboardButton(text="🖼 Logo",              callback_data="adm_logo")],
        [InlineKeyboardButton(text="🔑 API Token",         callback_data="adm_dev_token")],
        [InlineKeyboardButton(
            text=f"🤖 Bot {'✅ Yoqiq' if s['bot_active'] else '❌ O\\'chiq'}",
            callback_data="adm_toggle_bot"
        )],
    ])

async def adm_text():
    d = db(); s = d["settings"]
    done = [o for o in d["orders"] if o["status"] == "completed"]
    today = datetime.now().date().isoformat()
    t_rev = sum(o["price"] for o in done if o["created_at"][:10] == today)
    total_rev = sum(o["price"] for o in done)
    screens = len([t for t in d.get("pending_topups", {}).values() if t.get("method") == "screenshot"])
    ton_pending = len([o for o in d["orders"] if o.get("service") == "ton" and o.get("status") == "pending"])
    chs = s.get("required_channels", [])
    logs_ch = s.get("logs_channel", "Sozlanmagan")
    return (
        f"👨‍💼 <b>Admin Panel — U-Gift v4</b>\n\n"
        f"<code>━━━━━━━━━━━━━━━━━━</code>\n"
        f"👥 Foydalanuvchilar: <b>{len(d['users'])}</b>\n"
        f"✅ Bajarilgan: <b>{len(done)}</b>\n"
        f"📸 Screenshot kutmoqda: <b>{screens}</b>\n"
        f"💎 TON kutmoqda: <b>{ton_pending}</b>\n"
        f"<code>━━━━━━━━━━━━━━━━━━</code>\n"
        f"📅 Bugungi daromad: <b>{fmt(t_rev)} so'm</b>\n"
        f"💰 Jami daromad: <b>{fmt(total_rev)} so'm</b>\n"
        f"<code>━━━━━━━━━━━━━━━━━━</code>\n"
        f"📢 Obuna kanallari: <b>{len(chs)} ta</b>\n"
        f"📝 Logs kanal: <b>{logs_ch}</b>\n"
        f"💳 Karta: <b>{s.get('card_number', 'Sozlanmagan')}</b>"
    )

@dp.message(Command("admin"))
async def cmd_admin(msg: types.Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    await state.clear()
    await msg.answer(await adm_text(), parse_mode="HTML", reply_markup=adm_kb())

@dp.callback_query(F.data == "adm_main")
async def cb_adm_main(cb: types.CallbackQuery, state: FSMContext):
    if not is_admin(cb.from_user.id): return
    if state: await state.clear()
    try: await cb.message.edit_text(await adm_text(), parse_mode="HTML", reply_markup=adm_kb())
    except: await cb.message.answer(await adm_text(), parse_mode="HTML", reply_markup=adm_kb())

# ─── KANALLAR (MAJBURIY OBUNA + LOGS) ────────────────────────────
@dp.callback_query(F.data == "adm_channels")
async def cb_channels(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db(); s = d["settings"]
    chs = s.get("required_channels", [])
    logs = s.get("logs_channel", "Sozlanmagan")
    ch_text = "\n".join([f"  {i+1}. {c}" for i, c in enumerate(chs)]) if chs else "  Yo'q"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Obuna kanal qo'shish",  callback_data="adm_add_ch")],
        [InlineKeyboardButton(text="➖ Obuna kanal o'chirish", callback_data="adm_del_ch")],
        [InlineKeyboardButton(text=f"📝 Logs kanal: {logs}",   callback_data="adm_set_logs")],
        [InlineKeyboardButton(text="🗑 Barcha obunani tozalash", callback_data="adm_clear_ch")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_main")],
    ])
    await cb.message.edit_text(
        f"📢 <b>Kanal sozlamalari</b>\n\n"
        f"<b>Majburiy obuna kanallari:</b>\n{ch_text}\n\n"
        f"<b>Logs kanal:</b> {logs}\n\n"
        f"<i>💡 Logs kanalga barcha buyurtmalar va to'lovlar yuboriladi</i>",
        parse_mode="HTML", reply_markup=kb
    )

@dp.callback_query(F.data == "adm_add_ch")
async def add_ch(cb: types.CallbackQuery, state: FSMContext):
    await cb.message.edit_text(
        "📢 <b>Majburiy obuna kanal</b>\n\n"
        "Kanal username yoki ID kiriting:\n"
        "<i>Misol: @mening_kanalim yoki -100123456789</i>\n\n"
        "⚠️ Bot kanalda admin bo'lishi kerak!",
        parse_mode="HTML"
    )
    await state.set_state(A.add_channel)

@dp.message(A.add_channel)
async def enter_add_channel(msg: types.Message, state: FSMContext):
    ch = msg.text.strip()
    # Kanalda bot borligini tekshirish
    try:
        chat = await bot.get_chat(ch)
        d = db()
        if ch not in d["settings"]["required_channels"]:
            d["settings"]["required_channels"].append(ch)
            sdb(d)
        await msg.answer(
            f"✅ <b>Kanal qo'shildi!</b>\n\n"
            f"📢 {chat.title} ({ch})\n"
            f"Jami: {len(d['settings']['required_channels'])} ta kanal",
            parse_mode="HTML"
        )
    except Exception as e:
        await msg.answer(f"❌ Kanal topilmadi yoki bot admin emas!\n\n{e}")
    await state.clear(); await cmd_admin(msg, state)

@dp.callback_query(F.data == "adm_del_ch")
async def del_ch_start(cb: types.CallbackQuery, state: FSMContext):
    d = db(); chs = d["settings"].get("required_channels", [])
    if not chs:
        await cb.answer("Kanal yo'q!", show_alert=True); return
    btns = [[InlineKeyboardButton(text=f"❌ {ch}", callback_data=f"del_ch_{i}")] for i, ch in enumerate(chs)]
    btns.append([InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_channels")])
    await cb.message.edit_text("O'chirish uchun kanalni tanlang:", reply_markup=InlineKeyboardMarkup(inline_keyboard=btns))

@dp.callback_query(F.data.startswith("del_ch_"))
async def del_ch_confirm(cb: types.CallbackQuery):
    idx = int(cb.data.replace("del_ch_", ""))
    d = db(); chs = d["settings"].get("required_channels", [])
    if idx < len(chs):
        removed = chs.pop(idx)
        d["settings"]["required_channels"] = chs; sdb(d)
        await cb.answer(f"✅ {removed} o'chirildi!", show_alert=True)
    await cb_channels(cb)

@dp.callback_query(F.data == "adm_clear_ch")
async def clear_ch(cb: types.CallbackQuery):
    d = db(); d["settings"]["required_channels"] = []; sdb(d)
    await cb.answer("✅ Barcha kanallar o'chirildi!", show_alert=True)
    await cb_channels(cb)

@dp.callback_query(F.data == "adm_set_logs")
async def set_logs(cb: types.CallbackQuery, state: FSMContext):
    await cb.message.edit_text(
        "📝 <b>Logs kanal</b>\n\n"
        "Kanal username yoki ID kiriting:\n"
        "<i>Misol: @ugift_logs yoki -100123456789</i>\n\n"
        "⚠️ Bot kanalda admin bo'lishi kerak!",
        parse_mode="HTML"
    )
    await state.set_state(A.logs_channel)

@dp.message(A.logs_channel)
async def enter_logs_channel(msg: types.Message, state: FSMContext):
    ch = msg.text.strip()
    try:
        chat = await bot.get_chat(ch)
        d = db(); d["settings"]["logs_channel"] = ch; sdb(d)
        await msg.answer(
            f"✅ <b>Logs kanal saqlandi!</b>\n\n"
            f"📝 {chat.title} ({ch})\n\n"
            f"Endi barcha buyurtmalar va to'lovlar shu kanalga yuboriladi.",
            parse_mode="HTML"
        )
        await send_log(f"📝 Logs kanal sozlandi: {chat.title}")
    except Exception as e:
        await msg.answer(f"❌ Kanal topilmadi yoki bot admin emas!\n\n{e}")
    await state.clear(); await cmd_admin(msg, state)

# ─── STATISTIKA ──────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_stats")
async def cb_stats(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    d = db(); today = datetime.now().date().isoformat()
    done = [o for o in d["orders"] if o["status"] == "completed"]
    t_rev = sum(o["price"] for o in done if o["created_at"][:10] == today)
    w_rev = sum(o["price"] for o in done if o["created_at"][:10] >= (datetime.now() - timedelta(days=7)).date().isoformat())
    total_rev = sum(o["price"] for o in done)
    # Xizmat bo'yicha statistika
    by_svc = {}
    for o in done:
        s = o.get("service", "other")
        by_svc[s] = by_svc.get(s, 0) + 1
    svc_labels = {"stars": "⭐ Stars", "premium": "👑 Premium", "gift": "🎁 Gift",
                  "smm": "📊 SMM", "vnum": "📱 V-raqam", "ton": "💎 TON/USDT"}
    svc_text = "\n".join([f"  {svc_labels.get(k, k)}: {v} ta" for k, v in by_svc.items()])
    screens = len([t for t in d.get("pending_topups", {}).values() if t.get("method") == "screenshot"])
    ton_pend = len([o for o in d["orders"] if o.get("service") == "ton" and o.get("status") == "pending"])
    await cb.message.edit_text(
        f"📊 <b>Statistika</b>\n\n"
        f"<code>━━━━━━━━━━━━━━━━</code>\n"
        f"👥 Foydalanuvchilar: <b>{len(d['users'])}</b>\n"
        f"🚫 Banlangan: <b>{len([u for u in d['users'].values() if u.get('banned')])}</b>\n"
        f"<code>━━━━━━━━━━━━━━━━</code>\n"
        f"📋 Jami buyurtmalar: <b>{len(d['orders'])}</b>\n"
        f"✅ Bajarilgan: <b>{len(done)}</b>\n"
        f"❌ Xato: <b>{len([o for o in d['orders'] if o['status']=='failed'])}</b>\n"
        f"⏳ Jarayonda: <b>{len([o for o in d['orders'] if o['status']=='processing'])}</b>\n"
        f"📸 Screenshot kutmoqda: <b>{screens}</b>\n"
        f"💎 TON kutmoqda: <b>{ton_pend}</b>\n"
        f"<code>━━━━━━━━━━━━━━━━</code>\n"
        f"📅 Bugun: <b>{fmt(t_rev)} so'm</b>\n"
        f"📆 7 kun: <b>{fmt(w_rev)} so'm</b>\n"
        f"💰 Jami: <b>{fmt(total_rev)} so'm</b>\n"
        f"<code>━━━━━━━━━━━━━━━━</code>\n"
        f"<b>Xizmat bo'yicha:</b>\n{svc_text}",
        parse_mode="HTML", reply_markup=back_kb()
    )

# ─── TON BUYURTMALAR ─────────────────────────────────────────────
@dp.callback_query(F.data == "adm_ton_orders")
async def cb_ton_orders(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    d = db()
    pending = [o for o in d["orders"] if o.get("service") == "ton" and o.get("status") == "pending"]
    if not pending:
        await cb.answer("💎 Kutayotgan TON buyurtma yo'q!", show_alert=True); return
    for o in pending[:5]:
        u = d["users"].get(o["user_id"], {})
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"ton_confirm_{o['id']}"),
            InlineKeyboardButton(text="❌ Rad etish",  callback_data=f"ton_reject_{o['id']}"),
        ]])
        await cb.message.answer(
            f"💎 <b>TON/USDT Buyurtma #{o['id']}</b>\n\n"
            f"👤 {u.get('name', '?')} (@{u.get('username', '?')})\n"
            f"🆔 <code>{o['user_id']}</code>\n"
            f"💎 Miqdor: <b>{o['amount_crypto']} {o['currency']}</b>\n"
            f"💰 So'm: <b>{fmt(o['amount_uzs'])} so'm</b>\n"
            f"📈 Kurs: {fmt(o.get('rate', 0))} so'm\n"
            f"📍 Hamyon: <code>{o['wallet']}</code>\n"
            f"📅 {o['created_at'][:16]}",
            parse_mode="HTML", reply_markup=kb
        )
    await cb.message.answer(
        f"Jami {len(pending)} ta kutayotgan buyurtma.",
        reply_markup=back_kb()
    )

@dp.callback_query(F.data.startswith("ton_confirm_"))
async def ton_confirm(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    order_id = int(cb.data.replace("ton_confirm_", ""))
    d = db()
    for o in d["orders"]:
        if o["id"] == order_id and o.get("service") == "ton":
            o["status"] = "completed"; sdb(d)
            uid = o["user_id"]
            try:
                await bot.send_message(int(uid),
                    f"✅ <b>{o['amount_crypto']} {o['currency']} yuborildi!</b>\n\n"
                    f"📍 Hamyon: <code>{o['wallet']}</code>",
                    parse_mode="HTML"
                )
            except: pass
            await cb.message.edit_text(
                cb.message.text + "\n\n✅ <b>Tasdiqlandi!</b>", parse_mode="HTML"
            )
            await send_log(f"✅ TON #{order_id} tasdiqlandi | {uid} | {o['amount_crypto']} {o['currency']}")
            return
    await cb.answer("❌ Topilmadi!")

@dp.callback_query(F.data.startswith("ton_reject_"))
async def ton_reject(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    order_id = int(cb.data.replace("ton_reject_", ""))
    d = db()
    for o in d["orders"]:
        if o["id"] == order_id and o.get("service") == "ton":
            o["status"] = "cancelled"
            uid = o["user_id"]
            # Balansni qaytarish
            d["users"][uid]["balance"] = d["users"][uid].get("balance", 0) + o["amount_uzs"]
            sdb(d)
            try:
                await bot.send_message(int(uid),
                    f"❌ <b>TON/USDT so'rovingiz rad etildi.</b>\n\n"
                    f"💰 {fmt(o['amount_uzs'])} so'm balansingizga qaytarildi.",
                    parse_mode="HTML"
                )
            except: pass
            await cb.message.edit_text(cb.message.text + "\n\n❌ <b>Rad etildi, balans qaytarildi.</b>", parse_mode="HTML")
            return
    await cb.answer("❌ Topilmadi!")

# ─── O'YINLAR ────────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_games")
async def cb_games(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db(); games = d.get("games", [])
    game_text = "\n".join([f"  {g['emoji']} {g['name']}" for g in games]) if games else "  Yo'q"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ O'yin qo'shish",  callback_data="adm_add_game")],
        [InlineKeyboardButton(text="❌ O'yin o'chirish",  callback_data="adm_del_game")],
        [InlineKeyboardButton(text="🔙 Orqaga",           callback_data="adm_main")],
    ])
    await cb.message.edit_text(
        f"🎮 <b>O'yinlar ro'yxati</b>\n\n{game_text}\n\n"
        f"<i>Foydalanuvchilar bu ro'yxatni ko'radi va adminga murojaat qiladi</i>",
        parse_mode="HTML", reply_markup=kb
    )

@dp.callback_query(F.data == "adm_add_game")
async def add_game(cb: types.CallbackQuery, state: FSMContext):
    await cb.message.edit_text("🎮 O'yin nomi (masalan: Free Fire, PUBG Mobile, MLBB):")
    await state.set_state(A.game_name)

@dp.message(A.game_name)
async def enter_game_name(msg: types.Message, state: FSMContext):
    await state.update_data(game_name=msg.text.strip())
    await msg.answer("🎮 O'yin uchun emoji (masalan: 🔥, 🎯, ⚔️):")
    await state.set_state(A.game_emoji)

@dp.message(A.game_emoji)
async def enter_game_emoji(msg: types.Message, state: FSMContext):
    data = await state.get_data()
    d = db()
    game = {"name": data["game_name"], "emoji": msg.text.strip()}
    d.setdefault("games", []).append(game)
    sdb(d)
    await msg.answer(f"✅ <b>O'yin qo'shildi!</b>\n\n{game['emoji']} {game['name']}", parse_mode="HTML")
    await state.clear(); await cmd_admin(msg, state)

@dp.callback_query(F.data == "adm_del_game")
async def del_game(cb: types.CallbackQuery):
    d = db(); games = d.get("games", [])
    if not games: await cb.answer("O'yin yo'q!", show_alert=True); return
    btns = [[InlineKeyboardButton(text=f"❌ {g['emoji']} {g['name']}", callback_data=f"del_game_{i}")] for i, g in enumerate(games)]
    btns.append([InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_games")])
    await cb.message.edit_text("O'chirish uchun o'yinni tanlang:", reply_markup=InlineKeyboardMarkup(inline_keyboard=btns))

@dp.callback_query(F.data.startswith("del_game_"))
async def del_game_confirm(cb: types.CallbackQuery):
    idx = int(cb.data.replace("del_game_", ""))
    d = db(); games = d.get("games", [])
    if idx < len(games):
        removed = games.pop(idx)
        d["games"] = games; sdb(d)
        await cb.answer(f"✅ {removed['name']} o'chirildi!", show_alert=True)
    await cb_games(cb)

# ─── NARXLAR ─────────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_prices")
async def cb_prices(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db(); p = d["settings"]["prices"]
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"⭐ 1 Stars: {fmt(p['star'])} so'm",    callback_data="adm_p_star")],
        [InlineKeyboardButton(text=f"👑 3 oy: {fmt(p['pm3'])} so'm",        callback_data="adm_p_pm3")],
        [InlineKeyboardButton(text=f"👑 6 oy: {fmt(p['pm6'])} so'm",        callback_data="adm_p_pm6")],
        [InlineKeyboardButton(text=f"👑 12 oy: {fmt(p['pm12'])} so'm",      callback_data="adm_p_pm12")],
        [InlineKeyboardButton(text="🎁 Gift narxlari",                       callback_data="adm_gift_prices")],
        [InlineKeyboardButton(text=f"📊 SMM foiz: {p.get('smm_margin',20)}%",    callback_data="adm_p_smm_margin")],
        [InlineKeyboardButton(text=f"📱 V-raqam foiz: {p.get('vnum_margin',15)}%", callback_data="adm_p_vnum_margin")],
        [InlineKeyboardButton(text=f"💎 TON foiz: {p.get('ton_margin',5)}%",     callback_data="adm_p_ton_margin")],
        [InlineKeyboardButton(text=f"💵 USDT foiz: {p.get('usdt_margin',5)}%",   callback_data="adm_p_usdt_margin")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_main")],
    ])
    await cb.message.edit_text("💰 <b>Narxlar va foizlar</b>", parse_mode="HTML", reply_markup=kb)

@dp.callback_query(F.data.in_({"adm_p_star","adm_p_pm3","adm_p_pm6","adm_p_pm12","adm_p_smm_margin","adm_p_vnum_margin","adm_p_ton_margin","adm_p_usdt_margin"}))
async def cb_set_price(cb: types.CallbackQuery, state: FSMContext):
    if not is_super(cb.from_user.id): return
    key = cb.data.replace("adm_p_", "")
    labels = {
        "star": "⭐ 1 Stars narxi (so'm)",
        "pm3": "👑 Premium 3 oy narxi (so'm)",
        "pm6": "👑 Premium 6 oy narxi (so'm)",
        "pm12": "👑 Premium 12 oy narxi (so'm)",
        "smm_margin": "📊 SMM ustiga foiz (%) — masalan: 20",
        "vnum_margin": "📱 Virtual raqam ustiga foiz (%) — masalan: 15",
        "ton_margin": "💎 TON ustiga foiz (%) — masalan: 5",
        "usdt_margin": "💵 USDT ustiga foiz (%) — masalan: 5",
    }
    await cb.message.edit_text(f"💰 <b>{labels.get(key, key)}</b>\n\nYangi qiymat kiriting:", parse_mode="HTML")
    await state.update_data(price_key=key); await state.set_state(A.price_key)

@dp.message(A.price_key)
async def enter_price(msg: types.Message, state: FSMContext):
    try:
        v = int(msg.text.replace(" ", "").replace(",", ""))
        if v <= 0: await msg.answer("❌ 0 dan katta bo'lishi kerak!"); return
        data = await state.get_data(); d = db()
        d["settings"]["prices"][data["price_key"]] = v; sdb(d)
        await msg.answer(f"✅ Saqlandi: <b>{fmt(v)}</b>", parse_mode="HTML")
        await state.clear(); await cmd_admin(msg, state)
    except: await msg.answer("❌ Faqat raqam kiriting!")

# ─── GIFT NARXLARI ───────────────────────────────────────────────
@dp.callback_query(F.data == "adm_gift_prices")
async def cb_gift_prices(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db(); gift_prices = d["settings"]["prices"].get("gifts", {})
    gp_text = "\n".join([f"  ID: {k} → {fmt(v)} so'm" for k, v in gift_prices.items()]) if gift_prices else "  Narx belgilanmagan"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💰 Gift narx belgilash", callback_data="adm_set_gift_price")],
        [InlineKeyboardButton(text="🗑 Barcha narxlarni tozalash", callback_data="adm_clear_gift_prices")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_prices")],
    ])
    await cb.message.edit_text(
        f"🎁 <b>Gift narxlari</b>\n\n{gp_text}\n\n"
        f"<i>💡 Gift ID ni bilish uchun botga /gifts yozing</i>",
        parse_mode="HTML", reply_markup=kb
    )

@dp.callback_query(F.data == "adm_set_gift_price")
async def set_gift_price(cb: types.CallbackQuery, state: FSMContext):
    await cb.message.edit_text(
        "🎁 Gift ID kiriting (Telegram Bot API dan):\n\n"
        "<i>Giftlar ro'yxatini ko'rish uchun /gifts yozing</i>",
        parse_mode="HTML"
    )
    await state.set_state(A.gift_id)

@dp.message(A.gift_id)
async def enter_gift_id(msg: types.Message, state: FSMContext):
    await state.update_data(gift_id=msg.text.strip())
    await msg.answer("💰 Bu gift narxi (so'mda):")
    await state.set_state(A.gift_price)

@dp.message(A.gift_price)
async def enter_gift_price(msg: types.Message, state: FSMContext):
    try:
        v = int(msg.text.replace(" ", "").replace(",", ""))
        data = await state.get_data(); d = db()
        d["settings"]["prices"].setdefault("gifts", {})[data["gift_id"]] = v; sdb(d)
        await msg.answer(f"✅ Gift <code>{data['gift_id']}</code> narxi: <b>{fmt(v)} so'm</b>", parse_mode="HTML")
        await state.clear(); await cmd_admin(msg, state)
    except: await msg.answer("❌ Faqat raqam!")

@dp.callback_query(F.data == "adm_clear_gift_prices")
async def clear_gift_prices(cb: types.CallbackQuery):
    d = db(); d["settings"]["prices"]["gifts"] = {}; sdb(d)
    await cb.answer("✅ Barcha gift narxlari o'chirildi!", show_alert=True)
    await cb_gift_prices(cb)

@dp.message(Command("gifts"))
async def cmd_gifts_list(msg: types.Message):
    if not is_admin(msg.from_user.id): return
    import aiohttp
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getAvailableGifts") as r:
                data = await r.json()
        if data.get("ok"):
            gifts = data["result"].get("gifts", [])
            text = "🎁 <b>Mavjud giftlar:</b>\n\n"
            for g in gifts:
                text += f"ID: <code>{g['id']}</code> | {g.get('star_count', '?')} ⭐"
                if g.get("total_count"): text += f" | {g.get('remaining_count', '?')}/{g['total_count']}"
                text += "\n"
            await msg.answer(text, parse_mode="HTML")
        else: await msg.answer("❌ Giftlar ro'yxati olinmadi!")
    except Exception as e: await msg.answer(f"❌ Xato: {e}")

# ─── FOYDALANUVCHILAR ────────────────────────────────────────────
@dp.callback_query(F.data == "adm_users")
async def cb_users(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    d = db()
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 Ro'yxat (1-10)",    callback_data="adm_ulist_1"),
         InlineKeyboardButton(text="🔍 Qidirish",          callback_data="adm_usearch")],
        [InlineKeyboardButton(text="🚫 Bloklash",           callback_data="adm_ban"),
         InlineKeyboardButton(text="✅ Blokdan chiqarish",  callback_data="adm_unban")],
        [InlineKeyboardButton(text="💰 Balans berish",      callback_data="adm_give_bal"),
         InlineKeyboardButton(text="💸 Balans olish",       callback_data="adm_take_bal")],
        [InlineKeyboardButton(text="🔙 Orqaga",             callback_data="adm_main")],
    ])
    banned = len([u for u in d["users"].values() if u.get("banned")])
    await cb.message.edit_text(
        f"👥 <b>Foydalanuvchilar</b>\n\n"
        f"Jami: <b>{len(d['users'])}</b>\nBanlangan: <b>{banned}</b>",
        parse_mode="HTML", reply_markup=kb
    )

@dp.callback_query(F.data.startswith("adm_ulist_"))
async def cb_ulist(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    page = int(cb.data.replace("adm_ulist_", ""))
    d = db(); users = list(d["users"].items())
    per = 10; total = len(users); start = (page-1)*per; end = start+per
    text = f"👥 <b>Foydalanuvchilar</b> ({start+1}-{min(end,total)} / {total})\n\n"
    for uid, u in users[start:end]:
        ban = "🚫" if u.get("banned") else "✅"
        text += f"{ban} <code>{uid}</code> | {u.get('name','?')}\n💰 {fmt(u.get('balance',0))} so'm | 📋 {len(u.get('orders',[]))} ta\n\n"
    nav = []
    if page > 1: nav.append(InlineKeyboardButton(text="◀️", callback_data=f"adm_ulist_{page-1}"))
    if end < total: nav.append(InlineKeyboardButton(text="▶️", callback_data=f"adm_ulist_{page+1}"))
    rows = [nav] if nav else []
    rows.append([InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_users")])
    await cb.message.edit_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))

@dp.callback_query(F.data.in_({"adm_usearch","adm_ban","adm_unban","adm_give_bal","adm_take_bal"}))
async def cb_user_action(cb: types.CallbackQuery, state: FSMContext):
    labels = {
        "adm_usearch"  : "🔍 Foydalanuvchi ID kiriting:",
        "adm_ban"      : "🚫 Bloklash — ID kiriting:",
        "adm_unban"    : "✅ Ochish — ID kiriting:",
        "adm_give_bal" : "💰 Balans BERISH\nFormat: ID SUMMA\n<i>Masalan: 123456789 50000</i>",
        "adm_take_bal" : "💸 Balans OLISH\nFormat: ID SUMMA\n<i>Masalan: 123456789 20000</i>",
    }
    await cb.message.edit_text(labels[cb.data], parse_mode="HTML")
    await state.update_data(user_action=cb.data); await state.set_state(A.ban_id)

@dp.message(A.ban_id)
async def enter_user_action(msg: types.Message, state: FSMContext):
    try:
        parts = msg.text.strip().split(); uid = str(int(parts[0]))
        data = await state.get_data(); d = db(); action = data.get("user_action")
        if uid not in d["users"]:
            await msg.answer("❌ Foydalanuvchi topilmadi!"); await state.clear(); return
        u = d["users"][uid]
        if action == "adm_usearch":
            await msg.answer(
                f"👤 <b>Foydalanuvchi</b>\n\n🆔 <code>{uid}</code>\n"
                f"👤 {u.get('name','?')} (@{u.get('username','?')})\n"
                f"💰 Balans: <b>{fmt(u.get('balance',0))} so'm</b>\n"
                f"📋 Buyurtmalar: <b>{len(u.get('orders',[]))}</b>\n"
                f"👥 Referrallar: <b>{u.get('referrals',0)}</b>\n"
                f"💵 Ref daromad: <b>{fmt(u.get('ref_earned',0))} so'm</b>\n"
                f"🚫 Ban: <b>{'Ha' if u.get('banned') else \"Yo'q\"}</b>\n"
                f"📅 Qo'shilgan: {u.get('joined','?')[:10]}",
                parse_mode="HTML"
            )
        elif action == "adm_ban":
            d["users"][uid]["banned"] = True; sdb(d)
            await msg.answer(f"🚫 <code>{uid}</code> bloklandi!", parse_mode="HTML")
            try: await bot.send_message(int(uid), "🚫 Siz botdan bloklangansiz.")
            except: pass
        elif action == "adm_unban":
            d["users"][uid]["banned"] = False; sdb(d)
            await msg.answer(f"✅ <code>{uid}</code> blokdan chiqarildi!", parse_mode="HTML")
        elif action == "adm_give_bal":
            if len(parts) < 2: await msg.answer("❌ Format: ID SUMMA"); return
            amt = int(parts[1])
            d["users"][uid]["balance"] = d["users"][uid].get("balance", 0) + amt; sdb(d)
            try: await bot.send_message(int(uid), f"✅ Hisobingizga <b>+{fmt(amt)} so'm</b> qo'shildi!", parse_mode="HTML")
            except: pass
            await msg.answer(f"✅ +{fmt(amt)} so'm berildi!", parse_mode="HTML")
            await send_log(f"💰 Admin balans berdi: {uid} +{fmt(amt)} so'm")
        elif action == "adm_take_bal":
            if len(parts) < 2: await msg.answer("❌ Format: ID SUMMA"); return
            amt = int(parts[1])
            cur = d["users"][uid].get("balance", 0)
            d["users"][uid]["balance"] = max(0, cur - amt); sdb(d)
            await msg.answer(f"💸 -{fmt(amt)} so'm olindi! (Joriy: {fmt(d['users'][uid]['balance'])} so'm)", parse_mode="HTML")
        await state.clear(); await cmd_admin(msg, state)
    except Exception as e: await msg.answer(f"❌ Xato: {e}")

# ─── SCREENSHOTLAR ───────────────────────────────────────────────
@dp.callback_query(F.data == "adm_screens")
async def cb_screens(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    d = db()
    screens = {k: v for k, v in d.get("pending_topups", {}).items() if v.get("method") == "screenshot"}
    if not screens:
        await cb.answer("📸 Kutilayotgan screenshot yo'q!", show_alert=True); return
    text = f"📸 <b>Kutilayotgan screenshotlar ({len(screens)}):</b>\n\n"
    for txn_id, t in list(screens.items())[:10]:
        u = d["users"].get(t["uid"], {})
        text += f"👤 {u.get('name', '?')} | 💰 {fmt(t['amount'])} so'm | 🔑 <code>{txn_id[:8]}</code>\n"
    await cb.message.edit_text(text, parse_mode="HTML", reply_markup=back_kb())

# ─── BUYURTMALAR ─────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_orders")
async def cb_orders(cb: types.CallbackQuery):
    if not is_admin(cb.from_user.id): return
    d = db(); orders = d["orders"][-15:]
    if not orders: await cb.answer("Buyurtma yo'q!", show_alert=True); return
    st = {"completed": "✅", "failed": "❌", "processing": "⏳", "pending": "⏰", "cancelled": "🚫"}
    svc_l = {"stars": "⭐", "premium": "👑", "gift": "🎁", "smm": "📊", "vnum": "📱", "ton": "💎"}
    text = "📋 <b>So'nggi buyurtmalar:</b>\n\n"
    for o in reversed(orders):
        icon = svc_l.get(o.get("service", ""), "📦")
        text += f"{st.get(o['status'], '❓')} #{o['id']} {icon} @{o.get('username', o.get('user_id', '?'))} — {fmt(o['price'])} so'm\n"
    await cb.message.edit_text(text, parse_mode="HTML", reply_markup=back_kb())

# ─── BROADCAST ───────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_broadcast")
async def cb_broadcast(cb: types.CallbackQuery, state: FSMContext):
    if not is_admin(cb.from_user.id): return
    await cb.message.edit_text("📢 Xabar matnini yozing:")
    await state.set_state(A.broadcast)

@dp.message(A.broadcast)
async def enter_broadcast(msg: types.Message, state: FSMContext):
    d = db(); sent = failed = 0
    prog = await msg.answer(f"⏳ 0/{len(d['users'])}")
    for i, uid in enumerate(d["users"]):
        try: await bot.send_message(int(uid), f"📢 <b>Xabar:</b>\n\n{msg.text}", parse_mode="HTML"); sent += 1
        except: failed += 1
        if i % 20 == 0:
            try: await prog.edit_text(f"⏳ {i}/{len(d['users'])}")
            except: pass
        await asyncio.sleep(0.05)
    await prog.edit_text(f"✅ Broadcast tugadi!\n✅ Yuborildi: {sent}\n❌ Xato: {failed}")
    await state.clear(); await cmd_admin(msg, state)

# ─── KARTA ───────────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_card")
async def cb_card(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db(); s = d["settings"]
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"💳 Karta: {s.get('card_number','Sozlanmagan')}", callback_data="adm_set_card")],
        [InlineKeyboardButton(text=f"👤 Egasi: {s.get('card_holder','Sozlanmagan')}", callback_data="adm_set_holder")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_main")],
    ])
    await cb.message.edit_text("💳 <b>Karta sozlamalari</b>", parse_mode="HTML", reply_markup=kb)

@dp.callback_query(F.data.in_({"adm_set_card", "adm_set_holder"}))
async def cb_set_card(cb: types.CallbackQuery, state: FSMContext):
    labels = {
        "adm_set_card":   ("💳 Yangi karta raqami (masalan: 8600 1234 5678 9012):", A.card_number),
        "adm_set_holder": ("👤 Karta egasi to'liq ismi (lotin harfida):", A.card_holder),
    }
    lbl, st = labels[cb.data]
    await cb.message.edit_text(lbl); await state.set_state(st)

@dp.message(A.card_number)
async def e_card_num(msg: types.Message, state: FSMContext):
    d = db(); d["settings"]["card_number"] = msg.text.strip(); sdb(d)
    await msg.answer(f"✅ Karta: <code>{msg.text.strip()}</code>", parse_mode="HTML")
    await state.clear(); await cmd_admin(msg, state)

@dp.message(A.card_holder)
async def e_card_holder(msg: types.Message, state: FSMContext):
    d = db(); d["settings"]["card_holder"] = msg.text.strip(); sdb(d)
    await msg.answer(f"✅ Egasi: <b>{msg.text.strip()}</b>", parse_mode="HTML")
    await state.clear(); await cmd_admin(msg, state)

# ─── SOZLAMALAR ──────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_settings")
async def cb_settings(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db(); s = d["settings"]
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"⭐ Min Stars: {s['min_stars']}", callback_data="adm_set_minstars")],
        [InlineKeyboardButton(text=f"👥 Ref bonus: {fmt(s['referral_bonus'])} so'm", callback_data="adm_set_refbonus")],
        [InlineKeyboardButton(text="💬 Support linki",  callback_data="adm_set_support")],
        [InlineKeyboardButton(text="📣 Kanal linki",    callback_data="adm_set_chanlink")],
        [InlineKeyboardButton(text=f"💎 TON wallet: {s.get('ton_wallet','Sozlanmagan')[:20]}...", callback_data="adm_set_ton_wallet")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_main")],
    ])
    await cb.message.edit_text("⚙️ <b>Sozlamalar</b>", parse_mode="HTML", reply_markup=kb)

@dp.callback_query(F.data.in_({"adm_set_minstars","adm_set_refbonus","adm_set_support","adm_set_chanlink","adm_set_ton_wallet"}))
async def cb_set_settings(cb: types.CallbackQuery, state: FSMContext):
    labels = {
        "adm_set_minstars"  : ("⭐ Minimum Stars soni:", A.min_stars),
        "adm_set_refbonus"  : ("👥 Referral bonus (so'm):", A.ref_bonus),
        "adm_set_support"   : ("💬 Support linki (https://t.me/...):", A.support),
        "adm_set_chanlink"  : ("📣 Kanal linki (https://t.me/...):", A.channel_link),
        "adm_set_ton_wallet": ("💎 TON wallet manzili (UQ...):", A.margin_key),
    }
    lbl, st = labels[cb.data]
    await cb.message.edit_text(lbl)
    await state.update_data(settings_key=cb.data)
    await state.set_state(st)

@dp.message(A.min_stars)
async def e_min(msg: types.Message, state: FSMContext):
    try:
        v = int(msg.text); d = db(); d["settings"]["min_stars"] = v; sdb(d)
        await msg.answer(f"✅ Min Stars: {v}")
        await state.clear(); await cmd_admin(msg, state)
    except: await msg.answer("❌ Raqam!")

@dp.message(A.ref_bonus)
async def e_ref(msg: types.Message, state: FSMContext):
    try:
        v = int(msg.text.replace(" ", "")); d = db(); d["settings"]["referral_bonus"] = v; sdb(d)
        await msg.answer(f"✅ Ref bonus: {fmt(v)} so'm")
        await state.clear(); await cmd_admin(msg, state)
    except: await msg.answer("❌ Raqam!")

@dp.message(A.support)
async def e_sup(msg: types.Message, state: FSMContext):
    d = db(); d["settings"]["support_link"] = msg.text.strip(); sdb(d)
    await msg.answer("✅ Support linki saqlandi!")
    await state.clear(); await cmd_admin(msg, state)

@dp.message(A.channel_link)
async def e_chan(msg: types.Message, state: FSMContext):
    d = db(); d["settings"]["channel_link"] = msg.text.strip(); sdb(d)
    await msg.answer("✅ Kanal linki saqlandi!")
    await state.clear(); await cmd_admin(msg, state)

@dp.message(A.margin_key)
async def e_margin_key(msg: types.Message, state: FSMContext):
    data = await state.get_data()
    key = data.get("settings_key", "")
    if key == "adm_set_ton_wallet":
        d = db(); d["settings"]["ton_wallet"] = msg.text.strip(); sdb(d)
        await msg.answer(f"✅ TON wallet saqlandi!")
    await state.clear(); await cmd_admin(msg, state)

# ─── LOGO ────────────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_logo")
async def cb_logo(cb: types.CallbackQuery, state: FSMContext):
    if not is_super(cb.from_user.id): return
    await cb.message.edit_text("🖼 Logo rasmini yuboring:"); await state.set_state(A.logo)

@dp.message(A.logo)
async def enter_logo(msg: types.Message, state: FSMContext):
    if not msg.photo: await msg.answer("❌ Rasm yuboring!"); return
    d = db(); d["settings"]["logo_file_id"] = msg.photo[-1].file_id; sdb(d)
    await msg.answer("✅ Logo saqlandi!")
    await state.clear(); await cmd_admin(msg, state)

# ─── ADMINLAR ────────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_admins")
async def cb_admins(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db(); admins = d.get("admins", {})
    at = "\n".join([f"• <code>{a}</code>" for a in admins]) if admins else "Yo'q"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Admin qo'shish",  callback_data="adm_add_admin"),
         InlineKeyboardButton(text="➖ Admin o'chirish", callback_data="adm_del_admin")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_main")],
    ])
    await cb.message.edit_text(f"👑 <b>Adminlar:</b>\n\n{at}", parse_mode="HTML", reply_markup=kb)

@dp.callback_query(F.data.in_({"adm_add_admin", "adm_del_admin"}))
async def manage_admin(cb: types.CallbackQuery, state: FSMContext):
    action = "qo'shish" if cb.data == "adm_add_admin" else "o'chirish"
    await cb.message.edit_text(f"👑 Admin ID ({action}):")
    await state.update_data(admin_action=cb.data); await state.set_state(A.admin_id)

@dp.message(A.admin_id)
async def enter_admin(msg: types.Message, state: FSMContext):
    try:
        aid = int(msg.text.strip())
        if aid == SUPER_ADMIN_ID: await msg.answer("❌ Super adminni o'zgartirish mumkin emas!"); await state.clear(); return
        data = await state.get_data(); d = db()
        if data.get("admin_action") == "adm_add_admin":
            d["admins"][str(aid)] = {"added": datetime.now().isoformat()}; sdb(d)
            await msg.answer(f"✅ Admin qo'shildi: <code>{aid}</code>", parse_mode="HTML")
        else:
            if str(aid) in d["admins"]:
                del d["admins"][str(aid)]; sdb(d)
                await msg.answer(f"✅ Admin o'chirildi: <code>{aid}</code>", parse_mode="HTML")
            else: await msg.answer("❌ Topilmadi!")
        await state.clear(); await cmd_admin(msg, state)
    except: await msg.answer("❌ Noto'g'ri ID!")

# ─── PROMO ───────────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_promos")
async def cb_promos(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db(); promos = d.get("promo_codes", {})
    pt = "\n".join([f"• <code>{k}</code> — {v['discount']}% | {v.get('used',0)}/{v.get('limit','∞')}" for k, v in promos.items()]) if promos else "Yo'q"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Yaratish",    callback_data="adm_new_promo"),
         InlineKeyboardButton(text="🗑 Tozalash",    callback_data="adm_clear_promos")],
        [InlineKeyboardButton(text="🔙 Orqaga",      callback_data="adm_main")],
    ])
    await cb.message.edit_text(f"🎁 <b>Promo kodlar:</b>\n\n{pt}", parse_mode="HTML", reply_markup=kb)

@dp.callback_query(F.data == "adm_new_promo")
async def new_promo(cb: types.CallbackQuery, state: FSMContext):
    await cb.message.edit_text("🎁 Promo kod nomi (masalan: SUMMER25):")
    await state.set_state(A.promo_code)

@dp.message(A.promo_code)
async def enter_promo_code(msg: types.Message, state: FSMContext):
    await state.update_data(promo_code=msg.text.strip().upper())
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛍 Hammasi", callback_data="pp_all")],
        [InlineKeyboardButton(text="⭐ Stars",    callback_data="pp_star"),
         InlineKeyboardButton(text="👑 Premium",  callback_data="pp_premium")],
        [InlineKeyboardButton(text="🎁 Giftlar",  callback_data="pp_gift"),
         InlineKeyboardButton(text="📊 SMM",      callback_data="pp_smm")],
    ])
    await msg.answer("🛍 Qaysi mahsulot uchun?", reply_markup=kb)
    await state.set_state(A.promo_product)

@dp.callback_query(F.data.startswith("pp_"))
async def cb_promo_prod(cb: types.CallbackQuery, state: FSMContext):
    await state.update_data(promo_product=cb.data[3:])
    await cb.message.edit_text("📈 Chegirma foizi (1-90%):")
    await state.set_state(A.promo_disc)

@dp.message(A.promo_disc)
async def enter_promo_disc(msg: types.Message, state: FSMContext):
    try:
        v = int(msg.text)
        if v < 1 or v > 90: await msg.answer("❌ 1-90 oralig'ida!"); return
        await state.update_data(promo_disc=v)
        await msg.answer("🔢 Necha kishi ishlatishi mumkin? (0 = cheksiz):")
        await state.set_state(A.promo_limit)
    except: await msg.answer("❌ Faqat raqam!")

@dp.message(A.promo_limit)
async def enter_promo_limit(msg: types.Message, state: FSMContext):
    try:
        limit = int(msg.text); data = await state.get_data(); d = db()
        d["promo_codes"][data["promo_code"]] = {
            "discount": data["promo_disc"], "product": data.get("promo_product", "all"),
            "limit": limit if limit > 0 else None, "used": 0,
            "created_at": datetime.now().isoformat()
        }; sdb(d)
        await msg.answer(
            f"✅ <b>Promo kod yaratildi!</b>\n\n"
            f"🎁 Kod: <code>{data['promo_code']}</code>\n"
            f"📉 Chegirma: {data['promo_disc']}%\n"
            f"🔢 Limit: {'Cheksiz' if limit == 0 else limit}",
            parse_mode="HTML"
        )
        await state.clear(); await cmd_admin(msg, state)
    except: await msg.answer("❌ Faqat raqam!")

@dp.callback_query(F.data == "adm_clear_promos")
async def clear_promos(cb: types.CallbackQuery):
    d = db(); d["promo_codes"] = {}; sdb(d)
    await cb.answer("✅ Promo kodlar tozalandi!", show_alert=True)
    await cb_promos(cb)

# ─── API TOKEN ───────────────────────────────────────────────────
@dp.callback_query(F.data == "adm_dev_token")
async def cb_dev_token(cb: types.CallbackQuery):
    if not is_super(cb.from_user.id): return
    d = db()
    old = [t for t, v in d.get("api_keys", {}).items() if v.get("uid") == str(cb.from_user.id)]
    for t in old: del d["api_keys"][t]
    token = secrets.token_hex(32)
    d.setdefault("api_keys", {})[token] = {
        "uid": str(cb.from_user.id), "created_at": datetime.now().isoformat(),
        "active": True, "requests": 0, "last_used": None
    }; sdb(d)
    await cb.message.edit_text(
        f"🔑 <b>Reseller API Token</b>\n\n"
        f"<code>{token}</code>\n\n"
        f"<b>Ishlatish usuli:</b>\n"
        f"<code>X-API-Key: {token}</code>\n\n"
        f"📖 Hujjat: <code>/api/v1/docs</code>\n\n"
        f"⚠️ Bu tokenni hech kimga bermang!",
        parse_mode="HTML", reply_markup=back_kb()
    )

# ─── BOT YOQISH/O'CHIRISH ────────────────────────────────────────
@dp.callback_query(F.data == "adm_toggle_bot")
async def toggle_bot(cb: types.CallbackQuery, state: FSMContext):
    if not is_super(cb.from_user.id): return
    d = db(); d["settings"]["bot_active"] = not d["settings"]["bot_active"]; sdb(d)
    status = "✅ Yoqildi" if d["settings"]["bot_active"] else "❌ O'chirildi"
    await cb.answer(f"Bot {status}", show_alert=True)
    await cb_adm_main(cb, state)

# ─── MAIN ────────────────────────────────────────────────────────
async def main():
    log.info("🚀 U-Gift Bot v4 ishga tushmoqda...")
    try: await bot.set_chat_menu_button(menu_button=MenuButtonDefault())
    except: pass
    await dp.start_polling(bot, skip_updates=True)

if __name__ == "__main__":
    asyncio.run(main())
