#!/bin/bash
# ============================================================
# PIPS — AWS VPS Deploy Script (Ubuntu)
# Run once: chmod +x deploy.sh && ./deploy.sh
# ============================================================

set -e
echo "🚀 PIPS Deploy starting..."

# 1. Update system
sudo apt update && sudo apt upgrade -y

# 2. Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs nginx certbot python3-certbot-nginx

# 3. Install dependencies
cd /var/www/pips
npm install

# 4. Copy env
cp .env.example .env.local
echo "⚠️  Edit .env.local with your API keys before continuing!"
echo "    nano .env.local"
read -p "Press enter when done..."

# 5. Build
npm run build

# 6. Nginx
sudo cp nginx.conf /etc/nginx/sites-available/pips
sudo ln -sf /etc/nginx/sites-available/pips /etc/nginx/sites-enabled/pips
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# 7. SSL — replace yourdomain.com
read -p "Enter your domain (e.g. pips.io): " DOMAIN
sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos -m admin@$DOMAIN
sudo sed -i "s/yourdomain.com/$DOMAIN/g" /etc/nginx/sites-available/pips
sudo nginx -t && sudo systemctl reload nginx

echo "✅ PIPS deployed at https://$DOMAIN"
