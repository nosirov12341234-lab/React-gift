# PIPS — Solana NFT & Token Platform

> Create, trade, and own NFTs and tokens on Solana. Built for AWS VPS.

---

## Features

- 👻 **Wallet Login** — Phantom, Solflare, Backpack (no email/password)
- 🎨 **NFT Market** — Lazy mint: NFT mints to buyer's wallet on purchase
- 🪙 **Token Launch** — Deploy SPL tokens with bonding curve (Pump.fun style)
- 📈 **Token Trading** — Trade PIPS launches + all Solana tokens (GMGN/DexScreener)
- ⚙️ **Admin Control** — All fees configured via `.env` file

---

## Quick Start

### 1. Get API Keys (both free)

| Service | URL | Time |
|---------|-----|------|
| Helius | https://helius.dev | 2 min |
| NFT.Storage | https://nft.storage | 2 min |

### 2. Install & Run Locally

```bash
npm install
cp .env.example .env.local
# Edit .env.local with your keys
npm start
```

### 3. Deploy to AWS VPS

```bash
# Upload files to server
scp -r . ubuntu@your-server:/var/www/pips

# SSH into server
ssh ubuntu@your-server

# Run deploy script
cd /var/www/pips
chmod +x deploy.sh
./deploy.sh
```

---

## Configure Fees (`.env.local`)

```env
REACT_APP_PIPS_WALLET=your_wallet      # Where fees go
REACT_APP_NFT_CREATE_FREE=false        # true = free NFT listing
REACT_APP_NFT_CREATE_FEE=0.05         # SOL per NFT listing
REACT_APP_NFT_BUY_FEE=2.5            # % on NFT sales
REACT_APP_TOKEN_CREATE_FEE=0.02       # SOL per token launch
REACT_APP_TOKEN_TRADE_FEE=1           # % on token trades
REACT_APP_MIN_LIQUIDITY=0.5           # Min SOL to launch token
```

---

## Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18 + React Router |
| Styling | CSS Variables + Custom |
| Charts | Recharts |
| Blockchain | Solana + Metaplex |
| NFT Storage | IPFS via NFT.Storage |
| Token Data | DexScreener API (free) |
| NFT Data | Magic Eden API (free) |
| Swap | Jupiter Aggregator (free) |
| Server | Nginx on AWS VPS |
| SSL | Let's Encrypt (free) |

---

## Revenue Model

| Action | Fee | Who Pays |
|--------|-----|----------|
| NFT listing | 0.05 SOL (configurable) | Seller |
| NFT sale | 2.5% (configurable) | Buyer |
| Token launch | 0.02 SOL (configurable) | Creator |
| Token trade | 1% (configurable) | Trader |
| Swap | 1% (configurable) | Swapper |

All fees go directly to `REACT_APP_PIPS_WALLET`.

---

## Project Structure

```
pips/
├── src/
│   ├── context/
│   │   └── WalletContext.js     # Wallet state
│   ├── lib/
│   │   └── mockData.js          # Demo data (replace with real APIs)
│   ├── components/
│   │   ├── layout/Navbar.js
│   │   └── ui/WalletModal.js
│   ├── pages/
│   │   ├── HomePage.js
│   │   ├── NFTPage.js
│   │   ├── NFTDetailPage.js
│   │   ├── TokensPage.js
│   │   ├── TokenDetailPage.js
│   │   └── CreatePage.js
│   └── styles/globals.css
├── .env.example                 # Config template
├── nginx.conf                   # Nginx config
├── deploy.sh                    # Deploy script
└── package.json
```

---

## Next Steps (Production)

1. **Replace mock data** with real Helius + DexScreener API calls
2. **Implement smart contracts** for bonding curve (Anchor/Rust)
3. **Add real Metaplex** NFT minting
4. **Add Jupiter swap** integration
5. **Add PostgreSQL** for listing history and analytics

---

Built with ❤️ on Solana
