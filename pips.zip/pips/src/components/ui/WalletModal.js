import React from 'react';
import { X } from 'lucide-react';
import { useWallet, SUPPORTED_WALLETS } from '../../context/WalletContext';

export default function WalletModal() {
  const { connect, connecting, setShowModal } = useWallet();

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000,
      background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '20px'
    }} onClick={() => setShowModal(false)}>
      <div onClick={e => e.stopPropagation()} style={{
        background: '#0f0f1a',
        border: '1px solid #2e2e5a',
        borderRadius: '16px',
        padding: '32px',
        width: '100%',
        maxWidth: '400px',
        position: 'relative',
        animation: 'slide-in 0.3s ease'
      }}>
        <button onClick={() => setShowModal(false)} style={{
          position: 'absolute', top: '16px', right: '16px',
          background: 'transparent', border: 'none', color: '#8888aa',
          cursor: 'pointer', padding: '4px'
        }}>
          <X size={20} />
        </button>

        <div style={{ marginBottom: '24px' }}>
          <div style={{ fontSize: '22px', fontFamily: 'Syne', fontWeight: 800, color: '#f0f0ff', marginBottom: '6px' }}>
            Connect Wallet
          </div>
          <div style={{ fontSize: '13px', color: '#8888aa', fontFamily: 'Space Mono' }}>
            Wallet = Login. No email. No password.
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {SUPPORTED_WALLETS.map(w => (
            <button key={w.id} onClick={() => connect(w.id)} disabled={connecting} style={{
              display: 'flex', alignItems: 'center', gap: '14px',
              padding: '14px 18px',
              background: '#12121f',
              border: '1px solid #1e1e3a',
              borderRadius: '10px',
              cursor: connecting ? 'not-allowed' : 'pointer',
              transition: 'all 0.2s',
              color: '#f0f0ff',
              fontFamily: 'Syne',
              fontWeight: 600,
              fontSize: '15px',
              opacity: connecting ? 0.6 : 1,
            }}
            onMouseEnter={e => { if (!connecting) { e.currentTarget.style.borderColor = w.color; e.currentTarget.style.background = '#1a1a2e'; }}}
            onMouseLeave={e => { e.currentTarget.style.borderColor = '#1e1e3a'; e.currentTarget.style.background = '#12121f'; }}
            >
              <span style={{ fontSize: '24px' }}>{w.icon}</span>
              <span>{w.name}</span>
              {connecting && <span style={{ marginLeft: 'auto', width: '16px', height: '16px', border: '2px solid #444466', borderTopColor: w.color, borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} />}
            </button>
          ))}
        </div>

        <div style={{ marginTop: '20px', padding: '12px', background: 'rgba(0,255,136,0.05)', borderRadius: '8px', border: '1px solid rgba(0,255,136,0.1)' }}>
          <div style={{ fontSize: '11px', fontFamily: 'Space Mono', color: '#00ff88', letterSpacing: '0.05em' }}>
            🔒 Your wallet — your keys. PIPS never stores your private key.
          </div>
        </div>
      </div>
    </div>
  );
}
