import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Wallet, ChevronDown, LogOut, Copy, Check } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

export default function Navbar() {
  const { wallet, disconnect, setShowModal } = useWallet();
  const [dropOpen, setDropOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const location = useLocation();

  const links = [
    { path: '/', label: 'Home' },
    { path: '/nft', label: 'NFT Market' },
    { path: '/tokens', label: 'Tokens' },
    { path: '/create', label: 'Create' },
  ];

  const copyAddress = () => {
    if (wallet) {
      navigator.clipboard.writeText(wallet.address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      background: 'rgba(10,10,15,0.9)', backdropFilter: 'blur(12px)',
      borderBottom: '1px solid #1e1e3a',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 24px', height: '64px',
    }}>
      {/* Logo */}
      <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <div style={{
          width: '32px', height: '32px', borderRadius: '8px',
          background: 'linear-gradient(135deg, #00ff88, #7c3aed)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '16px', fontWeight: 900, color: '#000', fontFamily: 'Space Mono',
        }}>P</div>
        <span style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '20px', color: '#f0f0ff', letterSpacing: '-0.02em' }}>
          PIPS
        </span>
      </Link>

      {/* Nav Links */}
      <div style={{ display: 'flex', gap: '4px' }}>
        {links.map(link => (
          <Link key={link.path} to={link.path} style={{
            padding: '6px 14px',
            borderRadius: '6px',
            textDecoration: 'none',
            fontFamily: 'Space Mono',
            fontSize: '12px',
            fontWeight: 700,
            letterSpacing: '0.04em',
            color: location.pathname === link.path ? '#00ff88' : '#8888aa',
            background: location.pathname === link.path ? 'rgba(0,255,136,0.08)' : 'transparent',
            transition: 'all 0.2s',
          }}>
            {link.label}
          </Link>
        ))}
      </div>

      {/* Wallet Button */}
      <div style={{ position: 'relative' }}>
        {wallet ? (
          <>
            <button onClick={() => setDropOpen(!dropOpen)} style={{
              display: 'flex', alignItems: 'center', gap: '8px',
              padding: '8px 14px',
              background: '#12121f',
              border: '1px solid #2e2e5a',
              borderRadius: '8px',
              cursor: 'pointer',
              color: '#f0f0ff',
              fontFamily: 'Space Mono',
              fontSize: '12px',
              transition: 'all 0.2s',
            }}>
              <span style={{ fontSize: '16px' }}>{wallet.icon}</span>
              <span style={{ color: '#00ff88' }}>{wallet.shortAddress}</span>
              <span style={{ color: '#8888aa' }}>|</span>
              <span>{wallet.balance} SOL</span>
              <ChevronDown size={14} color="#8888aa" />
            </button>

            {dropOpen && (
              <div style={{
                position: 'absolute', top: '48px', right: 0,
                background: '#0f0f1a', border: '1px solid #2e2e5a',
                borderRadius: '10px', padding: '8px', minWidth: '220px',
                animation: 'slide-in 0.2s ease',
              }}>
                <div style={{ padding: '10px 12px', borderBottom: '1px solid #1e1e3a', marginBottom: '6px' }}>
                  <div style={{ fontSize: '11px', color: '#8888aa', fontFamily: 'Space Mono', marginBottom: '4px' }}>BALANCE</div>
                  <div style={{ fontSize: '18px', fontFamily: 'Syne', fontWeight: 700, color: '#00ff88' }}>{wallet.balance} SOL</div>
                  <div style={{ fontSize: '12px', color: '#8888aa', fontFamily: 'Space Mono' }}>${wallet.usdBalance} USD</div>
                </div>
                <button onClick={copyAddress} style={{
                  display: 'flex', alignItems: 'center', gap: '8px',
                  width: '100%', padding: '8px 12px', borderRadius: '6px',
                  background: 'transparent', border: 'none', cursor: 'pointer',
                  color: '#f0f0ff', fontFamily: 'Space Mono', fontSize: '12px',
                  transition: 'background 0.2s',
                }}
                onMouseEnter={e => e.currentTarget.style.background = '#1a1a2e'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  {copied ? <Check size={14} color="#00ff88" /> : <Copy size={14} />}
                  {copied ? 'Copied!' : 'Copy Address'}
                </button>
                <button onClick={() => { disconnect(); setDropOpen(false); }} style={{
                  display: 'flex', alignItems: 'center', gap: '8px',
                  width: '100%', padding: '8px 12px', borderRadius: '6px',
                  background: 'transparent', border: 'none', cursor: 'pointer',
                  color: '#ff2d78', fontFamily: 'Space Mono', fontSize: '12px',
                  transition: 'background 0.2s',
                }}
                onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,45,120,0.08)'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  <LogOut size={14} />
                  Disconnect
                </button>
              </div>
            )}
          </>
        ) : (
          <button onClick={() => setShowModal(true)} className="btn btn-primary" style={{ gap: '8px' }}>
            <Wallet size={15} />
            Connect Wallet
          </button>
        )}
      </div>
    </nav>
  );
}
