import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { WalletProvider } from './context/WalletContext';
import Navbar from './components/layout/Navbar';
import WalletModal from './components/ui/WalletModal';
import HomePage from './pages/HomePage';
import NFTPage from './pages/NFTPage';
import NFTDetailPage from './pages/NFTDetailPage';
import TokensPage from './pages/TokensPage';
import TokenDetailPage from './pages/TokenDetailPage';
import CreatePage from './pages/CreatePage';
import './styles/globals.css';
import { useWallet } from './context/WalletContext';

function AppInner() {
  const { showModal } = useWallet();
  return (
    <BrowserRouter>
      <Navbar />
      {showModal && <WalletModal />}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/nft" element={<NFTPage />} />
        <Route path="/nft/:id" element={<NFTDetailPage />} />
        <Route path="/tokens" element={<TokensPage />} />
        <Route path="/tokens/:id" element={<TokenDetailPage />} />
        <Route path="/create" element={<CreatePage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <WalletProvider>
      <AppInner />
    </WalletProvider>
  );
}
