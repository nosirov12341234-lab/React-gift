import React, { createContext, useContext, useState, useCallback } from 'react';

const WalletContext = createContext(null);

export const SUPPORTED_WALLETS = [
  { id: 'phantom', name: 'Phantom', icon: '👻', color: '#ab9ff2' },
  { id: 'solflare', name: 'Solflare', icon: '🔥', color: '#fc8d4d' },
  { id: 'backpack', name: 'Backpack', icon: '🎒', color: '#e33a3a' },
  { id: 'coinbase', name: 'Coinbase', icon: '🔵', color: '#0052ff' },
];

export function WalletProvider({ children }) {
  const [wallet, setWallet] = useState(null);
  const [connecting, setConnecting] = useState(false);
  const [showModal, setShowModal] = useState(false);

  const connect = useCallback(async (walletId) => {
    setConnecting(true);
    await new Promise(r => setTimeout(r, 1200));
    const w = SUPPORTED_WALLETS.find(w => w.id === walletId);
    const address = '7xKj' + Math.random().toString(36).substr(2,6).toUpperCase() + '3mNp' + Math.random().toString(36).substr(2,4).toUpperCase();
    setWallet({
      id: walletId,
      name: w.name,
      icon: w.icon,
      address,
      shortAddress: address.slice(0,4) + '...' + address.slice(-4),
      balance: (Math.random() * 20 + 1).toFixed(3),
      usdBalance: ((Math.random() * 20 + 1) * 150).toFixed(2),
    });
    setConnecting(false);
    setShowModal(false);
  }, []);

  const disconnect = useCallback(() => {
    setWallet(null);
  }, []);

  return (
    <WalletContext.Provider value={{ wallet, connecting, connect, disconnect, showModal, setShowModal }}>
      {children}
    </WalletContext.Provider>
  );
}

export const useWallet = () => useContext(WalletContext);
