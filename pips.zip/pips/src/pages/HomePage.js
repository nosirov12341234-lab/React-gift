import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Image, Coins, Zap, ArrowRight, Activity } from 'lucide-react';
import { useWallet } from '../context/WalletContext';
import { MOCK_NFTS, MOCK_PIPS_TOKENS, STATS } from '../lib/mockData';

export default function HomePage() {
  const { setShowModal, wallet } = useWallet();
  const topTokens = MOCK_PIPS_TOKENS.slice(0, 4);
  const topNFTs = MOCK_NFTS.slice(0, 4);

  return (
    <div style={{ padding: '80px 0 60px' }}>
      {/* Hero */}
      <div className="grid-noise" style={{
        minHeight: '500px', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', textAlign: 'center',
        padding: '80px 24px', position: 'relative', overflow: 'hidden',
      }}>
        {/* Glow orbs */}
        <div style={{
          position: 'absolute', width: '400px', height: '400px',
          background: 'radial-gradient(circle, rgba(0,255,136,0.08) 0%, transparent 70%)',
          top: '50%', left: '50%', transform: 'translate(-50%,-50%)', pointerEvents: 'none',
        }} />

        <div className="badge badge-green" style={{ marginBottom: '20px', animation: 'float 3s ease-in-out infinite' }}>
          ⚡ Built on Solana
        </div>

        <h1 style={{
          fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(40px, 8vw, 80px)',
          lineHeight: 1.05, letterSpacing: '-0.03em', color: '#f0f0ff',
          marginBottom: '20px', maxWidth: '800px',
        }}>
          Create. Trade.<br />
          <span style={{ color: '#00ff88' }}>Own Everything.</span>
        </h1>

        <p style={{
          fontFamily: 'Space Mono', fontSize: '14px', color: '#8888aa',
          maxWidth: '480px', lineHeight: 1.7, marginBottom: '36px',
        }}>
          Mint NFTs, launch tokens, and trade meme coins — all from one platform.
          Connect your Solana wallet and start building.
        </p>

        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {wallet ? (
            <>
              <Link to="/nft" className="btn btn-primary" style={{ fontSize: '14px', padding: '12px 28px' }}>
                <Image size={16} /> NFT Market
              </Link>
              <Link to="/tokens" className="btn btn-secondary" style={{ fontSize: '14px', padding: '12px 28px' }}>
                <Coins size={16} /> Trade Tokens
              </Link>
            </>
          ) : (
            <>
              <button onClick={() => setShowModal(true)} className="btn btn-primary" style={{ fontSize: '14px', padding: '12px 28px' }}>
                <Zap size={16} /> Connect & Start
              </button>
              <Link to="/nft" className="btn btn-secondary" style={{ fontSize: '14px', padding: '12px 28px' }}>
                Browse NFTs
              </Link>
            </>
          )}
        </div>
      </div>

      {/* Stats */}
      <div style={{ padding: '0 24px', maxWidth: '1200px', margin: '0 auto 60px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
          {[
            { label: 'Total Volume', value: STATS.totalVolume, icon: <Activity size={18} color="#00ff88" /> },
            { label: 'NFTs Sold', value: STATS.nftsSold, icon: <Image size={18} color="#7c3aed" /> },
            { label: 'Tokens Created', value: STATS.tokensCreated, icon: <Coins size={18} color="#00d4ff" /> },
            { label: 'Platform Fees', value: STATS.totalFees, icon: <TrendingUp size={18} color="#ff2d78" /> },
          ].map((stat, i) => (
            <div key={i} className="card" style={{ padding: '20px 24px', textAlign: 'center' }}>
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '10px' }}>{stat.icon}</div>
              <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '26px', color: '#f0f0ff', marginBottom: '4px' }}>{stat.value}</div>
              <div className="tag">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Trending Tokens */}
      <div style={{ padding: '0 24px', maxWidth: '1200px', margin: '0 auto 60px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
          <div>
            <div className="tag" style={{ marginBottom: '6px' }}>🔥 Trending</div>
            <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '24px', color: '#f0f0ff' }}>Hot Tokens</h2>
          </div>
          <Link to="/tokens" style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#00ff88', fontFamily: 'Space Mono', fontSize: '12px', textDecoration: 'none' }}>
            View All <ArrowRight size={14} />
          </Link>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '14px' }}>
          {topTokens.map(token => (
            <Link key={token.id} to={`/tokens/${token.id}`} style={{ textDecoration: 'none' }}>
              <div className="card" style={{ padding: '18px', cursor: 'pointer' }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = '#2e2e5a'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = '#1e1e3a'; e.currentTarget.style.transform = 'none'; }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{
                      width: '40px', height: '40px', borderRadius: '10px',
                      background: `hsl(${token.id * 60}, 70%, 50%)`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: '18px', fontWeight: 800, fontFamily: 'Syne', color: '#fff',
                    }}>{token.symbol[0]}</div>
                    <div>
                      <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '15px', color: '#f0f0ff' }}>{token.name}</div>
                      <div style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa' }}>{token.symbol}</div>
                    </div>
                  </div>
                  <span className={`badge ${token.change24h >= 0 ? 'badge-green' : 'badge-red'}`}>
                    {token.change24h >= 0 ? '+' : ''}{token.change24h}%
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontFamily: 'Space Mono', fontSize: '13px', color: '#f0f0ff' }}>${token.price.toFixed(8)}</div>
                  <div style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa' }}>Vol: ${(token.volume/1000).toFixed(1)}k</div>
                </div>
                {/* Bonding curve bar */}
                <div style={{ marginTop: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                    <span style={{ fontFamily: 'Space Mono', fontSize: '10px', color: '#8888aa' }}>Bonding Curve</span>
                    <span style={{ fontFamily: 'Space Mono', fontSize: '10px', color: '#00ff88' }}>{token.bondingProgress}%</span>
                  </div>
                  <div style={{ height: '4px', background: '#1e1e3a', borderRadius: '2px' }}>
                    <div style={{ height: '100%', width: `${token.bondingProgress}%`, background: 'linear-gradient(90deg, #00ff88, #7c3aed)', borderRadius: '2px' }} />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent NFTs */}
      <div style={{ padding: '0 24px', maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
          <div>
            <div className="tag" style={{ marginBottom: '6px' }}>🎨 Latest</div>
            <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '24px', color: '#f0f0ff' }}>Recent NFTs</h2>
          </div>
          <Link to="/nft" style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#00ff88', fontFamily: 'Space Mono', fontSize: '12px', textDecoration: 'none' }}>
            View All <ArrowRight size={14} />
          </Link>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px' }}>
          {topNFTs.map(nft => (
            <Link key={nft.id} to={`/nft/${nft.id}`} style={{ textDecoration: 'none' }}>
              <div className="card" style={{ overflow: 'hidden', cursor: 'pointer' }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = '#7c3aed'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = '#1e1e3a'; e.currentTarget.style.transform = 'none'; }}>
                <div style={{ position: 'relative', paddingTop: '100%' }}>
                  <img src={nft.image} alt={nft.name} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
                <div style={{ padding: '14px' }}>
                  <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '14px', color: '#f0f0ff', marginBottom: '4px' }}>{nft.name}</div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontFamily: 'Space Mono', fontSize: '13px', color: '#00ff88', fontWeight: 700 }}>{nft.price} SOL</span>
                    <span className="badge badge-purple" style={{ fontSize: '10px' }}>Buy → Mint</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
