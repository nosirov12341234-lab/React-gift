import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Copy, ExternalLink, Users, Activity, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { MOCK_PIPS_TOKENS, MOCK_GMGN_TOKENS } from '../lib/mockData';
import { useWallet } from '../context/WalletContext';

export default function TokenDetailPage() {
  const { id } = useParams();
  const { wallet, setShowModal } = useWallet();
  const [mode, setMode] = useState('buy');
  const [amount, setAmount] = useState('');
  const [trading, setTrading] = useState(false);
  const [txDone, setTxDone] = useState(null);

  const allTokens = [...MOCK_PIPS_TOKENS, ...MOCK_GMGN_TOKENS];
  const token = allTokens.find(t => t.id === parseInt(id));

  if (!token) return (
    <div style={{ padding: '120px 24px', textAlign: 'center', color: '#444466', fontFamily: 'Space Mono' }}>
      Token not found. <Link to="/tokens" style={{ color: '#00ff88' }}>← Back</Link>
    </div>
  );

  const handleTrade = async () => {
    if (!wallet) { setShowModal(true); return; }
    if (!amount || isNaN(amount)) return;
    setTrading(true);
    await new Promise(r => setTimeout(r, 2000));
    setTrading(false);
    setTxDone({ mode, amount, symbol: token.symbol });
    setAmount('');
  };

  const solAmount = mode === 'buy' ? parseFloat(amount) || 0 : (parseFloat(amount) || 0) * token.price / 150;
  const fee = solAmount * 0.01;
  const total = mode === 'buy' ? solAmount + fee : solAmount - fee;

  const fmtNum = (n) => {
    if (!n) return '$0';
    if (n >= 1e9) return '$' + (n/1e9).toFixed(2) + 'B';
    if (n >= 1e6) return '$' + (n/1e6).toFixed(2) + 'M';
    if (n >= 1e3) return '$' + (n/1e3).toFixed(1) + 'K';
    return '$' + n.toFixed(2);
  };

  const isUp = token.change24h >= 0;

  return (
    <div style={{ padding: '80px 24px 60px', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Back */}
      <Link to="/tokens" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', color: '#8888aa', fontFamily: 'Space Mono', fontSize: '12px', textDecoration: 'none', marginBottom: '24px' }}>
        <ArrowLeft size={14} /> Back to Tokens
      </Link>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '24px', alignItems: 'start' }}>
        {/* Left - Chart */}
        <div>
          {/* Token Header */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px', flexWrap: 'wrap' }}>
            <div style={{
              width: '56px', height: '56px', borderRadius: '14px',
              background: `hsl(${token.id * 47}, 65%, 45%)`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'Syne', fontWeight: 800, fontSize: '24px', color: '#fff', flexShrink: 0,
            }}>{token.symbol[0]}</div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '28px', color: '#f0f0ff', letterSpacing: '-0.02em' }}>{token.name}</h1>
                <span className="badge badge-cyan">{token.symbol}</span>
                {!token.external && <span className="badge badge-green">PIPS Launch</span>}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '4px' }}>
                <span style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#444466' }}>{token.ca}</span>
                <button onClick={() => navigator.clipboard.writeText(token.ca)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#444466', padding: '0' }}>
                  <Copy size={12} />
                </button>
              </div>
            </div>
            <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
              <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '28px', color: '#f0f0ff' }}>
                ${token.price < 0.001 ? token.price.toFixed(8) : token.price.toFixed(4)}
              </div>
              <div style={{ fontFamily: 'Space Mono', fontSize: '14px', color: isUp ? '#00ff88' : '#ff2d78', fontWeight: 700 }}>
                {isUp ? '+' : ''}{token.change24h.toFixed(1)}% (24h)
              </div>
            </div>
          </div>

          {/* Chart */}
          <div className="card" style={{ padding: '20px', marginBottom: '20px' }}>
            <div style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#444466', marginBottom: '16px', letterSpacing: '0.08em' }}>PRICE CHART (30D)</div>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={token.chartData}>
                <XAxis dataKey="time" hide />
                <YAxis hide domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ background: '#0f0f1a', border: '1px solid #2e2e5a', borderRadius: '8px', fontFamily: 'Space Mono', fontSize: '11px' }}
                  labelStyle={{ color: '#8888aa' }}
                  itemStyle={{ color: '#00ff88' }}
                  formatter={(v) => ['$' + v.toFixed(10), 'Price']}
                />
                <Line type="monotone" dataKey="price" stroke={isUp ? '#00ff88' : '#ff2d78'} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '12px', marginBottom: '20px' }}>
            {[
              { label: 'Market Cap', value: fmtNum(token.marketCap), icon: <TrendingUp size={14} color="#00ff88" /> },
              { label: '24h Volume', value: fmtNum(token.volume), icon: <Activity size={14} color="#7c3aed" /> },
              { label: 'Liquidity', value: token.external ? fmtNum(token.liquidity) : `${token.liquidity} SOL`, icon: <Activity size={14} color="#00d4ff" /> },
              ...(token.holders ? [{ label: 'Holders', value: token.holders.toLocaleString(), icon: <Users size={14} color="#ff2d78" /> }] : []),
            ].map((s, i) => (
              <div key={i} className="card" style={{ padding: '14px 16px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '6px' }}>{s.icon}<span className="tag">{s.label}</span></div>
                <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '18px', color: '#f0f0ff' }}>{s.value}</div>
              </div>
            ))}
          </div>

          {/* Bonding curve if PIPS token */}
          {!token.external && (
            <div className="card" style={{ padding: '18px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                <span className="tag">Bonding Curve Progress</span>
                <span style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#00ff88', fontWeight: 700 }}>{token.bondingProgress}%</span>
              </div>
              <div style={{ height: '8px', background: '#1e1e3a', borderRadius: '4px', marginBottom: '8px' }}>
                <div style={{ height: '100%', width: `${token.bondingProgress}%`, background: 'linear-gradient(90deg, #00ff88, #7c3aed)', borderRadius: '4px', transition: 'width 1s ease' }} />
              </div>
              <div style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa' }}>
                At 100% → Automatically listed on Raydium DEX
              </div>
            </div>
          )}
        </div>

        {/* Right - Trade Panel */}
        <div className="card" style={{ padding: '24px', position: 'sticky', top: '80px' }}>
          <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '18px', color: '#f0f0ff', marginBottom: '20px' }}>Trade {token.symbol}</div>

          {/* Buy/Sell Toggle */}
          <div style={{ display: 'flex', marginBottom: '20px', background: '#0f0f1a', borderRadius: '8px', padding: '4px', border: '1px solid #1e1e3a' }}>
            {['buy', 'sell'].map(m => (
              <button key={m} onClick={() => setMode(m)} style={{
                flex: 1, padding: '10px', borderRadius: '6px', border: 'none', cursor: 'pointer',
                fontFamily: 'Space Mono', fontSize: '13px', fontWeight: 700,
                background: mode === m ? (m === 'buy' ? '#00ff88' : '#ff2d78') : 'transparent',
                color: mode === m ? '#000' : '#8888aa',
                transition: 'all 0.2s', textTransform: 'uppercase', letterSpacing: '0.05em',
              }}>{m}</button>
            ))}
          </div>

          {/* Amount Input */}
          <div style={{ marginBottom: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span className="tag">{mode === 'buy' ? 'You pay (SOL)' : `You sell (${token.symbol})`}</span>
              {wallet && <span style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa' }}>Bal: {wallet.balance} SOL</span>}
            </div>
            <div style={{ position: 'relative' }}>
              <input className="input" type="number" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} style={{ paddingRight: '70px' }} />
              <div style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>
                {mode === 'buy' ? 'SOL' : token.symbol}
              </div>
            </div>
          </div>

          {/* Quick amounts */}
          {mode === 'buy' && (
            <div style={{ display: 'flex', gap: '6px', marginBottom: '16px', flexWrap: 'wrap' }}>
              {['0.1', '0.5', '1', '5'].map(v => (
                <button key={v} onClick={() => setAmount(v)} style={{
                  flex: 1, minWidth: '50px', padding: '6px', borderRadius: '6px', border: '1px solid #2e2e5a',
                  background: amount === v ? 'rgba(0,255,136,0.1)' : '#0f0f1a',
                  color: amount === v ? '#00ff88' : '#8888aa',
                  fontFamily: 'Space Mono', fontSize: '11px', cursor: 'pointer', fontWeight: 700,
                }}>{v}</button>
              ))}
            </div>
          )}

          {/* Fee breakdown */}
          {amount && (
            <div style={{ padding: '12px', background: '#0f0f1a', borderRadius: '8px', marginBottom: '16px', border: '1px solid #1e1e3a' }}>
              {[
                { label: mode === 'buy' ? 'You get' : 'You receive', value: mode === 'buy' ? `~${(parseFloat(amount)/token.price).toLocaleString()} ${token.symbol}` : `~${(parseFloat(amount)*token.price/150).toFixed(4)} SOL` },
                { label: 'Platform fee (1%)', value: `${fee.toFixed(4)} SOL` },
                { label: 'Total', value: `${total.toFixed(4)} SOL`, highlight: true },
              ].map((row, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: i < 2 ? '6px' : 0 }}>
                  <span style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa' }}>{row.label}</span>
                  <span style={{ fontFamily: 'Space Mono', fontSize: '11px', color: row.highlight ? '#00ff88' : '#f0f0ff', fontWeight: row.highlight ? 700 : 400 }}>{row.value}</span>
                </div>
              ))}
            </div>
          )}

          {/* TX done */}
          {txDone && (
            <div style={{ padding: '12px', background: 'rgba(0,255,136,0.06)', border: '1px solid rgba(0,255,136,0.15)', borderRadius: '8px', marginBottom: '12px', fontFamily: 'Space Mono', fontSize: '12px', color: '#00ff88' }}>
              ✅ {txDone.mode === 'buy' ? 'Bought' : 'Sold'} {txDone.amount} {txDone.mode === 'buy' ? 'SOL of' : ''} {txDone.symbol} successfully!
            </div>
          )}

          <button onClick={handleTrade} disabled={trading || !amount} style={{
            width: '100%', padding: '14px', borderRadius: '8px', border: 'none', cursor: trading || !amount ? 'not-allowed' : 'pointer',
            background: !amount ? '#1a1a2e' : mode === 'buy' ? '#00ff88' : '#ff2d78',
            color: !amount ? '#444466' : '#000',
            fontFamily: 'Space Mono', fontSize: '14px', fontWeight: 700, letterSpacing: '0.05em',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            transition: 'all 0.2s', opacity: trading ? 0.7 : 1,
          }}>
            {trading ? (
              <><span style={{ width: '16px', height: '16px', border: '2px solid rgba(0,0,0,0.3)', borderTopColor: '#000', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} /> Processing...</>
            ) : !wallet ? '👻 Connect Wallet' : mode === 'buy' ? `Buy ${token.symbol}` : `Sell ${token.symbol}`}
          </button>

          <div style={{ marginTop: '12px', textAlign: 'center', fontFamily: 'Space Mono', fontSize: '10px', color: '#444466' }}>
            Powered by Jupiter Aggregator · 1% platform fee
          </div>
        </div>
      </div>
    </div>
  );
}
