import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Heart, Eye, Copy, Share2 } from 'lucide-react';
import { MOCK_NFTS } from '../lib/mockData';
import { useWallet } from '../context/WalletContext';

export default function NFTDetailPage() {
  const { id } = useParams();
  const { wallet, setShowModal } = useWallet();
  const [buying, setBuying] = useState(false);
  const [bought, setBought] = useState(false);
  const [liked, setLiked] = useState(false);

  const nft = MOCK_NFTS.find(n => n.id === parseInt(id));

  if (!nft) return (
    <div style={{ padding: '120px 24px', textAlign: 'center', color: '#444466', fontFamily: 'Space Mono' }}>
      NFT not found. <Link to="/nft" style={{ color: '#00ff88' }}>← Back</Link>
    </div>
  );

  const handleBuy = async () => {
    if (!wallet) { setShowModal(true); return; }
    setBuying(true);
    await new Promise(r => setTimeout(r, 2500));
    setBuying(false);
    setBought(true);
  };

  const fee = nft.price * 0.025;
  const total = nft.price + fee;

  return (
    <div style={{ padding: '80px 24px 60px', maxWidth: '1100px', margin: '0 auto' }}>
      <Link to="/nft" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', color: '#8888aa', fontFamily: 'Space Mono', fontSize: '12px', textDecoration: 'none', marginBottom: '24px' }}>
        <ArrowLeft size={14} /> Back to NFT Market
      </Link>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px', alignItems: 'start' }}>
        {/* Image */}
        <div>
          <div style={{ borderRadius: '16px', overflow: 'hidden', border: '1px solid #2e2e5a' }}>
            <img src={nft.image} alt={nft.name} style={{ width: '100%', display: 'block' }} />
          </div>
          <div style={{ display: 'flex', gap: '10px', marginTop: '14px' }}>
            <button onClick={() => setLiked(!liked)} style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
              padding: '10px', background: liked ? 'rgba(255,45,120,0.1)' : '#12121f',
              border: `1px solid ${liked ? '#ff2d78' : '#1e1e3a'}`,
              borderRadius: '8px', cursor: 'pointer', color: liked ? '#ff2d78' : '#8888aa',
              fontFamily: 'Space Mono', fontSize: '12px', transition: 'all 0.2s',
            }}>
              <Heart size={14} fill={liked ? '#ff2d78' : 'none'} /> {nft.likes + (liked ? 1 : 0)} Likes
            </button>
            <button onClick={() => navigator.clipboard.writeText(window.location.href)} style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
              padding: '10px', background: '#12121f', border: '1px solid #1e1e3a',
              borderRadius: '8px', cursor: 'pointer', color: '#8888aa',
              fontFamily: 'Space Mono', fontSize: '12px', transition: 'all 0.2s',
            }}>
              <Share2 size={14} /> Share
            </button>
          </div>
        </div>

        {/* Details */}
        <div>
          <div style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#7c3aed', letterSpacing: '0.05em', marginBottom: '8px' }}>
            {nft.collection}
          </div>
          <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '32px', color: '#f0f0ff', letterSpacing: '-0.02em', marginBottom: '16px' }}>
            {nft.name}
          </h1>

          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>
              <Eye size={14} /> {nft.views} views
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>
              <Heart size={14} /> {nft.likes} likes
            </div>
            <span className={`badge ${nft.status === 'minted' ? 'badge-cyan' : 'badge-purple'}`}>
              {nft.status === 'minted' ? 'On-chain' : 'Lazy Mint'}
            </span>
          </div>

          {/* Creator */}
          <div className="card" style={{ padding: '14px 16px', marginBottom: '24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div className="tag" style={{ marginBottom: '4px' }}>Creator</div>
              <div style={{ fontFamily: 'Space Mono', fontSize: '13px', color: '#f0f0ff' }}>{nft.creator}</div>
            </div>
            <button onClick={() => navigator.clipboard.writeText(nft.creator)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#444466' }}>
              <Copy size={14} />
            </button>
          </div>

          {/* Price */}
          <div className="card" style={{ padding: '20px', marginBottom: '20px' }}>
            <div className="tag" style={{ marginBottom: '8px' }}>Current Price</div>
            <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '36px', color: '#00ff88', marginBottom: '4px' }}>
              {nft.price} SOL
            </div>
            <div style={{ fontFamily: 'Space Mono', fontSize: '13px', color: '#8888aa' }}>
              ≈ ${(nft.price * 150).toFixed(2)} USD
            </div>
          </div>

          {/* Fee breakdown */}
          <div style={{ padding: '14px', background: '#0f0f1a', borderRadius: '8px', marginBottom: '20px', border: '1px solid #1e1e3a' }}>
            {[
              { label: 'NFT Price', value: `${nft.price} SOL` },
              { label: 'Platform Fee (2.5%)', value: `${fee.toFixed(4)} SOL` },
              { label: 'Total', value: `${total.toFixed(4)} SOL`, highlight: true },
            ].map((row, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: i < 2 ? '8px' : 0 }}>
                <span style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>{row.label}</span>
                <span style={{ fontFamily: 'Space Mono', fontSize: '12px', color: row.highlight ? '#00ff88' : '#f0f0ff', fontWeight: row.highlight ? 700 : 400 }}>{row.value}</span>
              </div>
            ))}
          </div>

          {bought ? (
            <div style={{ padding: '20px', textAlign: 'center', background: 'rgba(0,255,136,0.06)', border: '1px solid rgba(0,255,136,0.2)', borderRadius: '10px' }}>
              <div style={{ fontSize: '32px', marginBottom: '8px' }}>✅</div>
              <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '18px', color: '#00ff88', marginBottom: '6px' }}>NFT Minted to Your Wallet!</div>
              <div style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>Check your Phantom wallet for {nft.name}</div>
            </div>
          ) : (
            <button onClick={handleBuy} disabled={buying} className="btn btn-primary"
              style={{ width: '100%', justifyContent: 'center', padding: '16px', fontSize: '15px', opacity: buying ? 0.7 : 1, cursor: buying ? 'wait' : 'pointer' }}>
              {buying ? (
                <><span style={{ width: '18px', height: '18px', border: '2px solid rgba(0,0,0,0.3)', borderTopColor: '#000', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} /> Minting to your wallet...</>
              ) : !wallet ? '👻 Connect Wallet' : `Buy & Mint for ${total.toFixed(3)} SOL`}
            </button>
          )}

          <div style={{ marginTop: '12px', textAlign: 'center', fontFamily: 'Space Mono', fontSize: '11px', color: '#444466' }}>
            NFT mints directly to your wallet on purchase
          </div>
        </div>
      </div>
    </div>
  );
}
