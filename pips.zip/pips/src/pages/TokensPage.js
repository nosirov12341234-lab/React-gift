import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Plus, TrendingUp, TrendingDown, ExternalLink } from 'lucide-react';
import { MOCK_PIPS_TOKENS, MOCK_GMGN_TOKENS } from '../lib/mockData';

export default function TokensPage() {
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState('pips');

  const pipsFiltered = MOCK_PIPS_TOKENS.filter(t =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.symbol.toLowerCase().includes(search.toLowerCase()) ||
    t.ca.toLowerCase().includes(search.toLowerCase())
  );

  const gmgnFiltered = MOCK_GMGN_TOKENS.filter(t =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.symbol.toLowerCase().includes(search.toLowerCase()) ||
    t.ca.toLowerCase().includes(search.toLowerCase())
  );

  const allFiltered = [...pipsFiltered, ...gmgnFiltered];
  const displayTokens = tab === 'pips' ? pipsFiltered : tab === 'gmgn' ? gmgnFiltered : allFiltered;

  return (
    <div style={{ padding: '80px 24px 60px', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: '32px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div className="tag" style={{ marginBottom: '8px' }}>🪙 Trading</div>
          <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '36px', color: '#f0f0ff', letterSpacing: '-0.02em' }}>Token Market</h1>
          <p style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', marginTop: '6px' }}>
            PIPS launches + all Solana tokens via DexScreener
          </p>
        </div>
        <Link to="/create?tab=token" className="btn btn-purple">
          <Plus size={15} /> Launch Token
        </Link>
      </div>

      {/* Search */}
      <div style={{ position: 'relative', marginBottom: '20px' }}>
        <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#444466' }} />
        <input className="input" placeholder="Search by name, symbol or contract address..." value={search} onChange={e => setSearch(e.target.value)} style={{ paddingLeft: '36px', fontSize: '14px' }} />
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '4px', marginBottom: '24px', background: '#0f0f1a', padding: '4px', borderRadius: '10px', width: 'fit-content', border: '1px solid #1e1e3a' }}>
        {[
          { id: 'pips', label: '⚡ PIPS Launches' },
          { id: 'gmgn', label: '🌐 All Solana (GMGN)' },
          { id: 'all', label: '🔥 All' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: '8px 16px', borderRadius: '7px', border: 'none', cursor: 'pointer',
            fontFamily: 'Space Mono', fontSize: '12px', fontWeight: 700,
            background: tab === t.id ? '#00ff88' : 'transparent',
            color: tab === t.id ? '#000' : '#8888aa',
            transition: 'all 0.2s',
          }}>{t.label}</button>
        ))}
      </div>

      {/* Token Table */}
      <div className="card" style={{ overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #1e1e3a' }}>
                {['Token', 'Price', '24h', 'Volume', 'Liquidity', 'MCap', ''].map((h, i) => (
                  <th key={i} style={{ padding: '14px 16px', textAlign: i > 0 ? 'right' : 'left', fontFamily: 'Space Mono', fontSize: '11px', color: '#444466', letterSpacing: '0.08em', fontWeight: 700, whiteSpace: 'nowrap' }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {displayTokens.map(token => (
                <TokenRow key={token.id} token={token} />
              ))}
            </tbody>
          </table>
        </div>
        {displayTokens.length === 0 && (
          <div style={{ textAlign: 'center', padding: '60px', color: '#444466', fontFamily: 'Space Mono', fontSize: '13px' }}>
            No tokens found matching "{search}"
          </div>
        )}
      </div>
    </div>
  );
}

function TokenRow({ token }) {
  const isUp = token.change24h >= 0;

  const fmtNum = (n) => {
    if (n >= 1e9) return '$' + (n/1e9).toFixed(2) + 'B';
    if (n >= 1e6) return '$' + (n/1e6).toFixed(2) + 'M';
    if (n >= 1e3) return '$' + (n/1e3).toFixed(1) + 'K';
    return '$' + n.toFixed(0);
  };

  return (
    <tr style={{ borderBottom: '1px solid #1e1e3a', transition: 'background 0.15s', cursor: 'pointer' }}
      onMouseEnter={e => e.currentTarget.style.background = '#1a1a2e'}
      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
      <td style={{ padding: '14px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '38px', height: '38px', borderRadius: '10px', flexShrink: 0,
            background: `hsl(${token.id * 47}, 65%, 45%)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'Syne', fontWeight: 800, fontSize: '16px', color: '#fff',
          }}>{token.symbol[0]}</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '14px', color: '#f0f0ff' }}>{token.name}</span>
              {token.external && <ExternalLink size={11} color="#444466" />}
              {!token.external && <span className="badge badge-green" style={{ fontSize: '9px' }}>PIPS</span>}
            </div>
            <div style={{ fontFamily: 'Space Mono', fontSize: '10px', color: '#444466' }}>{token.symbol} · {token.ca}</div>
          </div>
        </div>
      </td>
      <td style={{ padding: '14px 16px', textAlign: 'right', fontFamily: 'Space Mono', fontSize: '13px', color: '#f0f0ff' }}>
        ${token.price < 0.001 ? token.price.toFixed(8) : token.price.toFixed(4)}
      </td>
      <td style={{ padding: '14px 16px', textAlign: 'right' }}>
        <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '4px', fontFamily: 'Space Mono', fontSize: '13px', color: isUp ? '#00ff88' : '#ff2d78', fontWeight: 700 }}>
          {isUp ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
          {isUp ? '+' : ''}{token.change24h.toFixed(1)}%
        </span>
      </td>
      <td style={{ padding: '14px 16px', textAlign: 'right', fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>{fmtNum(token.volume)}</td>
      <td style={{ padding: '14px 16px', textAlign: 'right', fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>
        {token.external ? fmtNum(token.liquidity) : `${token.liquidity} SOL`}
      </td>
      <td style={{ padding: '14px 16px', textAlign: 'right', fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>{fmtNum(token.marketCap)}</td>
      <td style={{ padding: '14px 16px', textAlign: 'right' }}>
        <Link to={`/tokens/${token.id}`} className="btn btn-secondary" style={{ padding: '6px 14px', fontSize: '11px' }}>
          Trade
        </Link>
      </td>
    </tr>
  );
}
