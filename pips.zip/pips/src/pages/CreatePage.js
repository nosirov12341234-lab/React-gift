import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Upload, Image, Coins, Plus, Info } from 'lucide-react';
import { useWallet } from '../context/WalletContext';

export default function CreatePage() {
  const [searchParams] = useSearchParams();
  const [tab, setTab] = useState(searchParams.get('tab') || 'nft');
  const { wallet, setShowModal } = useWallet();

  return (
    <div style={{ padding: '80px 24px 60px', maxWidth: '700px', margin: '0 auto' }}>
      <div className="tag" style={{ marginBottom: '8px' }}>✨ Create</div>
      <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '36px', color: '#f0f0ff', letterSpacing: '-0.02em', marginBottom: '28px' }}>
        Launch on PIPS
      </h1>

      {/* Tab */}
      <div style={{ display: 'flex', gap: '4px', marginBottom: '32px', background: '#0f0f1a', padding: '4px', borderRadius: '10px', width: 'fit-content', border: '1px solid #1e1e3a' }}>
        {[
          { id: 'nft', label: '🎨 NFT', icon: <Image size={14} /> },
          { id: 'token', label: '🪙 Token', icon: <Coins size={14} /> },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: '10px 24px', borderRadius: '7px', border: 'none', cursor: 'pointer',
            fontFamily: 'Space Mono', fontSize: '13px', fontWeight: 700,
            background: tab === t.id ? '#00ff88' : 'transparent',
            color: tab === t.id ? '#000' : '#8888aa',
            transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '6px',
          }}>{t.label}</button>
        ))}
      </div>

      {tab === 'nft' ? <NFTCreateForm wallet={wallet} setShowModal={setShowModal} /> : <TokenCreateForm wallet={wallet} setShowModal={setShowModal} />}
    </div>
  );
}

function NFTCreateForm({ wallet, setShowModal }) {
  const [form, setForm] = useState({ name: '', collection: '', description: '', price: '', image: null });
  const [preview, setPreview] = useState(null);
  const [creating, setCreating] = useState(false);
  const [done, setDone] = useState(false);
  const [drag, setDrag] = useState(false);

  const handleFile = (file) => {
    if (!file) return;
    setForm(f => ({ ...f, image: file }));
    const reader = new FileReader();
    reader.onload = e => setPreview(e.target.result);
    reader.readAsDataURL(file);
  };

  const handleCreate = async () => {
    if (!wallet) { setShowModal(true); return; }
    if (!form.name || !form.price) return;
    setCreating(true);
    await new Promise(r => setTimeout(r, 2500));
    setCreating(false);
    setDone(true);
  };

  if (done) return (
    <div style={{ textAlign: 'center', padding: '60px 0' }}>
      <div style={{ fontSize: '64px', marginBottom: '20px' }}>🎉</div>
      <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '28px', color: '#00ff88', marginBottom: '12px' }}>NFT Listed!</h2>
      <p style={{ fontFamily: 'Space Mono', fontSize: '13px', color: '#8888aa', marginBottom: '24px', lineHeight: 1.7 }}>
        Your NFT is now live on PIPS marketplace.<br />When someone buys it, it will mint directly to their wallet.
      </p>
      <button onClick={() => { setDone(false); setForm({ name: '', collection: '', description: '', price: '', image: null }); setPreview(null); }}
        className="btn btn-primary" style={{ marginRight: '12px' }}>
        <Plus size={14} /> Create Another
      </button>
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Image Upload */}
      <div
        onDragOver={e => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]); }}
        onClick={() => document.getElementById('nft-file').click()}
        style={{
          border: `2px dashed ${drag ? '#00ff88' : '#2e2e5a'}`,
          borderRadius: '12px', cursor: 'pointer', transition: 'all 0.2s',
          background: drag ? 'rgba(0,255,136,0.04)' : '#0f0f1a',
          overflow: 'hidden', aspectRatio: preview ? 'auto' : '2/1',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
        <input id="nft-file" type="file" accept="image/*" style={{ display: 'none' }} onChange={e => handleFile(e.target.files[0])} />
        {preview ? (
          <img src={preview} alt="preview" style={{ width: '100%', maxHeight: '320px', objectFit: 'cover' }} />
        ) : (
          <div style={{ textAlign: 'center', padding: '40px', color: '#444466' }}>
            <Upload size={32} style={{ marginBottom: '12px', display: 'block', margin: '0 auto 12px' }} />
            <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '16px', marginBottom: '6px', color: '#8888aa' }}>Drop image here</div>
            <div style={{ fontFamily: 'Space Mono', fontSize: '12px' }}>PNG, JPG, GIF, SVG · Max 50MB</div>
          </div>
        )}
      </div>

      {/* Fields */}
      {[
        { key: 'name', label: 'NFT Name', placeholder: 'e.g. Cyber Ape #001', required: true },
        { key: 'collection', label: 'Collection', placeholder: 'e.g. Cyber Apes' },
        { key: 'description', label: 'Description', placeholder: 'Tell the story of your NFT...' },
        { key: 'price', label: 'Price (SOL)', placeholder: '0.5', type: 'number', required: true },
      ].map(f => (
        <div key={f.key}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <label style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', letterSpacing: '0.05em' }}>{f.label} {f.required && <span style={{ color: '#ff2d78' }}>*</span>}</label>
          </div>
          {f.key === 'description' ? (
            <textarea className="input" placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
              style={{ resize: 'vertical', minHeight: '80px' }} />
          ) : (
            <input className="input" type={f.type || 'text'} placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} />
          )}
        </div>
      ))}

      {/* Fee Info */}
      <div style={{ padding: '14px', background: 'rgba(0,212,255,0.06)', borderRadius: '8px', border: '1px solid rgba(0,212,255,0.15)', display: 'flex', gap: '10px' }}>
        <Info size={16} color="#00d4ff" style={{ flexShrink: 0, marginTop: '1px' }} />
        <div style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', lineHeight: 1.7 }}>
          <span style={{ color: '#00d4ff' }}>Listing is FREE.</span> When your NFT sells, a platform fee is deducted from the sale. NFT mints directly to the buyer's wallet.
        </div>
      </div>

      <button onClick={handleCreate} disabled={creating || !form.name || !form.price} className="btn btn-primary"
        style={{ width: '100%', justifyContent: 'center', padding: '14px', fontSize: '14px', opacity: creating ? 0.7 : 1, cursor: creating ? 'wait' : 'pointer' }}>
        {creating ? (
          <><span style={{ width: '16px', height: '16px', border: '2px solid rgba(0,0,0,0.3)', borderTopColor: '#000', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} /> Uploading to IPFS & Listing...</>
        ) : !wallet ? '👻 Connect Wallet to List' : '🎨 List NFT on PIPS'}
      </button>
    </div>
  );
}

function TokenCreateForm({ wallet, setShowModal }) {
  const [form, setForm] = useState({ name: '', symbol: '', supply: '1000000000', description: '', liquidity: '0.5', logo: null });
  const [preview, setPreview] = useState(null);
  const [creating, setCreating] = useState(false);
  const [done, setDone] = useState(null);

  const handleLogo = (file) => {
    if (!file) return;
    setForm(f => ({ ...f, logo: file }));
    const reader = new FileReader();
    reader.onload = e => setPreview(e.target.result);
    reader.readAsDataURL(file);
  };

  const handleCreate = async () => {
    if (!wallet) { setShowModal(true); return; }
    if (!form.name || !form.symbol) return;
    setCreating(true);
    await new Promise(r => setTimeout(r, 3000));
    setCreating(false);
    const ca = form.symbol.toUpperCase().slice(0, 4) + Math.random().toString(36).substr(2, 8).toUpperCase();
    setDone({ ...form, ca });
  };

  if (done) return (
    <div style={{ textAlign: 'center', padding: '40px 0' }}>
      <div style={{ fontSize: '64px', marginBottom: '20px' }}>🚀</div>
      <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '28px', color: '#00ff88', marginBottom: '12px' }}>Token Launched!</h2>
      <div className="card" style={{ padding: '20px', marginBottom: '24px', textAlign: 'left' }}>
        {[
          { label: 'Name', value: done.name },
          { label: 'Symbol', value: done.symbol.toUpperCase() },
          { label: 'Supply', value: parseInt(done.supply).toLocaleString() },
          { label: 'Contract Address', value: done.ca },
          { label: 'Initial Liquidity', value: `${done.liquidity} SOL` },
        ].map((row, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: i < 4 ? '1px solid #1e1e3a' : 'none' }}>
            <span style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>{row.label}</span>
            <span style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#f0f0ff', fontWeight: 700 }}>{row.value}</span>
          </div>
        ))}
      </div>
      <p style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', marginBottom: '24px', lineHeight: 1.7 }}>
        Bonding curve is now active. Share your token with the community!
      </p>
      <button onClick={() => { setDone(null); setForm({ name: '', symbol: '', supply: '1000000000', description: '', liquidity: '0.5', logo: null }); setPreview(null); }}
        className="btn btn-purple" style={{ marginRight: '12px' }}>
        <Plus size={14} /> Launch Another
      </button>
    </div>
  );

  const totalCost = (parseFloat(form.liquidity) || 0) + 0.02;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
        <div onClick={() => document.getElementById('logo-file').click()} style={{
          width: '80px', height: '80px', borderRadius: '16px', flexShrink: 0,
          border: '2px dashed #2e2e5a', cursor: 'pointer', overflow: 'hidden',
          background: '#0f0f1a', display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'border-color 0.2s',
        }}
        onMouseEnter={e => e.currentTarget.style.borderColor = '#00ff88'}
        onMouseLeave={e => e.currentTarget.style.borderColor = '#2e2e5a'}>
          <input id="logo-file" type="file" accept="image/*" style={{ display: 'none' }} onChange={e => handleLogo(e.target.files[0])} />
          {preview ? <img src={preview} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Upload size={20} color="#444466" />}
        </div>
        <div>
          <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '15px', color: '#f0f0ff', marginBottom: '4px' }}>Token Logo</div>
          <div style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa' }}>PNG, JPG · Recommended 512×512</div>
        </div>
      </div>

      {/* Fields */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
        <div>
          <label style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', display: 'block', marginBottom: '8px' }}>Token Name <span style={{ color: '#ff2d78' }}>*</span></label>
          <input className="input" placeholder="e.g. MoonDog" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
        </div>
        <div>
          <label style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', display: 'block', marginBottom: '8px' }}>Symbol <span style={{ color: '#ff2d78' }}>*</span></label>
          <input className="input" placeholder="e.g. MDOG" value={form.symbol} onChange={e => setForm(p => ({ ...p, symbol: e.target.value.toUpperCase().slice(0, 10) }))} />
        </div>
      </div>

      <div>
        <label style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', display: 'block', marginBottom: '8px' }}>Total Supply</label>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '10px' }}>
          {[
            { label: '1M', value: '1000000' },
            { label: '100M', value: '100000000' },
            { label: '1B ⭐', value: '1000000000' },
            { label: '1T', value: '1000000000000' },
          ].map(opt => (
            <button key={opt.value} onClick={() => setForm(p => ({ ...p, supply: opt.value }))} style={{
              padding: '6px 14px', borderRadius: '6px', border: '1px solid',
              borderColor: form.supply === opt.value ? '#00ff88' : '#2e2e5a',
              background: form.supply === opt.value ? 'rgba(0,255,136,0.1)' : '#0f0f1a',
              color: form.supply === opt.value ? '#00ff88' : '#8888aa',
              fontFamily: 'Space Mono', fontSize: '12px', cursor: 'pointer', fontWeight: 700,
            }}>{opt.label}</button>
          ))}
        </div>
        <input className="input" type="number" placeholder="Custom supply" value={form.supply} onChange={e => setForm(p => ({ ...p, supply: e.target.value }))} />
      </div>

      <div>
        <label style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', display: 'block', marginBottom: '8px' }}>Description</label>
        <textarea className="input" placeholder="What's your token about? Meme? Utility? Both?" value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
          style={{ resize: 'vertical', minHeight: '80px' }} />
      </div>

      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
          <label style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>Initial Liquidity (SOL) <span style={{ color: '#ff2d78' }}>*</span></label>
          <span style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa' }}>Min: 0.5 SOL</span>
        </div>
        <input className="input" type="number" min="0.5" step="0.1" placeholder="0.5" value={form.liquidity} onChange={e => setForm(p => ({ ...p, liquidity: e.target.value }))} />
        <div style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa', marginTop: '6px' }}>
          This SOL starts your bonding curve. More = lower initial price impact.
        </div>
      </div>

      {/* Cost Breakdown */}
      <div style={{ padding: '16px', background: '#0f0f1a', borderRadius: '8px', border: '1px solid #1e1e3a' }}>
        <div className="tag" style={{ marginBottom: '12px' }}>Cost Breakdown</div>
        {[
          { label: 'Initial Liquidity', value: `${form.liquidity || '0'} SOL` },
          { label: 'PIPS Platform Fee', value: '0.02 SOL' },
          { label: 'Solana Network (~gas)', value: '~0.002 SOL' },
        ].map((row, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa' }}>{row.label}</span>
            <span style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#f0f0ff' }}>{row.value}</span>
          </div>
        ))}
        <div style={{ borderTop: '1px solid #1e1e3a', paddingTop: '8px', display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Space Mono', fontSize: '13px', color: '#f0f0ff', fontWeight: 700 }}>Total</span>
          <span style={{ fontFamily: 'Space Mono', fontSize: '13px', color: '#00ff88', fontWeight: 700 }}>~{totalCost.toFixed(3)} SOL</span>
        </div>
      </div>

      <button onClick={handleCreate} disabled={creating || !form.name || !form.symbol} className="btn btn-purple"
        style={{ width: '100%', justifyContent: 'center', padding: '14px', fontSize: '14px', opacity: creating ? 0.7 : 1, cursor: creating ? 'wait' : 'pointer' }}>
        {creating ? (
          <><span style={{ width: '16px', height: '16px', border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} /> Deploying to Solana...</>
        ) : !wallet ? '👻 Connect Wallet' : '🚀 Launch Token'}
      </button>
    </div>
  );
}
