import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Plus, Heart, Eye } from 'lucide-react';
import { MOCK_NFTS } from '../lib/mockData';
import { useWallet } from '../context/WalletContext';

export default function NFTPage() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [sort, setSort] = useState('recent');
  const { wallet, setShowModal } = useWallet();

  const filtered = MOCK_NFTS.filter(n => {
    const matchSearch = n.name.toLowerCase().includes(search.toLowerCase()) ||
      n.collection.toLowerCase().includes(search.toLowerCase());
    return matchSearch;
  }).sort((a, b) => {
    if (sort === 'price-low') return a.price - b.price;
    if (sort === 'price-high') return b.price - a.price;
    return b.id - a.id;
  });

  return (
    <div style={{ padding: '80px 24px 60px', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: '32px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div className="tag" style={{ marginBottom: '8px' }}>🎨 Marketplace</div>
          <h1 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '36px', color: '#f0f0ff', letterSpacing: '-0.02em' }}>NFT Market</h1>
          <p style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#8888aa', marginTop: '6px' }}>
            Buy → NFT mints directly to your wallet
          </p>
        </div>
        <Link to="/create?tab=nft" className="btn btn-primary">
          <Plus size={15} /> Create NFT
        </Link>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '24px', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: '200px' }}>
          <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#444466' }} />
          <input className="input" placeholder="Search NFTs, collections..." value={search} onChange={e => setSearch(e.target.value)} style={{ paddingLeft: '36px' }} />
        </div>
        <select className="input" value={sort} onChange={e => setSort(e.target.value)} style={{ width: 'auto', minWidth: '140px' }}>
          <option value="recent">Recent</option>
          <option value="price-low">Price: Low</option>
          <option value="price-high">Price: High</option>
        </select>
      </div>

      {/* Info banner */}
      <div style={{ padding: '12px 16px', background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.2)', borderRadius: '8px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <span style={{ fontSize: '16px' }}>⚡</span>
        <span style={{ fontFamily: 'Space Mono', fontSize: '12px', color: '#a78bfa' }}>
          All NFTs mint directly to your wallet on purchase. Sellers list for free — buyers pay mint + platform fee.
        </span>
      </div>

      {/* Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '16px' }}>
        {filtered.map(nft => (
          <NFTCard key={nft.id} nft={nft} wallet={wallet} setShowModal={setShowModal} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: '80px 0', color: '#444466', fontFamily: 'Space Mono', fontSize: '14px' }}>
          No NFTs found. <Link to="/create?tab=nft" style={{ color: '#00ff88' }}>Create one?</Link>
        </div>
      )}
    </div>
  );
}

function NFTCard({ nft, wallet, setShowModal }) {
  const [buying, setBuying] = useState(false);
  const [bought, setBought] = useState(false);
  const [liked, setLiked] = useState(false);

  const handleBuy = async (e) => {
    e.preventDefault();
    if (!wallet) { setShowModal(true); return; }
    setBuying(true);
    await new Promise(r => setTimeout(r, 2000));
    setBuying(false);
    setBought(true);
  };

  return (
    <div className="card" style={{ overflow: 'hidden', transition: 'all 0.2s' }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = '#2e2e5a'; e.currentTarget.style.transform = 'translateY(-3px)'; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = '#1e1e3a'; e.currentTarget.style.transform = 'none'; }}>
      <div style={{ position: 'relative' }}>
        <img src={nft.image} alt={nft.name} style={{ width: '100%', aspectRatio: '1', objectFit: 'cover', display: 'block' }} />
        <button onClick={() => setLiked(!liked)} style={{
          position: 'absolute', top: '10px', right: '10px',
          background: 'rgba(0,0,0,0.6)', border: 'none', borderRadius: '20px',
          padding: '6px 10px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px',
          color: liked ? '#ff2d78' : '#f0f0ff', fontSize: '12px', fontFamily: 'Space Mono',
        }}>
          <Heart size={13} fill={liked ? '#ff2d78' : 'none'} /> {nft.likes + (liked ? 1 : 0)}
        </button>
        <div style={{
          position: 'absolute', bottom: '10px', left: '10px',
          background: 'rgba(0,0,0,0.6)', borderRadius: '6px', padding: '4px 8px',
          display: 'flex', alignItems: 'center', gap: '4px',
          color: '#8888aa', fontSize: '11px', fontFamily: 'Space Mono',
        }}>
          <Eye size={11} /> {nft.views}
        </div>
      </div>
      <div style={{ padding: '14px' }}>
        <div style={{ marginBottom: '4px' }}>
          <span style={{ fontFamily: 'Space Mono', fontSize: '10px', color: '#7c3aed', letterSpacing: '0.05em' }}>{nft.collection}</span>
        </div>
        <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '15px', color: '#f0f0ff', marginBottom: '12px' }}>{nft.name}</div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
          <div>
            <div style={{ fontFamily: 'Space Mono', fontSize: '11px', color: '#8888aa', marginBottom: '2px' }}>Price</div>
            <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '18px', color: '#00ff88' }}>{nft.price} SOL</div>
          </div>
          <span className="badge badge-purple" style={{ fontSize: '10px' }}>Lazy Mint</span>
        </div>
        {bought ? (
          <div style={{ textAlign: 'center', padding: '10px', background: 'rgba(0,255,136,0.08)', borderRadius: '8px', border: '1px solid rgba(0,255,136,0.2)', fontFamily: 'Space Mono', fontSize: '12px', color: '#00ff88' }}>
            ✅ Minted to your wallet!
          </div>
        ) : (
          <button onClick={handleBuy} disabled={buying} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', opacity: buying ? 0.7 : 1 }}>
            {buying ? (
              <>
                <span style={{ width: '14px', height: '14px', border: '2px solid rgba(0,0,0,0.3)', borderTopColor: '#000', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} />
                Minting...
              </>
            ) : 'Buy & Mint'}
          </button>
        )}
      </div>
    </div>
  );
}
