import { useState, useEffect } from 'react'
import { G } from './styles.js'
import { getSettings, getTop10 } from './api.js'
import StarsBg from './components/StarsBg.jsx'
import Header from './components/Header.jsx'
import BottomNav from './components/BottomNav.jsx'
import { Toast, useToast } from './components/Toast.jsx'
import Home from './pages/Home.jsx'
import Stars from './pages/Stars.jsx'
import Premium from './pages/Premium.jsx'
import TopUp from './pages/TopUp.jsx'
import History from './pages/History.jsx'
import Referral from './pages/Referral.jsx'
import Profile from './pages/Profile.jsx'

// Global CSS
const style = document.createElement('style')
style.textContent = G
document.head.appendChild(style)

const tgApp = window.Telegram?.WebApp
const TG_USER = tgApp?.initDataUnsafe?.user || {}
const UID = TG_USER.id || 0

if (tgApp) {
  tgApp.ready()
  tgApp.expand()
}

export default function App() {
  const [page, setPage] = useState('home')
  const [settings, setSettings] = useState({
    bal: 0, prices: { star: 210, pm3: 195000, pm6: 370000, pm12: 680000 },
    minStars: 50, refBonus: 5000, name: '', username: '',
    orders_count: 0, referrals: 0, ref_earned: 0,
    supportLink: '', channelLink: ''
  })
  const [top, setTop] = useState({ daily: [], weekly: [], monthly: [], all: [] })
  const [starsOpen,  setStarsOpen]  = useState(false)
  const [premOpen,   setPremOpen]   = useState(false)
  const [topupOpen,  setTopupOpen]  = useState(false)
  const { toast, show: showToast } = useToast()

  useEffect(() => { loadAll() }, [])

  async function loadAll() {
    try {
      if (!UID) return
      const [s, td, tw, tm, ta] = await Promise.all([
        getSettings(UID),
        getTop10('daily'),
        getTop10('weekly'),
        getTop10('monthly'),
        getTop10('all'),
      ])
      setSettings({
        bal          : s.balance || 0,
        prices       : s.prices || {},
        minStars     : s.min_stars || 50,
        refBonus     : s.referral_bonus || 5000,
        name         : s.name || TG_USER.first_name || '',
        username     : s.username || TG_USER.username || '',
        orders_count : s.orders_count || 0,
        referrals    : s.referrals || 0,
        ref_earned   : s.ref_earned || 0,
        supportLink  : s.support_link || '',
        channelLink  : s.channel_link || '',
      })
      setTop({
        daily  : td.top || [],
        weekly : tw.top || [],
        monthly: tm.top || [],
        all    : ta.top || [],
      })
    } catch(e) {
      console.error('loadAll xato:', e)
    }
  }

  async function refreshBalance() {
    try {
      const s = await getSettings(UID)
      setSettings(prev => ({ ...prev, bal: s.balance || 0 }))
    } catch {}
  }

  const commonProps = {
    settings, showToast,
    uid: String(UID),
    tgUser: TG_USER,
    onBalanceUpdate: refreshBalance,
  }

  return (
    <div>
      <StarsBg />
      <Header bal={settings.bal} name={settings.name || TG_USER.first_name} />

      {page === 'home' && (
        <Home
          {...commonProps}
          top={top}
          onOpenStars={() => setStarsOpen(true)}
          onOpenPremium={() => setPremOpen(true)}
          onOpenTopup={() => setTopupOpen(true)}
        />
      )}
      {page === 'history' && <History {...commonProps} />}
      {page === 'referral' && <Referral {...commonProps} />}
      {page === 'profile' && (
        <Profile
          {...commonProps}
          onTopup={() => setTopupOpen(true)}
          onReferral={() => setPage('referral')}
          onHistory={() => setPage('history')}
        />
      )}

      <Stars
        {...commonProps}
        open={starsOpen}
        onClose={() => { setStarsOpen(false); refreshBalance() }}
      />
      <Premium
        {...commonProps}
        open={premOpen}
        onClose={() => { setPremOpen(false); refreshBalance() }}
      />
      <TopUp
        {...commonProps}
        open={topupOpen}
        onClose={() => { setTopupOpen(false); refreshBalance() }}
      />

      <BottomNav
        page={page}
        setPage={setPage}
        onOpenStars={() => setStarsOpen(true)}
        onOpenPremium={() => setPremOpen(true)}
        onOpenTopup={() => setTopupOpen(true)}
      />

      {toast && <Toast msg={toast.msg} type={toast.type} />}
    </div>
  )
}
