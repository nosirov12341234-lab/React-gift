export const G = `
  :root {
    --bg: #0a0a0f;
    --s1: #12121a;
    --s2: #1a1a26;
    --s3: #222232;
    --bd: rgba(255,255,255,0.07);
    --gold: #f5c842;
    --gold2: #ffaa00;
    --ga: rgba(245,200,66,0.1);
    --pur: #7c5cfc;
    --pur2: #a78bfa;
    --pa: rgba(124,92,252,0.1);
    --tx: #f0f0ff;
    --mt: #6b6b8a;
    --green: #22d3a5;
    --red: #ff4f6d;
  }
  * { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
  body { background:var(--bg); color:var(--tx); font-family:'Syne',sans-serif; overflow-x:hidden; }
  #root { min-height:100vh; padding-bottom:70px; }
  @keyframes slideUp { from { transform:translateY(30px); opacity:0 } to { transform:translateY(0); opacity:1 } }
  @keyframes fadeUp  { from { transform:translateY(12px); opacity:0 } to { transform:translateY(0); opacity:1 } }
  @keyframes pulse   { 0%,100% { opacity:1 } 50% { opacity:0.5 } }
  ::-webkit-scrollbar { width:0; }
`
