import { useState } from 'react'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g,' ')

export default function Home({ settings, top, onOpenStars, onOpenPremium, onOpenTopup }) {
  const [period, setPeriod] = useState('daily')
  const topList = top[period] || []

  return (
    <div style={{position:'relative',zIndex:1,animation:'fadeUp .28s ease'}}>
      {/* Balans kartasi */}
      <div style={{
        margin:'16px 18px 0',
        background:'linear-gradient(135deg,#1e1a3a,#0f1525)',
        border:'1px solid rgba(124,92,252,0.2)',
        borderRadius:20,padding:'20px',position:'relative',overflow:'hidden'
      }}>
        <div style={{position:'absolute',top:-40,right:-40,width:160,height:160,
          background:'radial-gradient(circle,rgba(124,92,252,0.15),transparent 70%)',borderRadius:'50%'}}/>
        <div style={{fontSize:11,color:'var(--mt)',letterSpacing:2,textTransform:'uppercase',marginBottom:4}}>
          Balansingiz
        </div>
        <div style={{fontFamily:'Space Mono,monospace',fontSize:28,fontWeight:700,color:'var(--gold)',position:'relative'}}>
          {fmt(settings.bal)} <span style={{fontSize:14,color:'var(--mt)'}}>so'm</span>
        </div>
        <button onClick={onOpenTopup} style={{
          marginTop:14,background:'linear-gradient(135deg,var(--gold),var(--gold2))',
          border:'none',borderRadius:11,padding:'9px 20px',
          color:'#000',fontFamily:'Syne,sans-serif',fontSize:12,fontWeight:800,cursor:'pointer'
        }}>+ To'ldirish</button>
      </div>

      {/* Xizmatlar */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,margin:'12px 18px 0'}}>
        <div onClick={onOpenStars} style={{
          background:'var(--s1)',border:'1px solid rgba(245,200,66,0.15)',
          borderRadius:16,padding:'16px',cursor:'pointer',
          display:'flex',flexDirection:'column',gap:6
        }}>
          <div style={{fontSize:28}}>🌟</div>
          <div style={{fontWeight:800,fontSize:14}}>Stars</div>
          <div style={{fontSize:10,color:'var(--mt)'}}>
            {fmt(settings.prices?.star||210)} so'm / ta
          </div>
        </div>
        <div onClick={onOpenPremium} style={{
          background:'var(--s1)',border:'1px solid rgba(124,92,252,0.15)',
          borderRadius:16,padding:'16px',cursor:'pointer',
          display:'flex',flexDirection:'column',gap:6
        }}>
          <div style={{fontSize:28}}>👑</div>
          <div style={{fontWeight:800,fontSize:14}}>Premium</div>
          <div style={{fontSize:10,color:'var(--mt)'}}>
            {fmt(settings.prices?.pm3||195000)} so'mdan
          </div>
        </div>
      </div>

      {/* Top 10 */}
      <div style={{margin:'16px 18px 0'}}>
        <div style={{fontSize:14,fontWeight:800,marginBottom:10}}>🏆 Top foydalanuvchilar</div>
        <div style={{display:'flex',gap:6,marginBottom:10}}>
          {['daily','weekly','monthly','all'].map(p => (
            <button key={p} onClick={()=>setPeriod(p)} style={{
              flex:1,padding:'6px 4px',borderRadius:20,
              border:`1px solid ${period===p?'var(--gold)':'var(--bd)'}`,
              background:period===p?'var(--ga)':'transparent',
              color:period===p?'var(--gold)':'var(--mt)',
              fontSize:9,fontWeight:700,cursor:'pointer'
            }}>
              {p==='daily'?'Bugun':p==='weekly'?'Hafta':p==='monthly'?'Oy':'Barchasi'}
            </button>
          ))}
        </div>
        {topList.length === 0 ? (
          <div style={{textAlign:'center',padding:'20px',color:'var(--mt)',fontSize:12}}>
            Hali buyurtmalar yo'q
          </div>
        ) : topList.map((u,i) => (
          <div key={i} style={{
            display:'flex',alignItems:'center',gap:10,
            background:'var(--s1)',border:'1px solid var(--bd)',
            borderRadius:12,padding:'10px 12px',marginBottom:6
          }}>
            <div style={{
              width:28,height:28,borderRadius:'50%',
              background:i===0?'linear-gradient(135deg,#FFD700,#FFA500)':
                         i===1?'linear-gradient(135deg,#C0C0C0,#808080)':
                         i===2?'linear-gradient(135deg,#CD7F32,#8B4513)':'var(--s2)',
              display:'flex',alignItems:'center',justifyContent:'center',
              fontSize:11,fontWeight:800,flexShrink:0
            }}>{i+1}</div>
            <div style={{flex:1}}>
              <div style={{fontSize:12,fontWeight:700}}>{u.name||'Foydalanuvchi'}</div>
              <div style={{fontSize:10,color:'var(--mt)'}}>{fmt(u.stars||0)} ⭐</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
