import { useState } from 'react'
import FullPage from '../components/FullPage.jsx'
import { createTopup, createCardTopup } from '../api.js'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g,' ')
const AMTS = [10000,25000,50000,100000,200000,500000]

export default function TopUp({ open, onClose, settings, showToast, uid }) {
  const [method, setMethod]   = useState(null)
  const [selAmt, setSelAmt]   = useState(null)
  const [custom, setCustom]   = useState('')
  const [cardInfo, setCardInfo] = useState(null)
  const [loading, setLoad]    = useState(false)

  const finalAmt = selAmt || (parseInt(custom)||0)
  const support  = settings.supportLink || ''

  async function autoTopup() {
    if (finalAmt < 5000) { showToast('Minimum 5 000 so\'m!','err'); return }
    setLoad(true)
    try {
      const r = await createCardTopup(uid, finalAmt)
      if (r.success) {
        setCardInfo(r)
      } else {
        showToast('❌ ' + (r.error||'Xato'),'err')
      }
    } catch { showToast('❌ Xato','err') }
    setLoad(false)
  }

  function reset() {
    setMethod(null); setCardInfo(null)
    setSelAmt(null); setCustom('')
  }

  return (
    <FullPage open={open} onClose={()=>{reset();onClose()}} title="💰 Hisob To'ldirish">

      {/* USUL TANLASH */}
      {!method && !cardInfo && (
        <div style={{padding:'16px 18px',display:'flex',flexDirection:'column',gap:10}}>
          <div style={{fontSize:12,color:'var(--mt)',marginBottom:2}}>To'lov usulini tanlang:</div>

          <div onClick={()=>setMethod('auto')} style={{
            background:'var(--s1)',border:'1.5px solid var(--gold)',
            borderRadius:16,padding:'16px',cursor:'pointer',
            display:'flex',alignItems:'center',gap:12
          }}>
            <div style={{fontSize:28}}>💳</div>
            <div style={{flex:1}}>
              <div style={{fontWeight:800,fontSize:14,color:'var(--gold)'}}>Avtomatik (Karta)</div>
              <div style={{fontSize:11,color:'var(--mt)',marginTop:3}}>Summani kiriting → kartaga to'lang → avtomatik tasdiqlanadi</div>
            </div>
            <span style={{color:'var(--gold)'}}>›</span>
          </div>

          <div onClick={()=>setMethod('screen')} style={{
            background:'var(--s1)',border:'1px solid var(--bd)',
            borderRadius:16,padding:'16px',cursor:'pointer',
            display:'flex',alignItems:'center',gap:12
          }}>
            <div style={{fontSize:28}}>📸</div>
            <div style={{flex:1}}>
              <div style={{fontWeight:800,fontSize:14}}>Screenshot orqali</div>
              <div style={{fontSize:11,color:'var(--mt)',marginTop:3}}>Kartaga to'lang → screenshot yuboring → admin tasdiqlaydi</div>
            </div>
            <span style={{color:'var(--mt)'}}>›</span>
          </div>

          {support && (
            <div onClick={()=>{
              const tg=window.Telegram?.WebApp
              if(tg) tg.openLink(support)
            }} style={{
              background:'var(--s1)',border:'1px solid var(--bd)',
              borderRadius:16,padding:'16px',cursor:'pointer',
              display:'flex',alignItems:'center',gap:12
            }}>
              <div style={{fontSize:28}}>👨‍💼</div>
              <div style={{flex:1}}>
                <div style={{fontWeight:800,fontSize:14}}>Admin orqali</div>
                <div style={{fontSize:11,color:'var(--mt)',marginTop:3}}>Admin bilan bog'laning</div>
              </div>
              <span style={{color:'var(--mt)'}}>›</span>
            </div>
          )}
        </div>
      )}

      {/* AVTOMATIK TO'LOV - SUMMA */}
      {method==='auto' && !cardInfo && (
        <div style={{padding:'16px 18px',display:'flex',flexDirection:'column',gap:10}}>
          <button onClick={()=>setMethod(null)} style={{background:'none',border:'none',color:'var(--mt)',fontSize:12,cursor:'pointer',textAlign:'left',padding:0}}>← Orqaga</button>
          <div style={{fontSize:13,fontWeight:700}}>💳 Avtomatik to'ldirish</div>

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8}}>
            {AMTS.map(a => (
              <div key={a} onClick={()=>{setSelAmt(a);setCustom('')}} style={{
                background:selAmt===a&&!custom?'rgba(245,200,66,.08)':'var(--s1)',
                border:`1.5px solid ${selAmt===a&&!custom?'var(--gold)':'var(--bd)'}`,
                borderRadius:12,padding:'10px 6px',textAlign:'center',cursor:'pointer'
              }}>
                <div style={{fontFamily:'Space Mono,monospace',fontSize:12,fontWeight:700,color:'var(--gold)'}}>{fmt(a)}</div>
                <div style={{fontSize:9,color:'var(--mt)'}}>so'm</div>
              </div>
            ))}
          </div>

          <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:12,padding:'10px 14px'}}>
            <div style={{fontSize:10,color:'var(--mt)',marginBottom:4}}>Yoki kiriting (min 5 000):</div>
            <input type="number" value={custom}
              onChange={e=>{setCustom(e.target.value);setSelAmt(null)}}
              placeholder="75000"
              style={{width:'100%',background:'transparent',border:'none',outline:'none',
                color:'var(--tx)',fontFamily:'Syne,sans-serif',fontSize:15}}
            />
          </div>

          <div style={{
            background:'rgba(245,200,66,.05)',border:'1px solid rgba(245,200,66,.15)',
            borderRadius:12,padding:'10px 12px',fontSize:11,color:'var(--mt)',lineHeight:1.6
          }}>
            ⚠️ <b style={{color:'var(--gold)'}}>Muhim!</b> Berilgan summani aniq nusxalab to'lang. Boshqa summa yuborilsa to'lov aniqlanmaydi. Muammo bo'lsa admin bilan bog'laning.
          </div>

          <button onClick={autoTopup} disabled={loading||finalAmt<5000} style={{
            background:'linear-gradient(135deg,var(--gold),var(--gold2))',
            border:'none',borderRadius:14,padding:14,color:'#000',
            fontFamily:'Syne,sans-serif',fontSize:14,fontWeight:800,cursor:'pointer',
            opacity:loading||finalAmt<5000?0.5:1
          }}>{loading?'⏳...':'💳 Karta ma\'lumotlarini olish'}</button>
        </div>
      )}

      {/* KARTA MA'LUMOTLARI */}
      {cardInfo && (
        <div style={{padding:'16px 18px',display:'flex',flexDirection:'column',gap:12}}>
          <div style={{
            background:'linear-gradient(135deg,#1e1a3a,#0f1525)',
            border:'1px solid rgba(245,200,66,0.2)',
            borderRadius:20,padding:'20px'
          }}>
            <div style={{fontSize:12,color:'var(--mt)',marginBottom:8}}>Karta raqami:</div>
            <div style={{
              fontFamily:'Space Mono,monospace',fontSize:18,fontWeight:700,
              color:'var(--gold)',letterSpacing:2,marginBottom:4
            }}>{cardInfo.card}</div>
            <div style={{fontSize:12,color:'var(--mt)',marginBottom:16}}>{cardInfo.holder}</div>

            <div style={{
              background:'rgba(0,0,0,0.3)',borderRadius:12,padding:'12px',textAlign:'center'
            }}>
              <div style={{fontSize:11,color:'var(--mt)',marginBottom:4}}>To'lov summasi:</div>
              <div style={{
                fontFamily:'Space Mono,monospace',fontSize:24,fontWeight:700,color:'var(--gold)'
              }}>{fmt(cardInfo.unique_amount)} so'm</div>
            </div>

            <div style={{marginTop:12,fontSize:11,color:'var(--mt)',textAlign:'center'}}>
              ⏰ {cardInfo.wait_minutes} daqiqa ichida to'lang
            </div>
          </div>

          <button onClick={()=>{
            if(navigator.clipboard) {
              navigator.clipboard.writeText(String(cardInfo.unique_amount))
                .then(()=>showToast('✅ Summa nusxalandi!','ok'))
            }
          }} style={{
            background:'var(--s1)',border:'1px solid var(--gold)',
            borderRadius:14,padding:12,color:'var(--gold)',
            fontFamily:'Syne,sans-serif',fontSize:13,fontWeight:700,cursor:'pointer'
          }}>📋 Summani nusxalash</button>

          <button onClick={reset} style={{
            background:'transparent',border:'1px solid var(--bd)',
            borderRadius:14,padding:12,color:'var(--mt)',
            fontFamily:'Syne,sans-serif',fontSize:13,cursor:'pointer'
          }}>← Orqaga</button>
        </div>
      )}

      {/* SCREENSHOT */}
      {method==='screen' && (
        <div style={{padding:'16px 18px',display:'flex',flexDirection:'column',gap:10}}>
          <button onClick={()=>setMethod(null)} style={{background:'none',border:'none',color:'var(--mt)',fontSize:12,cursor:'pointer',textAlign:'left',padding:0}}>← Orqaga</button>
          <div style={{fontSize:13,fontWeight:700}}>📸 Screenshot orqali</div>
          <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:14,padding:'14px',fontSize:12,lineHeight:1.8,color:'var(--mt)'}}>
            1️⃣ Kartaga pul yuboring<br/>
            2️⃣ Botga <b style={{color:'var(--tx)'}}>/tolov</b> buyrug'ini yuboring<br/>
            3️⃣ "📸 Screenshot orqali" ni tanlang<br/>
            4️⃣ Summani kiriting<br/>
            5️⃣ Screenshot yuboring → Admin tasdiqlaydi ✅
          </div>
          <button onClick={()=>{
            const tg=window.Telegram?.WebApp
            if(tg) tg.close()
          }} style={{
            background:'linear-gradient(135deg,var(--pur),#5b3fd8)',
            border:'none',borderRadius:14,padding:14,color:'#fff',
            fontFamily:'Syne,sans-serif',fontSize:14,fontWeight:800,cursor:'pointer'
          }}>🤖 Botga o'tish → /tolov</button>
        </div>
      )}

    </FullPage>
  )
}
