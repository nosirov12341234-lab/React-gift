import { useState, useEffect } from 'react'
import { getHistory } from '../api.js'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g,' ')

export default function History({ uid }) {
  const [orders, setOrders] = useState([])
  const [loading, setLoad]  = useState(true)

  useEffect(() => {
    if (!uid || uid==='0') return
    getHistory(uid).then(r => { setOrders(r.orders||[]); setLoad(false) }).catch(()=>setLoad(false))
  }, [uid])

  const icons = { completed:'✅', failed:'❌', processing:'⏳' }

  return (
    <div style={{position:'relative',zIndex:1,animation:'fadeUp .28s ease',padding:'16px 18px'}}>
      <div style={{fontSize:16,fontWeight:800,marginBottom:14}}>📋 Buyurtmalar tarixi</div>
      {loading ? (
        <div style={{textAlign:'center',padding:40,color:'var(--mt)'}}>Yuklanmoqda...</div>
      ) : orders.length===0 ? (
        <div style={{textAlign:'center',padding:40}}>
          <div style={{fontSize:40,opacity:.3,marginBottom:10}}>📋</div>
          <div style={{color:'var(--mt)',fontSize:13}}>Hali buyurtmalar yo'q</div>
        </div>
      ) : orders.map((o,i) => (
        <div key={i} style={{
          background:'var(--s1)',border:'1px solid var(--bd)',
          borderRadius:14,padding:'12px 14px',marginBottom:8,
          display:'flex',alignItems:'center',gap:10
        }}>
          <div style={{fontSize:20}}>{icons[o.status]||'❓'}</div>
          <div style={{flex:1}}>
            <div style={{fontWeight:700,fontSize:13}}>
              {o.service==='stars' ? `${fmt(o.stars||0)} ⭐ Stars` : `👑 Premium ${o.months}oy`}
            </div>
            <div style={{fontSize:10,color:'var(--mt)',marginTop:2}}>
              @{o.username} • {o.created_at?.slice(0,10)}
            </div>
          </div>
          <div style={{fontFamily:'Space Mono,monospace',fontSize:11,color:'var(--gold)',textAlign:'right'}}>
            {fmt(o.price)} so'm
          </div>
        </div>
      ))}
    </div>
  )
}
