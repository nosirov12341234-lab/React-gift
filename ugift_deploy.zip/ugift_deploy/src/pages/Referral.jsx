import { useEffect, useState } from 'react'
import { getReferral } from '../api.js'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g,' ')

export default function Referral({ uid, showToast }) {
  const [data, setData] = useState({ link:'', referrals:0, ref_earned:0, bonus:5000, list:[] })
  const [tab, setTab]   = useState('stats')

  useEffect(() => {
    if (!uid || uid==='0') return
    getReferral(uid).then(r => setData(r)).catch(()=>{})
  }, [uid])

  function copy() {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(data.link).then(()=>showToast('✅ Nusxalandi!','ok'))
    }
  }

  return (
    <div style={{position:'relative',zIndex:1,animation:'fadeUp .28s ease'}}>
      <div style={{padding:'16px 18px',fontSize:16,fontWeight:800}}>🤝 Referral tizimi</div>

      <div style={{display:'flex',gap:6,padding:'0 18px',marginBottom:12}}>
        {['stats','list'].map(t=>(
          <button key={t} onClick={()=>setTab(t)} style={{
            padding:'7px 16px',borderRadius:20,
            border:`1px solid ${tab===t?'var(--pur)':'var(--bd)'}`,
            background:tab===t?'var(--pa)':'transparent',
            color:tab===t?'var(--pur2)':'var(--mt)',
            fontFamily:'Syne,sans-serif',fontSize:12,fontWeight:700,cursor:'pointer'
          }}>
            {t==='stats'?'📊 Statistika':`👥 Ro'yxat (${data.list?.length||0})`}
          </button>
        ))}
      </div>

      {tab==='stats' && (
        <div style={{padding:'0 18px',display:'flex',flexDirection:'column',gap:10}}>
          <div style={{
            background:'linear-gradient(135deg,#1e1a3a,#0f1525)',
            border:'1px solid rgba(124,92,252,.2)',borderRadius:18,padding:'18px'
          }}>
            <div style={{fontSize:10,color:'var(--mt)',letterSpacing:2,textTransform:'uppercase',marginBottom:4}}>Havolangiz</div>
            <div style={{fontFamily:'Space Mono,monospace',fontSize:10,color:'var(--mt)',marginBottom:12,wordBreak:'break-all'}}>
              {data.link||'—'}
            </div>
            <button onClick={copy} style={{
              background:'linear-gradient(135deg,var(--pur),#5b3fd8)',border:'none',
              borderRadius:10,padding:'9px 18px',color:'#fff',
              fontFamily:'Syne,sans-serif',fontSize:12,fontWeight:700,cursor:'pointer'
            }}>📋 Nusxa olish</button>
          </div>

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
            <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:13,padding:14,textAlign:'center'}}>
              <div style={{fontSize:28,fontWeight:800,color:'var(--pur2)',fontFamily:'Space Mono,monospace'}}>{data.referrals||0}</div>
              <div style={{fontSize:10,color:'var(--mt)',marginTop:3}}>Taklif</div>
            </div>
            <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:13,padding:14,textAlign:'center'}}>
              <div style={{fontSize:18,fontWeight:800,color:'var(--gold)',fontFamily:'Space Mono,monospace'}}>{fmt(data.ref_earned||0)}</div>
              <div style={{fontSize:10,color:'var(--mt)',marginTop:3}}>Bonus so'm</div>
            </div>
          </div>

          <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:13,padding:14,display:'flex',alignItems:'center',gap:10}}>
            <div style={{flex:1}}>
              <div style={{fontSize:13,fontWeight:700}}>Har bir do'st uchun</div>
              <div style={{fontSize:11,color:'var(--mt)',marginTop:2}}>Botga kirsa avtomatik</div>
            </div>
            <div style={{fontSize:15,fontWeight:800,color:'var(--gold)'}}>+{fmt(data.bonus||5000)} so'm</div>
          </div>
        </div>
      )}

      {tab==='list' && (
        <div style={{padding:'0 18px'}}>
          {!data.list?.length ? (
            <div style={{textAlign:'center',padding:40,color:'var(--mt)'}}>
              <div style={{fontSize:36,opacity:.3,marginBottom:8}}>👥</div>
              Hali referrallar yo'q
            </div>
          ) : data.list.map((u,i)=>(
            <div key={i} style={{
              display:'flex',alignItems:'center',gap:10,
              background:'var(--s1)',border:'1px solid var(--bd)',
              borderRadius:13,padding:'10px 12px',marginBottom:8
            }}>
              <div style={{
                width:34,height:34,borderRadius:'50%',
                background:'linear-gradient(135deg,var(--pur),#5b3fd4)',
                display:'flex',alignItems:'center',justifyContent:'center',
                fontSize:14,fontWeight:800,flexShrink:0
              }}>{(u.name||'U')[0].toUpperCase()}</div>
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:700}}>{u.name||'Foydalanuvchi'}</div>
                <div style={{fontSize:10,color:'var(--mt)',marginTop:1}}>
                  {u.username?`@${u.username} • `:''}{u.date}
                </div>
              </div>
              <div style={{fontSize:11,color:'var(--green)'}}>✅</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
