import { useState } from 'react'

const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g,' ')

export default function Profile({ settings, tgUser, onTopup, onReferral, onHistory, showToast, uid }) {
  const [tab, setTab]     = useState('profile')
  const [token, setToken] = useState('')
  const [loading, setLoad] = useState(false)
  const [docs, setDocs]   = useState(null)

  const name = tgUser?.first_name || settings.name || '—'
  const un   = tgUser?.username ? '@'+tgUser.username : settings.username ? '@'+settings.username : '—'
  const av   = name[0]?.toUpperCase() || 'U'

  function openLink(url) {
    const tg = window.Telegram?.WebApp
    if (url && tg) tg.openLink(url)
    else if (url) window.open(url,'_blank')
  }

  async function createToken() {
    setLoad(true)
    try {
      const r = await fetch('/api/v1/token/create', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ uid })
      })
      const d = await r.json()
      if (d.success) { setToken(d.token); showToast('✅ Token yaratildi!','ok') }
      else showToast('❌ '+d.error,'err')
    } catch { showToast('❌ Xato','err') }
    setLoad(false)
  }

  async function loadDocs() {
    try {
      const r = await fetch('/api/v1/docs')
      setDocs(await r.json())
    } catch {}
  }

  return (
    <div style={{position:'relative',zIndex:1,animation:'fadeUp .28s ease'}}>
      <div style={{display:'flex',gap:5,padding:'16px 18px 0'}}>
        {[{id:'profile',label:'👤 Profil'},{id:'dev',label:'⚡ Developer'}].map(t=>(
          <button key={t.id} onClick={()=>{setTab(t.id);if(t.id==='dev'&&!docs)loadDocs()}} style={{
            flex:1,padding:'9px',borderRadius:12,
            border:`1.5px solid ${tab===t.id?'var(--gold)':'var(--bd)'}`,
            background:tab===t.id?'var(--ga)':'transparent',
            color:tab===t.id?'var(--gold)':'var(--mt)',
            fontFamily:'Syne,sans-serif',fontSize:12,fontWeight:700,cursor:'pointer'
          }}>{t.label}</button>
        ))}
      </div>

      {tab==='profile' && (
        <div style={{padding:'12px 18px 0',display:'flex',flexDirection:'column',gap:10}}>
          <div style={{
            background:'linear-gradient(135deg,#1e1a3a,#0f1525)',
            border:'1px solid rgba(124,92,252,.2)',borderRadius:20,padding:'20px',textAlign:'center'
          }}>
            <div style={{
              width:56,height:56,borderRadius:'50%',
              background:'linear-gradient(135deg,var(--gold),var(--gold2))',
              display:'flex',alignItems:'center',justifyContent:'center',
              fontSize:24,fontWeight:800,margin:'0 auto 10px',color:'#000'
            }}>{av}</div>
            <div style={{fontSize:16,fontWeight:800,marginBottom:2}}>{name}</div>
            <div style={{fontSize:12,color:'var(--mt)',marginBottom:14}}>{un}</div>
            <div style={{background:'rgba(0,0,0,.3)',borderRadius:11,padding:10}}>
              <div style={{fontSize:10,color:'var(--mt)',textTransform:'uppercase',letterSpacing:1,marginBottom:2}}>Balansingiz</div>
              <div style={{fontSize:22,fontWeight:800,color:'var(--gold)',fontFamily:'Space Mono,monospace'}}>{fmt(settings.bal||0)} so'm</div>
            </div>
          </div>

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
            <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:13,padding:12,textAlign:'center'}}>
              <div style={{fontSize:20,fontWeight:800,fontFamily:'Space Mono,monospace'}}>{settings.orders_count||0}</div>
              <div style={{fontSize:10,color:'var(--mt)',marginTop:2}}>Buyurtmalar</div>
            </div>
            <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:13,padding:12,textAlign:'center'}}>
              <div style={{fontSize:20,fontWeight:800,fontFamily:'Space Mono,monospace'}}>{settings.referrals||0}</div>
              <div style={{fontSize:10,color:'var(--mt)',marginTop:2}}>Referrallar</div>
            </div>
          </div>

          {[
            {icon:'💰',label:"Hisob to'ldirish",fn:onTopup},
            {icon:'🤝',label:'Referral tizimi',fn:onReferral},
            {icon:'📋',label:'Buyurtmalar tarixi',fn:onHistory},
            settings.supportLink&&{icon:'💬',label:'Support',fn:()=>openLink(settings.supportLink)},
            settings.channelLink&&{icon:'📢',label:'Kanalimiz',fn:()=>openLink(settings.channelLink)},
          ].filter(Boolean).map((item,i)=>(
            <div key={i} onClick={item.fn} style={{
              background:'var(--s1)',border:'1px solid var(--bd)',
              borderRadius:13,padding:'12px 14px',display:'flex',alignItems:'center',cursor:'pointer'
            }}>
              <span style={{fontSize:18,marginRight:10}}>{item.icon}</span>
              <span style={{flex:1,fontSize:13,fontWeight:600}}>{item.label}</span>
              <span style={{color:'var(--mt)'}}>›</span>
            </div>
          ))}
        </div>
      )}

      {tab==='dev' && (
        <div style={{padding:'12px 18px 0',display:'flex',flexDirection:'column',gap:10}}>
          <div style={{
            background:'linear-gradient(135deg,#1a1535,#0f0e1e)',
            border:'1px solid rgba(124,92,252,.2)',borderRadius:16,padding:'16px'
          }}>
            <div style={{fontSize:13,fontWeight:800,marginBottom:4}}>🔑 API Token</div>
            <div style={{fontSize:11,color:'var(--mt)',marginBottom:12,lineHeight:1.5}}>
              Token orqali Stars va Premium sotib olishingiz mumkin. Pul <b style={{color:'var(--gold)'}}>sizning balansingizdan</b> yechiladi.
            </div>
            {token ? (
              <>
                <div style={{background:'rgba(0,0,0,.4)',borderRadius:10,padding:'10px 12px',marginBottom:10,fontFamily:'Space Mono,monospace',fontSize:9,color:'var(--pur2)',wordBreak:'break-all'}}>
                  {token}
                </div>
                <div style={{display:'flex',gap:8}}>
                  <button onClick={()=>{navigator.clipboard?.writeText(token).then(()=>showToast('✅ Nusxalandi!','ok'))}} style={{flex:1,background:'linear-gradient(135deg,var(--pur),#5b3fd8)',border:'none',borderRadius:10,padding:'9px',color:'#fff',fontFamily:'Syne,sans-serif',fontSize:12,fontWeight:700,cursor:'pointer'}}>📋 Nusxa</button>
                  <button onClick={createToken} disabled={loading} style={{flex:1,background:'var(--s2)',border:'1px solid var(--bd)',borderRadius:10,padding:'9px',color:'var(--tx)',fontFamily:'Syne,sans-serif',fontSize:12,fontWeight:700,cursor:'pointer'}}>🔄 Yangilash</button>
                </div>
              </>
            ) : (
              <button onClick={createToken} disabled={loading} style={{width:'100%',background:'linear-gradient(135deg,var(--pur),#5b3fd8)',border:'none',borderRadius:11,padding:'12px',color:'#fff',fontFamily:'Syne,sans-serif',fontSize:13,fontWeight:700,cursor:'pointer',opacity:loading?0.6:1}}>
                {loading?'⏳...':'🔑 API Token olish'}
              </button>
            )}
          </div>

          {docs && (
            <>
              <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:14,padding:'14px'}}>
                <div style={{fontSize:12,fontWeight:800,marginBottom:10,color:'var(--gold)'}}>💰 Joriy narxlar</div>
                {[
                  {label:'1 Stars',val:fmt(docs.prices?.star||210)+' so\'m'},
                  {label:'Premium 3 oy',val:fmt(docs.prices?.pm3||195000)+' so\'m'},
                  {label:'Premium 6 oy',val:fmt(docs.prices?.pm6||370000)+' so\'m'},
                  {label:'Premium 12 oy',val:fmt(docs.prices?.pm12||680000)+' so\'m'},
                ].map((p,i)=>(
                  <div key={i} style={{display:'flex',justifyContent:'space-between',fontSize:12,padding:'5px 0',borderTop:i>0?'1px solid var(--bd)':'none'}}>
                    <span style={{color:'var(--mt)'}}>{p.label}</span>
                    <span style={{fontWeight:700}}>{p.val}</span>
                  </div>
                ))}
              </div>

              <div style={{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:14,padding:'14px'}}>
                <div style={{fontSize:12,fontWeight:800,marginBottom:10,color:'var(--pur2)'}}>📡 Endpointlar</div>
                {docs.endpoints && Object.entries(docs.endpoints).map(([s,eps])=>(
                  <div key={s} style={{marginBottom:10}}>
                    <div style={{fontSize:10,color:'var(--mt)',fontWeight:700,textTransform:'uppercase',letterSpacing:1,marginBottom:6}}>{s}</div>
                    {Object.entries(eps).map(([ep,desc])=>(
                      <div key={ep} style={{background:'var(--s2)',borderRadius:8,padding:'7px 10px',marginBottom:4}}>
                        <div style={{fontFamily:'Space Mono,monospace',fontSize:9,color:'var(--gold)',marginBottom:2}}>{ep}</div>
                        <div style={{fontSize:10,color:'var(--mt)'}}>{desc}</div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>

              <div style={{background:'rgba(245,200,66,.05)',border:'1px solid rgba(245,200,66,.15)',borderRadius:13,padding:'12px',fontSize:11,color:'var(--mt)',lineHeight:1.6}}>
                ⚠️ <b style={{color:'var(--gold)'}}>Muhim:</b> {docs.billing}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  )
}
