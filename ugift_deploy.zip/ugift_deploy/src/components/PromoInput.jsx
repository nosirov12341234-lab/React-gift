import { useState } from 'react'
import { checkPromo } from '../api.js'

export default function PromoInput({ uid, product, onApply }) {
  const [code, setCode]   = useState('')
  const [msg, setMsg]     = useState('')
  const [ok, setOk]       = useState(false)
  const [loading, setLoading] = useState(false)

  async function apply() {
    if (!code.trim()) return
    setLoading(true)
    try {
      const r = await checkPromo(code.trim(), uid, product)
      if (r.success) {
        setOk(true); setMsg(`✅ -${r.discount}% chegirma!`)
        onApply(r.discount, code.trim().toUpperCase())
      } else {
        setOk(false); setMsg('❌ ' + r.error)
      }
    } catch { setMsg('❌ Xato') }
    setLoading(false)
  }

  return (
    <div style={{margin:'10px 18px 0'}}>
      <div style={{
        display:'flex',gap:8,
        background:'var(--s1)',border:`1px solid ${ok?'var(--green)':'var(--bd)'}`,
        borderRadius:12,padding:'8px 12px',alignItems:'center'
      }}>
        <span style={{fontSize:14}}>🎁</span>
        <input value={code} onChange={e=>setCode(e.target.value.toUpperCase())}
          placeholder="Promo kod"
          style={{flex:1,background:'transparent',border:'none',outline:'none',
            color:'var(--tx)',fontFamily:'Syne,sans-serif',fontSize:13}}
        />
        <button onClick={apply} disabled={loading||ok} style={{
          background:'var(--s2)',border:'1px solid var(--bd)',
          borderRadius:8,padding:'4px 10px',color:'var(--tx)',
          fontSize:11,fontWeight:700,cursor:'pointer',
          opacity:ok?0.5:1
        }}>{ok?'✅':'Qo\'llash'}</button>
      </div>
      {msg && <div style={{fontSize:11,marginTop:4,color:ok?'var(--green)':'var(--red)',paddingLeft:4}}>{msg}</div>}
    </div>
  )
}
