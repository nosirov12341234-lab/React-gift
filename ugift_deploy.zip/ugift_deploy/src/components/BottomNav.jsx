const tabs = [
  { id:'home',    icon:'🏠', label:'Bosh' },
  { id:'stars',   icon:'⭐', label:'Stars', action:true },
  { id:'premium', icon:'👑', label:'Premium', action:true },
  { id:'history', icon:'📋', label:'Tarix' },
  { id:'profile', icon:'👤', label:'Profil' },
]

export default function BottomNav({ page, setPage, onOpenStars, onOpenPremium }) {
  return (
    <div style={{
      position:'fixed',bottom:0,left:0,right:0,zIndex:100,
      display:'flex',
      background:'rgba(10,10,15,0.96)',backdropFilter:'blur(20px)',
      borderTop:'1px solid var(--bd)',
      paddingBottom:'env(safe-area-inset-bottom,0px)',
    }}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => {
          if (t.id==='stars') onOpenStars()
          else if (t.id==='premium') onOpenPremium()
          else setPage(t.id)
        }} style={{
          flex:1,padding:'8px 4px',border:'none',
          background:'transparent',cursor:'pointer',
          display:'flex',flexDirection:'column',alignItems:'center',gap:2,
          color: page===t.id ? 'var(--gold)' : 'var(--mt)',
          transition:'color .2s'
        }}>
          <span style={{fontSize:20}}>{t.icon}</span>
          <span style={{fontSize:9,fontWeight:700,letterSpacing:.3}}>{t.label}</span>
        </button>
      ))}
    </div>
  )
}
