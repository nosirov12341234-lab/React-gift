export default function FullPage({ open, onClose, title, children }) {
  if (!open) return null
  return (
    <div style={{
      position:'fixed',inset:0,zIndex:200,
      background:'var(--bg)',overflowY:'auto',
      animation:'slideUp .28s ease'
    }}>
      <div style={{
        position:'sticky',top:0,zIndex:10,
        padding:'12px 18px',
        display:'flex',alignItems:'center',gap:12,
        background:'rgba(10,10,15,0.95)',backdropFilter:'blur(16px)',
        borderBottom:'1px solid var(--bd)'
      }}>
        <button onClick={onClose} style={{
          width:34,height:34,borderRadius:10,
          background:'var(--s2)',border:'1px solid var(--bd)',
          color:'var(--tx)',fontSize:16,cursor:'pointer',
          display:'flex',alignItems:'center',justifyContent:'center'
        }}>←</button>
        <div style={{fontSize:16,fontWeight:800}}>{title}</div>
      </div>
      <div style={{paddingBottom:30}}>{children}</div>
    </div>
  )
}
