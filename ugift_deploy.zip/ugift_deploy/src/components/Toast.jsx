import { useState, useCallback } from 'react'

export function useToast() {
  const [toast, setToast] = useState(null)
  const show = useCallback((msg, type='ok') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3000)
  }, [])
  return { toast, show }
}

export function Toast({ msg, type }) {
  return (
    <div style={{
      position:'fixed',bottom:80,left:'50%',transform:'translateX(-50%)',
      zIndex:999,padding:'10px 20px',borderRadius:20,
      background: type==='err' ? 'var(--red)' : 'var(--green)',
      color:'#fff',fontWeight:700,fontSize:13,
      animation:'fadeUp .3s ease',whiteSpace:'nowrap',
      boxShadow:'0 8px 24px rgba(0,0,0,0.4)'
    }}>{msg}</div>
  )
}
