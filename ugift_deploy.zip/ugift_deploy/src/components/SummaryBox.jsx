const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g,' ')

export default function SummaryBox({ rows=[], total=0, totalColor='var(--gold)' }) {
  return (
    <div style={{
      margin:'10px 18px 0',
      background:'var(--s1)',border:'1px solid var(--bd)',
      borderRadius:13,padding:'12px 14px'
    }}>
      {rows.filter(Boolean).map((r,i) => (
        <div key={i} style={{
          display:'flex',justifyContent:'space-between',
          fontSize:12,padding:'4px 0',
          borderTop:i>0?'1px solid var(--bd)':'none'
        }}>
          <span style={{color:'var(--mt)'}}>{r.label}</span>
          <span style={{fontWeight:700,color:r.color||'var(--tx)'}}>{r.value}</span>
        </div>
      ))}
      <div style={{
        display:'flex',justifyContent:'space-between',
        fontSize:14,fontWeight:800,
        borderTop:'1px solid var(--bd)',marginTop:6,paddingTop:6
      }}>
        <span>Jami to'lov</span>
        <span style={{color:totalColor,fontFamily:'Space Mono,monospace'}}>
          {fmt(total)} so'm
        </span>
      </div>
    </div>
  )
}
