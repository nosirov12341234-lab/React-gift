const fmt = n => Math.round(n).toLocaleString('ru-RU').replace(/\s/g,' ')

export default function Header({ bal, name }) {
  return (
    <div style={{
      position:'sticky',top:0,zIndex:100,
      padding:'12px 18px',
      display:'flex',alignItems:'center',justifyContent:'space-between',
      background:'rgba(10,10,15,0.92)',backdropFilter:'blur(16px)',
      borderBottom:'1px solid var(--bd)'
    }}>
      <div style={{display:'flex',alignItems:'center',gap:8}}>
        <div style={{
          width:32,height:32,borderRadius:'50%',
          background:'linear-gradient(135deg,var(--gold),var(--gold2))',
          display:'flex',alignItems:'center',justifyContent:'center',
          fontSize:14,fontWeight:800,color:'#000'
        }}>{(name||'U')[0].toUpperCase()}</div>
        <div>
          <div style={{fontSize:12,fontWeight:700}}>{name||'Foydalanuvchi'}</div>
          <div style={{fontSize:10,color:'var(--mt)'}}>U-Gift Market</div>
        </div>
      </div>
      <div style={{
        background:'var(--ga)',border:'1px solid rgba(245,200,66,0.2)',
        borderRadius:20,padding:'5px 12px',
        display:'flex',alignItems:'center',gap:5
      }}>
        <span style={{fontSize:12}}>💰</span>
        <span style={{fontFamily:'Space Mono,monospace',fontSize:12,fontWeight:700,color:'var(--gold)'}}>
          {fmt(bal)} so'm
        </span>
      </div>
    </div>
  )
}
