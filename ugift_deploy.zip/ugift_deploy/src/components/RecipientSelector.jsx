export default function RecipientSelector({ value, onChange, usernameVal, onUsernameChange, color='gold' }) {
  const c = color==='gold' ? 'var(--gold)' : 'var(--pur2)'
  const bg = color==='gold' ? 'var(--ga)' : 'var(--pa)'
  return (
    <div style={{margin:'10px 18px 0',display:'flex',flexDirection:'column',gap:8}}>
      <div style={{display:'flex',gap:8}}>
        {['self','other'].map(v => (
          <button key={v} onClick={()=>onChange(v)} style={{
            flex:1,padding:'9px',borderRadius:11,
            border:`1.5px solid ${value===v?c:'var(--bd)'}`,
            background:value===v?bg:'transparent',
            color:value===v?c:'var(--mt)',
            fontFamily:'Syne,sans-serif',fontSize:12,fontWeight:700,cursor:'pointer'
          }}>
            {v==='self'?'👤 O\'zimga':'👥 Boshqaga'}
          </button>
        ))}
      </div>
      {value==='other' && (
        <div style={{
          background:'var(--s1)',border:'1px solid var(--bd)',
          borderRadius:11,padding:'10px 12px',display:'flex',alignItems:'center',gap:8
        }}>
          <span style={{color:'var(--mt)',fontSize:13}}>@</span>
          <input value={usernameVal} onChange={e=>onUsernameChange(e.target.value.replace('@',''))}
            placeholder="username"
            style={{flex:1,background:'transparent',border:'none',outline:'none',
              color:'var(--tx)',fontFamily:'Syne,sans-serif',fontSize:14}}
          />
        </div>
      )}
    </div>
  )
}
