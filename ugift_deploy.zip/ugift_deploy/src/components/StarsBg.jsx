export default function StarsBg() {
  return (
    <div style={{
      position:'fixed',inset:0,zIndex:0,overflow:'hidden',pointerEvents:'none'
    }}>
      {[...Array(40)].map((_,i) => (
        <div key={i} style={{
          position:'absolute',
          width: Math.random()*2+1+'px',
          height: Math.random()*2+1+'px',
          background:'rgba(255,255,255,'+(Math.random()*0.4+0.1)+')',
          borderRadius:'50%',
          left: Math.random()*100+'%',
          top: Math.random()*100+'%',
          animation:`pulse ${Math.random()*3+2}s ease-in-out infinite`,
          animationDelay: Math.random()*3+'s',
        }}/>
      ))}
    </div>
  )
}
